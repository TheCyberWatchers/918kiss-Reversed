package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;

public class ActionMenuView extends LinearLayoutCompat implements MenuBuilder.ItemInvoker, MenuView {
  static final int GENERATED_ITEM_PADDING = 4;
  
  static final int MIN_CELL_SIZE = 56;
  
  private static final String TAG = "ActionMenuView";
  
  private MenuPresenter.Callback mActionMenuPresenterCallback;
  
  private boolean mFormatItems;
  
  private int mFormatItemsWidth;
  
  private int mGeneratedItemPadding;
  
  private MenuBuilder mMenu;
  
  MenuBuilder.Callback mMenuBuilderCallback;
  
  private int mMinCellSize;
  
  OnMenuItemClickListener mOnMenuItemClickListener;
  
  private Context mPopupContext;
  
  private int mPopupTheme;
  
  private ActionMenuPresenter mPresenter;
  
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mMinCellSize = (int)(56.0F * f);
    this.mGeneratedItemPadding = (int)(f * 4.0F);
    this.mPopupContext = paramContext;
    this.mPopupTheme = 0;
  }
  
  static int measureChildForCells(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool = true;
    if (actionMenuItemView != null && actionMenuItemView.hasText()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int j = paramView.getMeasuredWidth();
      int k = j / paramInt1;
      paramInt2 = k;
      if (j % paramInt1 != 0)
        paramInt2 = k + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    if (layoutParams.isOverflowButton || paramInt3 == 0)
      bool = false; 
    layoutParams.expandable = bool;
    layoutParams.cellsUsed = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore_1
    //   10: iload_2
    //   11: invokestatic getSize : (I)I
    //   14: istore #4
    //   16: aload_0
    //   17: invokevirtual getPaddingLeft : ()I
    //   20: istore #5
    //   22: aload_0
    //   23: invokevirtual getPaddingRight : ()I
    //   26: istore #6
    //   28: aload_0
    //   29: invokevirtual getPaddingTop : ()I
    //   32: aload_0
    //   33: invokevirtual getPaddingBottom : ()I
    //   36: iadd
    //   37: istore #7
    //   39: iload_2
    //   40: iload #7
    //   42: bipush #-2
    //   44: invokestatic getChildMeasureSpec : (III)I
    //   47: istore #8
    //   49: iload_1
    //   50: iload #5
    //   52: iload #6
    //   54: iadd
    //   55: isub
    //   56: istore #9
    //   58: aload_0
    //   59: getfield mMinCellSize : I
    //   62: istore_2
    //   63: iload #9
    //   65: iload_2
    //   66: idiv
    //   67: istore_1
    //   68: iload_1
    //   69: ifne -> 80
    //   72: aload_0
    //   73: iload #9
    //   75: iconst_0
    //   76: invokevirtual setMeasuredDimension : (II)V
    //   79: return
    //   80: iload_2
    //   81: iload #9
    //   83: iload_2
    //   84: irem
    //   85: iload_1
    //   86: idiv
    //   87: iadd
    //   88: istore #10
    //   90: aload_0
    //   91: invokevirtual getChildCount : ()I
    //   94: istore #11
    //   96: iconst_0
    //   97: istore #5
    //   99: iconst_0
    //   100: istore #12
    //   102: iconst_0
    //   103: istore #6
    //   105: iconst_0
    //   106: istore #13
    //   108: iconst_0
    //   109: istore #14
    //   111: iconst_0
    //   112: istore #15
    //   114: lconst_0
    //   115: lstore #16
    //   117: iload #12
    //   119: iload #11
    //   121: if_icmpge -> 368
    //   124: aload_0
    //   125: iload #12
    //   127: invokevirtual getChildAt : (I)Landroid/view/View;
    //   130: astore #18
    //   132: aload #18
    //   134: invokevirtual getVisibility : ()I
    //   137: bipush #8
    //   139: if_icmpne -> 148
    //   142: iload #15
    //   144: istore_2
    //   145: goto -> 359
    //   148: aload #18
    //   150: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   153: istore #19
    //   155: iinc #13, 1
    //   158: iload #19
    //   160: ifeq -> 180
    //   163: aload_0
    //   164: getfield mGeneratedItemPadding : I
    //   167: istore_2
    //   168: aload #18
    //   170: iload_2
    //   171: iconst_0
    //   172: iload_2
    //   173: iconst_0
    //   174: invokevirtual setPadding : (IIII)V
    //   177: goto -> 180
    //   180: aload #18
    //   182: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   185: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   188: astore #20
    //   190: aload #20
    //   192: iconst_0
    //   193: putfield expanded : Z
    //   196: aload #20
    //   198: iconst_0
    //   199: putfield extraPixels : I
    //   202: aload #20
    //   204: iconst_0
    //   205: putfield cellsUsed : I
    //   208: aload #20
    //   210: iconst_0
    //   211: putfield expandable : Z
    //   214: aload #20
    //   216: iconst_0
    //   217: putfield leftMargin : I
    //   220: aload #20
    //   222: iconst_0
    //   223: putfield rightMargin : I
    //   226: iload #19
    //   228: ifeq -> 248
    //   231: aload #18
    //   233: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   236: invokevirtual hasText : ()Z
    //   239: ifeq -> 248
    //   242: iconst_1
    //   243: istore #19
    //   245: goto -> 251
    //   248: iconst_0
    //   249: istore #19
    //   251: aload #20
    //   253: iload #19
    //   255: putfield preventEdgeOffset : Z
    //   258: aload #20
    //   260: getfield isOverflowButton : Z
    //   263: ifeq -> 271
    //   266: iconst_1
    //   267: istore_2
    //   268: goto -> 273
    //   271: iload_1
    //   272: istore_2
    //   273: aload #18
    //   275: iload #10
    //   277: iload_2
    //   278: iload #8
    //   280: iload #7
    //   282: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   285: istore #21
    //   287: iload #14
    //   289: iload #21
    //   291: invokestatic max : (II)I
    //   294: istore #14
    //   296: iload #15
    //   298: istore_2
    //   299: aload #20
    //   301: getfield expandable : Z
    //   304: ifeq -> 312
    //   307: iload #15
    //   309: iconst_1
    //   310: iadd
    //   311: istore_2
    //   312: aload #20
    //   314: getfield isOverflowButton : Z
    //   317: ifeq -> 323
    //   320: iconst_1
    //   321: istore #6
    //   323: iload_1
    //   324: iload #21
    //   326: isub
    //   327: istore_1
    //   328: iload #5
    //   330: aload #18
    //   332: invokevirtual getMeasuredHeight : ()I
    //   335: invokestatic max : (II)I
    //   338: istore #5
    //   340: iload #21
    //   342: iconst_1
    //   343: if_icmpne -> 359
    //   346: lload #16
    //   348: iconst_1
    //   349: iload #12
    //   351: ishl
    //   352: i2l
    //   353: lor
    //   354: lstore #16
    //   356: goto -> 359
    //   359: iinc #12, 1
    //   362: iload_2
    //   363: istore #15
    //   365: goto -> 117
    //   368: iload #6
    //   370: ifeq -> 385
    //   373: iload #13
    //   375: iconst_2
    //   376: if_icmpne -> 385
    //   379: iconst_1
    //   380: istore #12
    //   382: goto -> 388
    //   385: iconst_0
    //   386: istore #12
    //   388: iconst_0
    //   389: istore_2
    //   390: iload_1
    //   391: istore #7
    //   393: iload #12
    //   395: istore #21
    //   397: iload #9
    //   399: istore #12
    //   401: iload #15
    //   403: ifle -> 721
    //   406: iload #7
    //   408: ifle -> 721
    //   411: iconst_0
    //   412: istore #22
    //   414: iconst_0
    //   415: istore #23
    //   417: ldc 2147483647
    //   419: istore #9
    //   421: lconst_0
    //   422: lstore #24
    //   424: iload #23
    //   426: iload #11
    //   428: if_icmpge -> 551
    //   431: aload_0
    //   432: iload #23
    //   434: invokevirtual getChildAt : (I)Landroid/view/View;
    //   437: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   440: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   443: astore #18
    //   445: aload #18
    //   447: getfield expandable : Z
    //   450: ifne -> 467
    //   453: iload #22
    //   455: istore_1
    //   456: iload #9
    //   458: istore #26
    //   460: lload #24
    //   462: lstore #27
    //   464: goto -> 534
    //   467: aload #18
    //   469: getfield cellsUsed : I
    //   472: iload #9
    //   474: if_icmpge -> 495
    //   477: aload #18
    //   479: getfield cellsUsed : I
    //   482: istore #26
    //   484: lconst_1
    //   485: iload #23
    //   487: lshl
    //   488: lstore #27
    //   490: iconst_1
    //   491: istore_1
    //   492: goto -> 534
    //   495: iload #22
    //   497: istore_1
    //   498: iload #9
    //   500: istore #26
    //   502: lload #24
    //   504: lstore #27
    //   506: aload #18
    //   508: getfield cellsUsed : I
    //   511: iload #9
    //   513: if_icmpne -> 534
    //   516: iload #22
    //   518: iconst_1
    //   519: iadd
    //   520: istore_1
    //   521: lload #24
    //   523: lconst_1
    //   524: iload #23
    //   526: lshl
    //   527: lor
    //   528: lstore #27
    //   530: iload #9
    //   532: istore #26
    //   534: iinc #23, 1
    //   537: iload_1
    //   538: istore #22
    //   540: iload #26
    //   542: istore #9
    //   544: lload #27
    //   546: lstore #24
    //   548: goto -> 424
    //   551: iload_2
    //   552: istore_1
    //   553: iload #5
    //   555: istore_2
    //   556: lload #16
    //   558: lload #24
    //   560: lor
    //   561: lstore #16
    //   563: iload #22
    //   565: iload #7
    //   567: if_icmple -> 573
    //   570: goto -> 726
    //   573: iconst_0
    //   574: istore_1
    //   575: iload_1
    //   576: iload #11
    //   578: if_icmpge -> 713
    //   581: aload_0
    //   582: iload_1
    //   583: invokevirtual getChildAt : (I)Landroid/view/View;
    //   586: astore #20
    //   588: aload #20
    //   590: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   593: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   596: astore #18
    //   598: iconst_1
    //   599: iload_1
    //   600: ishl
    //   601: i2l
    //   602: lstore #29
    //   604: lload #24
    //   606: lload #29
    //   608: land
    //   609: lconst_0
    //   610: lcmp
    //   611: ifne -> 644
    //   614: lload #16
    //   616: lstore #27
    //   618: aload #18
    //   620: getfield cellsUsed : I
    //   623: iload #9
    //   625: iconst_1
    //   626: iadd
    //   627: if_icmpne -> 637
    //   630: lload #16
    //   632: lload #29
    //   634: lor
    //   635: lstore #27
    //   637: lload #27
    //   639: lstore #16
    //   641: goto -> 707
    //   644: iload #21
    //   646: ifeq -> 686
    //   649: aload #18
    //   651: getfield preventEdgeOffset : Z
    //   654: ifeq -> 686
    //   657: iload #7
    //   659: iconst_1
    //   660: if_icmpne -> 686
    //   663: aload_0
    //   664: getfield mGeneratedItemPadding : I
    //   667: istore #5
    //   669: aload #20
    //   671: iload #5
    //   673: iload #10
    //   675: iadd
    //   676: iconst_0
    //   677: iload #5
    //   679: iconst_0
    //   680: invokevirtual setPadding : (IIII)V
    //   683: goto -> 686
    //   686: aload #18
    //   688: aload #18
    //   690: getfield cellsUsed : I
    //   693: iconst_1
    //   694: iadd
    //   695: putfield cellsUsed : I
    //   698: aload #18
    //   700: iconst_1
    //   701: putfield expanded : Z
    //   704: iinc #7, -1
    //   707: iinc #1, 1
    //   710: goto -> 575
    //   713: iload_2
    //   714: istore #5
    //   716: iconst_1
    //   717: istore_2
    //   718: goto -> 401
    //   721: iload_2
    //   722: istore_1
    //   723: iload #5
    //   725: istore_2
    //   726: iload #6
    //   728: ifne -> 743
    //   731: iload #13
    //   733: iconst_1
    //   734: if_icmpne -> 743
    //   737: iconst_1
    //   738: istore #5
    //   740: goto -> 746
    //   743: iconst_0
    //   744: istore #5
    //   746: iload #7
    //   748: ifle -> 1096
    //   751: lload #16
    //   753: lconst_0
    //   754: lcmp
    //   755: ifeq -> 1096
    //   758: iload #7
    //   760: iload #13
    //   762: iconst_1
    //   763: isub
    //   764: if_icmplt -> 778
    //   767: iload #5
    //   769: ifne -> 778
    //   772: iload #14
    //   774: iconst_1
    //   775: if_icmple -> 1096
    //   778: lload #16
    //   780: invokestatic bitCount : (J)I
    //   783: i2f
    //   784: fstore #31
    //   786: iload #5
    //   788: ifne -> 887
    //   791: fload #31
    //   793: fstore #32
    //   795: lload #16
    //   797: lconst_1
    //   798: land
    //   799: lconst_0
    //   800: lcmp
    //   801: ifeq -> 832
    //   804: fload #31
    //   806: fstore #32
    //   808: aload_0
    //   809: iconst_0
    //   810: invokevirtual getChildAt : (I)Landroid/view/View;
    //   813: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   816: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   819: getfield preventEdgeOffset : Z
    //   822: ifne -> 832
    //   825: fload #31
    //   827: ldc 0.5
    //   829: fsub
    //   830: fstore #32
    //   832: iload #11
    //   834: iconst_1
    //   835: isub
    //   836: istore #5
    //   838: fload #32
    //   840: fstore #31
    //   842: lload #16
    //   844: iconst_1
    //   845: iload #5
    //   847: ishl
    //   848: i2l
    //   849: land
    //   850: lconst_0
    //   851: lcmp
    //   852: ifeq -> 887
    //   855: fload #32
    //   857: fstore #31
    //   859: aload_0
    //   860: iload #5
    //   862: invokevirtual getChildAt : (I)Landroid/view/View;
    //   865: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   868: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   871: getfield preventEdgeOffset : Z
    //   874: ifne -> 887
    //   877: fload #32
    //   879: ldc 0.5
    //   881: fsub
    //   882: fstore #31
    //   884: goto -> 887
    //   887: fload #31
    //   889: fconst_0
    //   890: fcmpl
    //   891: ifle -> 909
    //   894: iload #7
    //   896: iload #10
    //   898: imul
    //   899: i2f
    //   900: fload #31
    //   902: fdiv
    //   903: f2i
    //   904: istore #5
    //   906: goto -> 912
    //   909: iconst_0
    //   910: istore #5
    //   912: iconst_0
    //   913: istore #6
    //   915: iload_1
    //   916: istore #15
    //   918: iload #6
    //   920: iload #11
    //   922: if_icmpge -> 1099
    //   925: lload #16
    //   927: iconst_1
    //   928: iload #6
    //   930: ishl
    //   931: i2l
    //   932: land
    //   933: lconst_0
    //   934: lcmp
    //   935: ifne -> 944
    //   938: iload_1
    //   939: istore #15
    //   941: goto -> 1087
    //   944: aload_0
    //   945: iload #6
    //   947: invokevirtual getChildAt : (I)Landroid/view/View;
    //   950: astore #20
    //   952: aload #20
    //   954: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   957: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   960: astore #18
    //   962: aload #20
    //   964: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   967: ifeq -> 1012
    //   970: aload #18
    //   972: iload #5
    //   974: putfield extraPixels : I
    //   977: aload #18
    //   979: iconst_1
    //   980: putfield expanded : Z
    //   983: iload #6
    //   985: ifne -> 1009
    //   988: aload #18
    //   990: getfield preventEdgeOffset : Z
    //   993: ifne -> 1009
    //   996: aload #18
    //   998: iload #5
    //   1000: ineg
    //   1001: iconst_2
    //   1002: idiv
    //   1003: putfield leftMargin : I
    //   1006: goto -> 1009
    //   1009: goto -> 1043
    //   1012: aload #18
    //   1014: getfield isOverflowButton : Z
    //   1017: ifeq -> 1049
    //   1020: aload #18
    //   1022: iload #5
    //   1024: putfield extraPixels : I
    //   1027: aload #18
    //   1029: iconst_1
    //   1030: putfield expanded : Z
    //   1033: aload #18
    //   1035: iload #5
    //   1037: ineg
    //   1038: iconst_2
    //   1039: idiv
    //   1040: putfield rightMargin : I
    //   1043: iconst_1
    //   1044: istore #15
    //   1046: goto -> 1087
    //   1049: iload #6
    //   1051: ifeq -> 1063
    //   1054: aload #18
    //   1056: iload #5
    //   1058: iconst_2
    //   1059: idiv
    //   1060: putfield leftMargin : I
    //   1063: iload_1
    //   1064: istore #15
    //   1066: iload #6
    //   1068: iload #11
    //   1070: iconst_1
    //   1071: isub
    //   1072: if_icmpeq -> 1087
    //   1075: aload #18
    //   1077: iload #5
    //   1079: iconst_2
    //   1080: idiv
    //   1081: putfield rightMargin : I
    //   1084: iload_1
    //   1085: istore #15
    //   1087: iinc #6, 1
    //   1090: iload #15
    //   1092: istore_1
    //   1093: goto -> 915
    //   1096: iload_1
    //   1097: istore #15
    //   1099: iload #15
    //   1101: ifeq -> 1172
    //   1104: iconst_0
    //   1105: istore_1
    //   1106: iload_1
    //   1107: iload #11
    //   1109: if_icmpge -> 1172
    //   1112: aload_0
    //   1113: iload_1
    //   1114: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1117: astore #18
    //   1119: aload #18
    //   1121: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1124: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   1127: astore #20
    //   1129: aload #20
    //   1131: getfield expanded : Z
    //   1134: ifne -> 1140
    //   1137: goto -> 1166
    //   1140: aload #18
    //   1142: aload #20
    //   1144: getfield cellsUsed : I
    //   1147: iload #10
    //   1149: imul
    //   1150: aload #20
    //   1152: getfield extraPixels : I
    //   1155: iadd
    //   1156: ldc 1073741824
    //   1158: invokestatic makeMeasureSpec : (II)I
    //   1161: iload #8
    //   1163: invokevirtual measure : (II)V
    //   1166: iinc #1, 1
    //   1169: goto -> 1106
    //   1172: iload_3
    //   1173: ldc 1073741824
    //   1175: if_icmpeq -> 1183
    //   1178: iload_2
    //   1179: istore_1
    //   1180: goto -> 1186
    //   1183: iload #4
    //   1185: istore_1
    //   1186: aload_0
    //   1187: iload #12
    //   1189: iload_1
    //   1190: invokevirtual setMeasuredDimension : (II)V
    //   1193: return
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dismissPopupMenus() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null)
      actionMenuPresenter.dismissPopupMenus(); 
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    LayoutParams layoutParams = new LayoutParams(-2, -2);
    layoutParams.gravity = 16;
    return layoutParams;
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      LayoutParams layoutParams;
      if (paramLayoutParams instanceof LayoutParams) {
        layoutParams = new LayoutParams((LayoutParams)paramLayoutParams);
      } else {
        layoutParams = new LayoutParams((ViewGroup.LayoutParams)layoutParams);
      } 
      if (layoutParams.gravity <= 0)
        layoutParams.gravity = 16; 
      return layoutParams;
    } 
    return generateDefaultLayoutParams();
  }
  
  public LayoutParams generateOverflowButtonLayoutParams() {
    LayoutParams layoutParams = generateDefaultLayoutParams();
    layoutParams.isOverflowButton = true;
    return layoutParams;
  }
  
  public Menu getMenu() {
    if (this.mMenu == null) {
      Context context = getContext();
      MenuBuilder menuBuilder = new MenuBuilder(context);
      this.mMenu = menuBuilder;
      menuBuilder.setCallback(new MenuBuilderCallback());
      ActionMenuPresenter actionMenuPresenter1 = new ActionMenuPresenter(context);
      this.mPresenter = actionMenuPresenter1;
      actionMenuPresenter1.setReserveOverflow(true);
      ActionMenuPresenter actionMenuPresenter2 = this.mPresenter;
      MenuPresenter.Callback callback = this.mActionMenuPresenterCallback;
      if (callback == null)
        callback = new ActionMenuPresenterCallback(); 
      actionMenuPresenter2.setCallback(callback);
      this.mMenu.addMenuPresenter((MenuPresenter)this.mPresenter, this.mPopupContext);
      this.mPresenter.setMenuView(this);
    } 
    return (Menu)this.mMenu;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    return this.mPresenter.getOverflowIcon();
  }
  
  public int getPopupTheme() {
    return this.mPopupTheme;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    boolean bool;
    int i = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int j = i;
    if (paramInt < getChildCount()) {
      j = i;
      if (view1 instanceof ActionMenuChildView)
        j = false | ((ActionMenuChildView)view1).needsDividerAfter(); 
    } 
    i = j;
    if (paramInt > 0) {
      i = j;
      if (view2 instanceof ActionMenuChildView)
        bool = j | ((ActionMenuChildView)view2).needsDividerBefore(); 
    } 
    return bool;
  }
  
  public boolean hideOverflowMenu() {
    boolean bool;
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null && actionMenuPresenter.hideOverflowMenu()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void initialize(MenuBuilder paramMenuBuilder) {
    this.mMenu = paramMenuBuilder;
  }
  
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl) {
    return this.mMenu.performItemAction((MenuItem)paramMenuItemImpl, 0);
  }
  
  public boolean isOverflowMenuShowPending() {
    boolean bool;
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowPending()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isOverflowMenuShowing() {
    boolean bool;
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowing()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null) {
      actionMenuPresenter.updateMenuView(false);
      if (this.mPresenter.isOverflowMenuShowing()) {
        this.mPresenter.hideOverflowMenu();
        this.mPresenter.showOverflowMenu();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.mFormatItems) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int i = getChildCount();
    int j = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    paramInt1 = m - getPaddingRight() - getPaddingLeft();
    paramBoolean = ViewUtils.isLayoutRtl((View)this);
    paramInt3 = 0;
    paramInt4 = 0;
    paramInt2 = 0;
    while (paramInt3 < i) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isOverflowButton) {
          int i2;
          int n = view.getMeasuredWidth();
          paramInt4 = n;
          if (hasSupportDividerBeforeChildAt(paramInt3))
            paramInt4 = n + k; 
          int i1 = view.getMeasuredHeight();
          if (paramBoolean) {
            n = getPaddingLeft() + layoutParams.leftMargin;
            i2 = n + paramInt4;
          } else {
            i2 = getWidth() - getPaddingRight() - layoutParams.rightMargin;
            n = i2 - paramInt4;
          } 
          int i3 = j - i1 / 2;
          view.layout(n, i3, i2, i1 + i3);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
          hasSupportDividerBeforeChildAt(paramInt3);
          paramInt2++;
        } 
      } 
      paramInt3++;
    } 
    if (i == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = m / 2 - paramInt1 / 2;
      paramInt4 = j - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 -= paramInt4 ^ 0x1;
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt3 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < i) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt2 = paramInt3;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt2 = paramInt3;
          } else {
            paramInt2 = paramInt3 - layoutParams.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            int n = j - i1 / 2;
            view.layout(paramInt2 - paramInt3, n, paramInt2, i1 + n);
            paramInt2 -= paramInt3 + layoutParams.leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt3 = paramInt2;
      } 
    } else {
      paramInt3 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < i) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt2 = paramInt3;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt2 = paramInt3;
          } else {
            paramInt3 += layoutParams.leftMargin;
            int n = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            paramInt2 = j - i1 / 2;
            view.layout(paramInt3, paramInt2, paramInt3 + n, i1 + paramInt2);
            paramInt2 = paramInt3 + n + layoutParams.rightMargin + paramInt4;
          }  
        paramInt1++;
        paramInt3 = paramInt2;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool2;
    boolean bool1 = this.mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mFormatItems = bool2;
    if (bool1 != bool2)
      this.mFormatItemsWidth = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.mFormatItems) {
      MenuBuilder menuBuilder = this.mMenu;
      if (menuBuilder != null && i != this.mFormatItemsWidth) {
        this.mFormatItemsWidth = i;
        menuBuilder.onItemsChanged(true);
      } 
    } 
    int j = getChildCount();
    if (this.mFormatItems && j > 0) {
      onMeasureExactFormat(paramInt1, paramInt2);
    } else {
      for (i = 0; i < j; i++) {
        LayoutParams layoutParams = (LayoutParams)getChildAt(i).getLayoutParams();
        layoutParams.rightMargin = 0;
        layoutParams.leftMargin = 0;
      } 
      super.onMeasure(paramInt1, paramInt2);
    } 
  }
  
  public MenuBuilder peekMenu() {
    return this.mMenu;
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mPresenter.setExpandedActionViewsExclusive(paramBoolean);
  }
  
  public void setMenuCallbacks(MenuPresenter.Callback paramCallback, MenuBuilder.Callback paramCallback1) {
    this.mActionMenuPresenterCallback = paramCallback;
    this.mMenuBuilderCallback = paramCallback1;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.mOnMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    this.mPresenter.setOverflowIcon(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.mPopupTheme != paramInt) {
      this.mPopupTheme = paramInt;
      if (paramInt == 0) {
        this.mPopupContext = getContext();
      } else {
        this.mPopupContext = (Context)new ContextThemeWrapper(getContext(), paramInt);
      } 
    } 
  }
  
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter) {
    this.mPresenter = paramActionMenuPresenter;
    paramActionMenuPresenter.setMenuView(this);
  }
  
  public boolean showOverflowMenu() {
    boolean bool;
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null && actionMenuPresenter.showOverflowMenu()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static interface ActionMenuChildView {
    boolean needsDividerAfter();
    
    boolean needsDividerBefore();
  }
  
  private static class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      return false;
    }
  }
  
  public static class LayoutParams extends LinearLayoutCompat.LayoutParams {
    @ExportedProperty
    public int cellsUsed;
    
    @ExportedProperty
    public boolean expandable;
    
    boolean expanded;
    
    @ExportedProperty
    public int extraPixels;
    
    @ExportedProperty
    public boolean isOverflowButton;
    
    @ExportedProperty
    public boolean preventEdgeOffset;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = false;
    }
    
    LayoutParams(int param1Int1, int param1Int2, boolean param1Boolean) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = param1Boolean;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super((ViewGroup.LayoutParams)param1LayoutParams);
      this.isOverflowButton = param1LayoutParams.isOverflowButton;
    }
  }
  
  private class MenuBuilderCallback implements MenuBuilder.Callback {
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      boolean bool;
      if (ActionMenuView.this.mOnMenuItemClickListener != null && ActionMenuView.this.mOnMenuItemClickListener.onMenuItemClick(param1MenuItem)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (ActionMenuView.this.mMenuBuilderCallback != null)
        ActionMenuView.this.mMenuBuilderCallback.onMenuModeChange(param1MenuBuilder); 
    }
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */