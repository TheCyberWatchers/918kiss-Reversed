package androidx.core.internal.view;

import android.view.SubMenu;

public interface SupportSubMenu extends SupportMenu, SubMenu {}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\core\internal\view\SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */