package android.net.http;

class Request {
  Request() {
    throw new RuntimeException("Stub!");
  }
  
  public void handleSslErrorResponse(boolean paramBoolean) {
    throw new RuntimeException("Stub!");
  }
  
  public String toString() {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\android\net\http\Request.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */