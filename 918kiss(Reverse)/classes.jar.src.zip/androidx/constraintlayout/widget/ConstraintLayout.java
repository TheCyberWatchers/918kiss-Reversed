package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.Analyzer;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  static final boolean ALLOWS_EMBEDDED = false;
  
  private static final boolean CACHE_MEASURED_DIMENSION = false;
  
  private static final boolean DEBUG = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-1.1.3";
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  private boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOptimizationLevel = 7;
  
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<ConstraintWidget>(100);
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet);
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    ConstraintWidget constraintWidget;
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view1 = (View)this.mChildrenByIds.get(paramInt);
    View view2 = view1;
    if (view1 == null) {
      view1 = findViewById(paramInt);
      view2 = view1;
      if (view1 != null) {
        view2 = view1;
        if (view1 != this) {
          view2 = view1;
          if (view1.getParent() == this) {
            onViewAdded(view1);
            view2 = view1;
          } 
        } 
      } 
    } 
    if (view2 == this)
      return (ConstraintWidget)this.mLayoutWidget; 
    if (view2 == null) {
      view2 = null;
    } else {
      constraintWidget = ((LayoutParams)view2.getLayoutParams()).widget;
    } 
    return constraintWidget;
  }
  
  private void init(AttributeSet paramAttributeSet) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == R.styleable.ConstraintLayout_Layout_android_minWidth) {
          this.mMinWidth = typedArray.getDimensionPixelOffset(j, this.mMinWidth);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_minHeight) {
          this.mMinHeight = typedArray.getDimensionPixelOffset(j, this.mMinHeight);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
          this.mMaxWidth = typedArray.getDimensionPixelOffset(j, this.mMaxWidth);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
          this.mMaxHeight = typedArray.getDimensionPixelOffset(j, this.mMaxHeight);
        } else if (j == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
          this.mOptimizationLevel = typedArray.getInt(j, this.mOptimizationLevel);
        } else if (j == R.styleable.ConstraintLayout_Layout_constraintSet) {
          j = typedArray.getResourceId(j, 0);
          try {
            ConstraintSet constraintSet = new ConstraintSet();
            this();
            this.mConstraintSet = constraintSet;
            constraintSet.load(getContext(), j);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            this.mConstraintSet = null;
          } 
          this.mConstraintSetId = j;
        } 
      } 
      typedArray.recycle();
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void internalMeasureChildren(int paramInt1, int paramInt2) {
    int i = getPaddingTop() + getPaddingBottom();
    int j = getPaddingLeft() + getPaddingRight();
    int k = getChildCount();
    for (byte b = 0; b < k; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        ConstraintWidget constraintWidget = layoutParams.widget;
        if (!layoutParams.isGuideline && !layoutParams.isHelper) {
          int i1;
          int i2;
          int i3;
          boolean bool;
          constraintWidget.setVisibility(view.getVisibility());
          int m = layoutParams.width;
          int n = layoutParams.height;
          if (layoutParams.horizontalDimensionFixed || layoutParams.verticalDimensionFixed || (!layoutParams.horizontalDimensionFixed && layoutParams.matchConstraintDefaultWidth == 1) || layoutParams.width == -1 || (!layoutParams.verticalDimensionFixed && (layoutParams.matchConstraintDefaultHeight == 1 || layoutParams.height == -1))) {
            i1 = 1;
          } else {
            i1 = 0;
          } 
          if (i1) {
            boolean bool1;
            if (m == 0) {
              i2 = getChildMeasureSpec(paramInt1, j, -2);
              i1 = 1;
            } else if (m == -1) {
              i2 = getChildMeasureSpec(paramInt1, j, -1);
              i1 = 0;
            } else {
              if (m == -2) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              i2 = getChildMeasureSpec(paramInt1, j, m);
            } 
            if (n == 0) {
              i3 = getChildMeasureSpec(paramInt2, i, -2);
              bool = true;
            } else if (n == -1) {
              i3 = getChildMeasureSpec(paramInt2, i, -1);
              bool = false;
            } else {
              if (n == -2) {
                bool = true;
              } else {
                bool = false;
              } 
              i3 = getChildMeasureSpec(paramInt2, i, n);
            } 
            view.measure(i2, i3);
            Metrics metrics = this.mMetrics;
            if (metrics != null)
              metrics.measures++; 
            if (m == -2) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            constraintWidget.setWidthWrapContent(bool1);
            if (n == -2) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            constraintWidget.setHeightWrapContent(bool1);
            i3 = view.getMeasuredWidth();
            i2 = view.getMeasuredHeight();
          } else {
            i1 = 0;
            bool = false;
            i2 = n;
            i3 = m;
          } 
          constraintWidget.setWidth(i3);
          constraintWidget.setHeight(i2);
          if (i1)
            constraintWidget.setWrapWidth(i3); 
          if (bool)
            constraintWidget.setWrapHeight(i2); 
          if (layoutParams.needsBaseline) {
            i1 = view.getBaseline();
            if (i1 != -1)
              constraintWidget.setBaselineDistance(i1); 
          } 
        } 
      } 
    } 
  }
  
  private void internalMeasureDimensions(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: astore_3
    //   2: aload_0
    //   3: invokevirtual getPaddingTop : ()I
    //   6: aload_0
    //   7: invokevirtual getPaddingBottom : ()I
    //   10: iadd
    //   11: istore #4
    //   13: aload_0
    //   14: invokevirtual getPaddingLeft : ()I
    //   17: aload_0
    //   18: invokevirtual getPaddingRight : ()I
    //   21: iadd
    //   22: istore #5
    //   24: aload_0
    //   25: invokevirtual getChildCount : ()I
    //   28: istore #6
    //   30: iconst_0
    //   31: istore #7
    //   33: lconst_1
    //   34: lstore #8
    //   36: iload #7
    //   38: iload #6
    //   40: if_icmpge -> 407
    //   43: aload_3
    //   44: iload #7
    //   46: invokevirtual getChildAt : (I)Landroid/view/View;
    //   49: astore #10
    //   51: aload #10
    //   53: invokevirtual getVisibility : ()I
    //   56: bipush #8
    //   58: if_icmpne -> 64
    //   61: goto -> 401
    //   64: aload #10
    //   66: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   69: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   72: astore #11
    //   74: aload #11
    //   76: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   79: astore #12
    //   81: aload #11
    //   83: getfield isGuideline : Z
    //   86: ifne -> 401
    //   89: aload #11
    //   91: getfield isHelper : Z
    //   94: ifeq -> 100
    //   97: goto -> 401
    //   100: aload #12
    //   102: aload #10
    //   104: invokevirtual getVisibility : ()I
    //   107: invokevirtual setVisibility : (I)V
    //   110: aload #11
    //   112: getfield width : I
    //   115: istore #13
    //   117: aload #11
    //   119: getfield height : I
    //   122: istore #14
    //   124: iload #13
    //   126: ifeq -> 382
    //   129: iload #14
    //   131: ifne -> 137
    //   134: goto -> 382
    //   137: iload #13
    //   139: bipush #-2
    //   141: if_icmpne -> 150
    //   144: iconst_1
    //   145: istore #15
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #15
    //   153: iload_1
    //   154: iload #5
    //   156: iload #13
    //   158: invokestatic getChildMeasureSpec : (III)I
    //   161: istore #16
    //   163: iload #14
    //   165: bipush #-2
    //   167: if_icmpne -> 176
    //   170: iconst_1
    //   171: istore #17
    //   173: goto -> 179
    //   176: iconst_0
    //   177: istore #17
    //   179: aload #10
    //   181: iload #16
    //   183: iload_2
    //   184: iload #4
    //   186: iload #14
    //   188: invokestatic getChildMeasureSpec : (III)I
    //   191: invokevirtual measure : (II)V
    //   194: aload_3
    //   195: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   198: astore #18
    //   200: aload #18
    //   202: ifnull -> 217
    //   205: aload #18
    //   207: aload #18
    //   209: getfield measures : J
    //   212: lconst_1
    //   213: ladd
    //   214: putfield measures : J
    //   217: iload #13
    //   219: bipush #-2
    //   221: if_icmpne -> 230
    //   224: iconst_1
    //   225: istore #19
    //   227: goto -> 233
    //   230: iconst_0
    //   231: istore #19
    //   233: aload #12
    //   235: iload #19
    //   237: invokevirtual setWidthWrapContent : (Z)V
    //   240: iload #14
    //   242: bipush #-2
    //   244: if_icmpne -> 253
    //   247: iconst_1
    //   248: istore #19
    //   250: goto -> 256
    //   253: iconst_0
    //   254: istore #19
    //   256: aload #12
    //   258: iload #19
    //   260: invokevirtual setHeightWrapContent : (Z)V
    //   263: aload #10
    //   265: invokevirtual getMeasuredWidth : ()I
    //   268: istore #13
    //   270: aload #10
    //   272: invokevirtual getMeasuredHeight : ()I
    //   275: istore #14
    //   277: aload #12
    //   279: iload #13
    //   281: invokevirtual setWidth : (I)V
    //   284: aload #12
    //   286: iload #14
    //   288: invokevirtual setHeight : (I)V
    //   291: iload #15
    //   293: ifeq -> 303
    //   296: aload #12
    //   298: iload #13
    //   300: invokevirtual setWrapWidth : (I)V
    //   303: iload #17
    //   305: ifeq -> 315
    //   308: aload #12
    //   310: iload #14
    //   312: invokevirtual setWrapHeight : (I)V
    //   315: aload #11
    //   317: getfield needsBaseline : Z
    //   320: ifeq -> 343
    //   323: aload #10
    //   325: invokevirtual getBaseline : ()I
    //   328: istore #15
    //   330: iload #15
    //   332: iconst_m1
    //   333: if_icmpeq -> 343
    //   336: aload #12
    //   338: iload #15
    //   340: invokevirtual setBaselineDistance : (I)V
    //   343: aload #11
    //   345: getfield horizontalDimensionFixed : Z
    //   348: ifeq -> 401
    //   351: aload #11
    //   353: getfield verticalDimensionFixed : Z
    //   356: ifeq -> 401
    //   359: aload #12
    //   361: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   364: iload #13
    //   366: invokevirtual resolve : (I)V
    //   369: aload #12
    //   371: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   374: iload #14
    //   376: invokevirtual resolve : (I)V
    //   379: goto -> 401
    //   382: aload #12
    //   384: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   387: invokevirtual invalidate : ()V
    //   390: aload #12
    //   392: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   395: invokevirtual invalidate : ()V
    //   398: goto -> 401
    //   401: iinc #7, 1
    //   404: goto -> 33
    //   407: aload_3
    //   408: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   411: invokevirtual solveGraph : ()V
    //   414: iconst_0
    //   415: istore #20
    //   417: iload #20
    //   419: iload #6
    //   421: if_icmpge -> 1293
    //   424: aload_3
    //   425: iload #20
    //   427: invokevirtual getChildAt : (I)Landroid/view/View;
    //   430: astore #10
    //   432: aload #10
    //   434: invokevirtual getVisibility : ()I
    //   437: bipush #8
    //   439: if_icmpne -> 445
    //   442: goto -> 1287
    //   445: aload #10
    //   447: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   450: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   453: astore #18
    //   455: aload #18
    //   457: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   460: astore #12
    //   462: aload #18
    //   464: getfield isGuideline : Z
    //   467: ifne -> 1287
    //   470: aload #18
    //   472: getfield isHelper : Z
    //   475: ifeq -> 481
    //   478: goto -> 1287
    //   481: aload #12
    //   483: aload #10
    //   485: invokevirtual getVisibility : ()I
    //   488: invokevirtual setVisibility : (I)V
    //   491: aload #18
    //   493: getfield width : I
    //   496: istore #13
    //   498: aload #18
    //   500: getfield height : I
    //   503: istore #16
    //   505: iload #13
    //   507: ifeq -> 518
    //   510: iload #16
    //   512: ifeq -> 518
    //   515: goto -> 1287
    //   518: aload #12
    //   520: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   523: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   526: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   529: astore #21
    //   531: aload #12
    //   533: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   536: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   539: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   542: astore #11
    //   544: aload #12
    //   546: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   549: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   552: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   555: ifnull -> 578
    //   558: aload #12
    //   560: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   563: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   566: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   569: ifnull -> 578
    //   572: iconst_1
    //   573: istore #15
    //   575: goto -> 581
    //   578: iconst_0
    //   579: istore #15
    //   581: aload #12
    //   583: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   586: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   589: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   592: astore #22
    //   594: aload #12
    //   596: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   599: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   602: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   605: astore #23
    //   607: aload #12
    //   609: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   612: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   615: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   618: ifnull -> 641
    //   621: aload #12
    //   623: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   626: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   629: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   632: ifnull -> 641
    //   635: iconst_1
    //   636: istore #24
    //   638: goto -> 644
    //   641: iconst_0
    //   642: istore #24
    //   644: iload #13
    //   646: ifne -> 670
    //   649: iload #16
    //   651: ifne -> 670
    //   654: iload #15
    //   656: ifeq -> 670
    //   659: iload #24
    //   661: ifeq -> 670
    //   664: lconst_1
    //   665: lstore #8
    //   667: goto -> 1287
    //   670: aload_3
    //   671: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   674: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   677: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   680: if_acmpeq -> 689
    //   683: iconst_1
    //   684: istore #14
    //   686: goto -> 692
    //   689: iconst_0
    //   690: istore #14
    //   692: aload_3
    //   693: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   696: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   699: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   702: if_acmpeq -> 711
    //   705: iconst_1
    //   706: istore #7
    //   708: goto -> 714
    //   711: iconst_0
    //   712: istore #7
    //   714: iload #14
    //   716: ifne -> 727
    //   719: aload #12
    //   721: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   724: invokevirtual invalidate : ()V
    //   727: iload #7
    //   729: ifne -> 740
    //   732: aload #12
    //   734: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   737: invokevirtual invalidate : ()V
    //   740: iload #13
    //   742: ifne -> 839
    //   745: iload #14
    //   747: ifeq -> 816
    //   750: aload #12
    //   752: invokevirtual isSpreadWidth : ()Z
    //   755: ifeq -> 816
    //   758: iload #15
    //   760: ifeq -> 816
    //   763: aload #21
    //   765: invokevirtual isResolved : ()Z
    //   768: ifeq -> 816
    //   771: aload #11
    //   773: invokevirtual isResolved : ()Z
    //   776: ifeq -> 816
    //   779: aload #11
    //   781: invokevirtual getResolvedValue : ()F
    //   784: aload #21
    //   786: invokevirtual getResolvedValue : ()F
    //   789: fsub
    //   790: f2i
    //   791: istore #13
    //   793: aload #12
    //   795: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   798: iload #13
    //   800: invokevirtual resolve : (I)V
    //   803: iload_1
    //   804: iload #5
    //   806: iload #13
    //   808: invokestatic getChildMeasureSpec : (III)I
    //   811: istore #17
    //   813: goto -> 854
    //   816: iload_1
    //   817: iload #5
    //   819: bipush #-2
    //   821: invokestatic getChildMeasureSpec : (III)I
    //   824: istore #17
    //   826: iconst_0
    //   827: istore #25
    //   829: iconst_1
    //   830: istore #15
    //   832: iload #13
    //   834: istore #26
    //   836: goto -> 902
    //   839: iload #13
    //   841: iconst_m1
    //   842: if_icmpne -> 868
    //   845: iload_1
    //   846: iload #5
    //   848: iconst_m1
    //   849: invokestatic getChildMeasureSpec : (III)I
    //   852: istore #17
    //   854: iconst_0
    //   855: istore #15
    //   857: iload #14
    //   859: istore #25
    //   861: iload #13
    //   863: istore #26
    //   865: goto -> 902
    //   868: iload #13
    //   870: bipush #-2
    //   872: if_icmpne -> 881
    //   875: iconst_1
    //   876: istore #15
    //   878: goto -> 884
    //   881: iconst_0
    //   882: istore #15
    //   884: iload_1
    //   885: iload #5
    //   887: iload #13
    //   889: invokestatic getChildMeasureSpec : (III)I
    //   892: istore #17
    //   894: iload #13
    //   896: istore #26
    //   898: iload #14
    //   900: istore #25
    //   902: iload #16
    //   904: ifne -> 997
    //   907: iload #7
    //   909: ifeq -> 978
    //   912: aload #12
    //   914: invokevirtual isSpreadHeight : ()Z
    //   917: ifeq -> 978
    //   920: iload #24
    //   922: ifeq -> 978
    //   925: aload #22
    //   927: invokevirtual isResolved : ()Z
    //   930: ifeq -> 978
    //   933: aload #23
    //   935: invokevirtual isResolved : ()Z
    //   938: ifeq -> 978
    //   941: aload #23
    //   943: invokevirtual getResolvedValue : ()F
    //   946: aload #22
    //   948: invokevirtual getResolvedValue : ()F
    //   951: fsub
    //   952: f2i
    //   953: istore #16
    //   955: aload #12
    //   957: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   960: iload #16
    //   962: invokevirtual resolve : (I)V
    //   965: iload_2
    //   966: iload #4
    //   968: iload #16
    //   970: invokestatic getChildMeasureSpec : (III)I
    //   973: istore #13
    //   975: goto -> 1012
    //   978: iload_2
    //   979: iload #4
    //   981: bipush #-2
    //   983: invokestatic getChildMeasureSpec : (III)I
    //   986: istore #13
    //   988: iconst_0
    //   989: istore #7
    //   991: iconst_1
    //   992: istore #14
    //   994: goto -> 1044
    //   997: iload #16
    //   999: iconst_m1
    //   1000: if_icmpne -> 1018
    //   1003: iload_2
    //   1004: iload #4
    //   1006: iconst_m1
    //   1007: invokestatic getChildMeasureSpec : (III)I
    //   1010: istore #13
    //   1012: iconst_0
    //   1013: istore #14
    //   1015: goto -> 1044
    //   1018: iload #16
    //   1020: bipush #-2
    //   1022: if_icmpne -> 1031
    //   1025: iconst_1
    //   1026: istore #14
    //   1028: goto -> 1034
    //   1031: iconst_0
    //   1032: istore #14
    //   1034: iload_2
    //   1035: iload #4
    //   1037: iload #16
    //   1039: invokestatic getChildMeasureSpec : (III)I
    //   1042: istore #13
    //   1044: aload #10
    //   1046: iload #17
    //   1048: iload #13
    //   1050: invokevirtual measure : (II)V
    //   1053: aload_0
    //   1054: astore #11
    //   1056: aload #11
    //   1058: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   1061: astore_3
    //   1062: aload_3
    //   1063: ifnull -> 1079
    //   1066: aload_3
    //   1067: aload_3
    //   1068: getfield measures : J
    //   1071: lconst_1
    //   1072: ladd
    //   1073: putfield measures : J
    //   1076: goto -> 1079
    //   1079: lconst_1
    //   1080: lstore #27
    //   1082: iload #26
    //   1084: bipush #-2
    //   1086: if_icmpne -> 1095
    //   1089: iconst_1
    //   1090: istore #19
    //   1092: goto -> 1098
    //   1095: iconst_0
    //   1096: istore #19
    //   1098: aload #12
    //   1100: iload #19
    //   1102: invokevirtual setWidthWrapContent : (Z)V
    //   1105: iload #16
    //   1107: bipush #-2
    //   1109: if_icmpne -> 1118
    //   1112: iconst_1
    //   1113: istore #19
    //   1115: goto -> 1121
    //   1118: iconst_0
    //   1119: istore #19
    //   1121: aload #12
    //   1123: iload #19
    //   1125: invokevirtual setHeightWrapContent : (Z)V
    //   1128: aload #10
    //   1130: invokevirtual getMeasuredWidth : ()I
    //   1133: istore #13
    //   1135: aload #10
    //   1137: invokevirtual getMeasuredHeight : ()I
    //   1140: istore #17
    //   1142: aload #12
    //   1144: iload #13
    //   1146: invokevirtual setWidth : (I)V
    //   1149: aload #12
    //   1151: iload #17
    //   1153: invokevirtual setHeight : (I)V
    //   1156: iload #15
    //   1158: ifeq -> 1168
    //   1161: aload #12
    //   1163: iload #13
    //   1165: invokevirtual setWrapWidth : (I)V
    //   1168: iload #14
    //   1170: ifeq -> 1180
    //   1173: aload #12
    //   1175: iload #17
    //   1177: invokevirtual setWrapHeight : (I)V
    //   1180: iload #25
    //   1182: ifeq -> 1198
    //   1185: aload #12
    //   1187: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1190: iload #13
    //   1192: invokevirtual resolve : (I)V
    //   1195: goto -> 1206
    //   1198: aload #12
    //   1200: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1203: invokevirtual remove : ()V
    //   1206: iload #7
    //   1208: ifeq -> 1224
    //   1211: aload #12
    //   1213: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1216: iload #17
    //   1218: invokevirtual resolve : (I)V
    //   1221: goto -> 1232
    //   1224: aload #12
    //   1226: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1229: invokevirtual remove : ()V
    //   1232: aload #18
    //   1234: getfield needsBaseline : Z
    //   1237: ifeq -> 1277
    //   1240: aload #10
    //   1242: invokevirtual getBaseline : ()I
    //   1245: istore #7
    //   1247: aload #11
    //   1249: astore_3
    //   1250: lload #27
    //   1252: lstore #8
    //   1254: iload #7
    //   1256: iconst_m1
    //   1257: if_icmpeq -> 1287
    //   1260: aload #12
    //   1262: iload #7
    //   1264: invokevirtual setBaselineDistance : (I)V
    //   1267: aload #11
    //   1269: astore_3
    //   1270: lload #27
    //   1272: lstore #8
    //   1274: goto -> 1287
    //   1277: aload #11
    //   1279: astore_3
    //   1280: lload #27
    //   1282: lstore #8
    //   1284: goto -> 1287
    //   1287: iinc #20, 1
    //   1290: goto -> 417
    //   1293: return
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore_1
    //   5: aload_0
    //   6: invokevirtual getChildCount : ()I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_3
    //   12: iload_1
    //   13: ifeq -> 112
    //   16: iconst_0
    //   17: istore #4
    //   19: iload #4
    //   21: iload_2
    //   22: if_icmpge -> 112
    //   25: aload_0
    //   26: iload #4
    //   28: invokevirtual getChildAt : (I)Landroid/view/View;
    //   31: astore #5
    //   33: aload_0
    //   34: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   37: aload #5
    //   39: invokevirtual getId : ()I
    //   42: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   45: astore #6
    //   47: aload_0
    //   48: iconst_0
    //   49: aload #6
    //   51: aload #5
    //   53: invokevirtual getId : ()I
    //   56: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   59: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   62: aload #6
    //   64: bipush #47
    //   66: invokevirtual indexOf : (I)I
    //   69: istore #7
    //   71: aload #6
    //   73: astore #8
    //   75: iload #7
    //   77: iconst_m1
    //   78: if_icmpeq -> 92
    //   81: aload #6
    //   83: iload #7
    //   85: iconst_1
    //   86: iadd
    //   87: invokevirtual substring : (I)Ljava/lang/String;
    //   90: astore #8
    //   92: aload_0
    //   93: aload #5
    //   95: invokevirtual getId : ()I
    //   98: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   101: aload #8
    //   103: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   106: iinc #4, 1
    //   109: goto -> 19
    //   112: iconst_0
    //   113: istore #4
    //   115: iload #4
    //   117: iload_2
    //   118: if_icmpge -> 152
    //   121: aload_0
    //   122: aload_0
    //   123: iload #4
    //   125: invokevirtual getChildAt : (I)Landroid/view/View;
    //   128: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   131: astore #8
    //   133: aload #8
    //   135: ifnonnull -> 141
    //   138: goto -> 146
    //   141: aload #8
    //   143: invokevirtual reset : ()V
    //   146: iinc #4, 1
    //   149: goto -> 115
    //   152: aload_0
    //   153: getfield mConstraintSetId : I
    //   156: iconst_m1
    //   157: if_icmpeq -> 215
    //   160: iconst_0
    //   161: istore #4
    //   163: iload #4
    //   165: iload_2
    //   166: if_icmpge -> 215
    //   169: aload_0
    //   170: iload #4
    //   172: invokevirtual getChildAt : (I)Landroid/view/View;
    //   175: astore #8
    //   177: aload #8
    //   179: invokevirtual getId : ()I
    //   182: aload_0
    //   183: getfield mConstraintSetId : I
    //   186: if_icmpne -> 209
    //   189: aload #8
    //   191: instanceof androidx/constraintlayout/widget/Constraints
    //   194: ifeq -> 209
    //   197: aload_0
    //   198: aload #8
    //   200: checkcast androidx/constraintlayout/widget/Constraints
    //   203: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   206: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   209: iinc #4, 1
    //   212: goto -> 163
    //   215: aload_0
    //   216: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   219: astore #8
    //   221: aload #8
    //   223: ifnull -> 232
    //   226: aload #8
    //   228: aload_0
    //   229: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   232: aload_0
    //   233: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   236: invokevirtual removeAllChildren : ()V
    //   239: aload_0
    //   240: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   243: invokevirtual size : ()I
    //   246: istore #7
    //   248: iload #7
    //   250: ifle -> 285
    //   253: iconst_0
    //   254: istore #4
    //   256: iload #4
    //   258: iload #7
    //   260: if_icmpge -> 285
    //   263: aload_0
    //   264: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   267: iload #4
    //   269: invokevirtual get : (I)Ljava/lang/Object;
    //   272: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   275: aload_0
    //   276: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   279: iinc #4, 1
    //   282: goto -> 256
    //   285: iconst_0
    //   286: istore #4
    //   288: iload #4
    //   290: iload_2
    //   291: if_icmpge -> 325
    //   294: aload_0
    //   295: iload #4
    //   297: invokevirtual getChildAt : (I)Landroid/view/View;
    //   300: astore #8
    //   302: aload #8
    //   304: instanceof androidx/constraintlayout/widget/Placeholder
    //   307: ifeq -> 319
    //   310: aload #8
    //   312: checkcast androidx/constraintlayout/widget/Placeholder
    //   315: aload_0
    //   316: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   319: iinc #4, 1
    //   322: goto -> 288
    //   325: iconst_0
    //   326: istore #9
    //   328: iload_3
    //   329: istore #4
    //   331: iload #9
    //   333: iload_2
    //   334: if_icmpge -> 2042
    //   337: aload_0
    //   338: iload #9
    //   340: invokevirtual getChildAt : (I)Landroid/view/View;
    //   343: astore #5
    //   345: aload_0
    //   346: aload #5
    //   348: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   351: astore #6
    //   353: aload #6
    //   355: ifnonnull -> 365
    //   358: iload #4
    //   360: istore #7
    //   362: goto -> 2032
    //   365: aload #5
    //   367: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   370: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   373: astore #8
    //   375: aload #8
    //   377: invokevirtual validate : ()V
    //   380: aload #8
    //   382: getfield helped : Z
    //   385: ifeq -> 398
    //   388: aload #8
    //   390: iload #4
    //   392: putfield helped : Z
    //   395: goto -> 468
    //   398: iload_1
    //   399: ifeq -> 468
    //   402: aload_0
    //   403: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   406: aload #5
    //   408: invokevirtual getId : ()I
    //   411: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   414: astore #10
    //   416: aload_0
    //   417: iload #4
    //   419: aload #10
    //   421: aload #5
    //   423: invokevirtual getId : ()I
    //   426: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   429: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   432: aload #10
    //   434: aload #10
    //   436: ldc_w 'id/'
    //   439: invokevirtual indexOf : (Ljava/lang/String;)I
    //   442: iconst_3
    //   443: iadd
    //   444: invokevirtual substring : (I)Ljava/lang/String;
    //   447: astore #10
    //   449: aload_0
    //   450: aload #5
    //   452: invokevirtual getId : ()I
    //   455: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   458: aload #10
    //   460: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   463: goto -> 468
    //   466: astore #10
    //   468: aload #6
    //   470: aload #5
    //   472: invokevirtual getVisibility : ()I
    //   475: invokevirtual setVisibility : (I)V
    //   478: aload #8
    //   480: getfield isInPlaceholder : Z
    //   483: ifeq -> 493
    //   486: aload #6
    //   488: bipush #8
    //   490: invokevirtual setVisibility : (I)V
    //   493: aload #6
    //   495: aload #5
    //   497: invokevirtual setCompanionWidget : (Ljava/lang/Object;)V
    //   500: aload_0
    //   501: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   504: aload #6
    //   506: invokevirtual add : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   509: aload #8
    //   511: getfield verticalDimensionFixed : Z
    //   514: ifeq -> 525
    //   517: aload #8
    //   519: getfield horizontalDimensionFixed : Z
    //   522: ifne -> 535
    //   525: aload_0
    //   526: getfield mVariableDimensionsWidgets : Ljava/util/ArrayList;
    //   529: aload #6
    //   531: invokevirtual add : (Ljava/lang/Object;)Z
    //   534: pop
    //   535: aload #8
    //   537: getfield isGuideline : Z
    //   540: ifeq -> 663
    //   543: aload #6
    //   545: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   548: astore #6
    //   550: aload #8
    //   552: getfield resolvedGuideBegin : I
    //   555: istore #7
    //   557: aload #8
    //   559: getfield resolvedGuideEnd : I
    //   562: istore_3
    //   563: aload #8
    //   565: getfield resolvedGuidePercent : F
    //   568: fstore #11
    //   570: getstatic android/os/Build$VERSION.SDK_INT : I
    //   573: bipush #17
    //   575: if_icmpge -> 598
    //   578: aload #8
    //   580: getfield guideBegin : I
    //   583: istore #7
    //   585: aload #8
    //   587: getfield guideEnd : I
    //   590: istore_3
    //   591: aload #8
    //   593: getfield guidePercent : F
    //   596: fstore #11
    //   598: fload #11
    //   600: ldc_w -1.0
    //   603: fcmpl
    //   604: ifeq -> 621
    //   607: aload #6
    //   609: fload #11
    //   611: invokevirtual setGuidePercent : (F)V
    //   614: iload #4
    //   616: istore #7
    //   618: goto -> 2032
    //   621: iload #7
    //   623: iconst_m1
    //   624: if_icmpeq -> 641
    //   627: aload #6
    //   629: iload #7
    //   631: invokevirtual setGuideBegin : (I)V
    //   634: iload #4
    //   636: istore #7
    //   638: goto -> 2032
    //   641: iload #4
    //   643: istore #7
    //   645: iload_3
    //   646: iconst_m1
    //   647: if_icmpeq -> 2032
    //   650: aload #6
    //   652: iload_3
    //   653: invokevirtual setGuideEnd : (I)V
    //   656: iload #4
    //   658: istore #7
    //   660: goto -> 2032
    //   663: aload #8
    //   665: getfield leftToLeft : I
    //   668: iconst_m1
    //   669: if_icmpne -> 829
    //   672: aload #8
    //   674: getfield leftToRight : I
    //   677: iconst_m1
    //   678: if_icmpne -> 829
    //   681: aload #8
    //   683: getfield rightToLeft : I
    //   686: iconst_m1
    //   687: if_icmpne -> 829
    //   690: aload #8
    //   692: getfield rightToRight : I
    //   695: iconst_m1
    //   696: if_icmpne -> 829
    //   699: aload #8
    //   701: getfield startToStart : I
    //   704: iconst_m1
    //   705: if_icmpne -> 829
    //   708: aload #8
    //   710: getfield startToEnd : I
    //   713: iconst_m1
    //   714: if_icmpne -> 829
    //   717: aload #8
    //   719: getfield endToStart : I
    //   722: iconst_m1
    //   723: if_icmpne -> 829
    //   726: aload #8
    //   728: getfield endToEnd : I
    //   731: iconst_m1
    //   732: if_icmpne -> 829
    //   735: aload #8
    //   737: getfield topToTop : I
    //   740: iconst_m1
    //   741: if_icmpne -> 829
    //   744: aload #8
    //   746: getfield topToBottom : I
    //   749: iconst_m1
    //   750: if_icmpne -> 829
    //   753: aload #8
    //   755: getfield bottomToTop : I
    //   758: iconst_m1
    //   759: if_icmpne -> 829
    //   762: aload #8
    //   764: getfield bottomToBottom : I
    //   767: iconst_m1
    //   768: if_icmpne -> 829
    //   771: aload #8
    //   773: getfield baselineToBaseline : I
    //   776: iconst_m1
    //   777: if_icmpne -> 829
    //   780: aload #8
    //   782: getfield editorAbsoluteX : I
    //   785: iconst_m1
    //   786: if_icmpne -> 829
    //   789: aload #8
    //   791: getfield editorAbsoluteY : I
    //   794: iconst_m1
    //   795: if_icmpne -> 829
    //   798: aload #8
    //   800: getfield circleConstraint : I
    //   803: iconst_m1
    //   804: if_icmpne -> 829
    //   807: aload #8
    //   809: getfield width : I
    //   812: iconst_m1
    //   813: if_icmpeq -> 829
    //   816: iload #4
    //   818: istore #7
    //   820: aload #8
    //   822: getfield height : I
    //   825: iconst_m1
    //   826: if_icmpne -> 2032
    //   829: aload #8
    //   831: getfield resolvedLeftToLeft : I
    //   834: istore #12
    //   836: aload #8
    //   838: getfield resolvedLeftToRight : I
    //   841: istore #13
    //   843: aload #8
    //   845: getfield resolvedRightToLeft : I
    //   848: istore #4
    //   850: aload #8
    //   852: getfield resolvedRightToRight : I
    //   855: istore_3
    //   856: aload #8
    //   858: getfield resolveGoneLeftMargin : I
    //   861: istore #14
    //   863: aload #8
    //   865: getfield resolveGoneRightMargin : I
    //   868: istore #15
    //   870: aload #8
    //   872: getfield resolvedHorizontalBias : F
    //   875: fstore #11
    //   877: getstatic android/os/Build$VERSION.SDK_INT : I
    //   880: bipush #17
    //   882: if_icmpge -> 1100
    //   885: aload #8
    //   887: getfield leftToLeft : I
    //   890: istore #12
    //   892: aload #8
    //   894: getfield leftToRight : I
    //   897: istore #7
    //   899: aload #8
    //   901: getfield rightToLeft : I
    //   904: istore #13
    //   906: aload #8
    //   908: getfield rightToRight : I
    //   911: istore #16
    //   913: aload #8
    //   915: getfield goneLeftMargin : I
    //   918: istore #14
    //   920: aload #8
    //   922: getfield goneRightMargin : I
    //   925: istore #15
    //   927: aload #8
    //   929: getfield horizontalBias : F
    //   932: fstore #11
    //   934: iload #12
    //   936: istore #4
    //   938: iload #7
    //   940: istore_3
    //   941: iload #12
    //   943: iconst_m1
    //   944: if_icmpne -> 1008
    //   947: iload #12
    //   949: istore #4
    //   951: iload #7
    //   953: istore_3
    //   954: iload #7
    //   956: iconst_m1
    //   957: if_icmpne -> 1008
    //   960: aload #8
    //   962: getfield startToStart : I
    //   965: iconst_m1
    //   966: if_icmpeq -> 982
    //   969: aload #8
    //   971: getfield startToStart : I
    //   974: istore #4
    //   976: iload #7
    //   978: istore_3
    //   979: goto -> 1008
    //   982: iload #12
    //   984: istore #4
    //   986: iload #7
    //   988: istore_3
    //   989: aload #8
    //   991: getfield startToEnd : I
    //   994: iconst_m1
    //   995: if_icmpeq -> 1008
    //   998: aload #8
    //   1000: getfield startToEnd : I
    //   1003: istore_3
    //   1004: iload #12
    //   1006: istore #4
    //   1008: iload #4
    //   1010: istore #12
    //   1012: iload #13
    //   1014: istore #7
    //   1016: iload #16
    //   1018: istore #4
    //   1020: iload #13
    //   1022: iconst_m1
    //   1023: if_icmpne -> 1091
    //   1026: iload #13
    //   1028: istore #7
    //   1030: iload #16
    //   1032: istore #4
    //   1034: iload #16
    //   1036: iconst_m1
    //   1037: if_icmpne -> 1091
    //   1040: aload #8
    //   1042: getfield endToStart : I
    //   1045: iconst_m1
    //   1046: if_icmpeq -> 1063
    //   1049: aload #8
    //   1051: getfield endToStart : I
    //   1054: istore #7
    //   1056: iload #16
    //   1058: istore #4
    //   1060: goto -> 1091
    //   1063: iload #13
    //   1065: istore #7
    //   1067: iload #16
    //   1069: istore #4
    //   1071: aload #8
    //   1073: getfield endToEnd : I
    //   1076: iconst_m1
    //   1077: if_icmpeq -> 1091
    //   1080: aload #8
    //   1082: getfield endToEnd : I
    //   1085: istore #4
    //   1087: iload #13
    //   1089: istore #7
    //   1091: iload_3
    //   1092: istore #13
    //   1094: iload #4
    //   1096: istore_3
    //   1097: goto -> 1104
    //   1100: iload #4
    //   1102: istore #7
    //   1104: aload #8
    //   1106: getfield circleConstraint : I
    //   1109: iconst_m1
    //   1110: if_icmpeq -> 1149
    //   1113: aload_0
    //   1114: aload #8
    //   1116: getfield circleConstraint : I
    //   1119: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1122: astore #5
    //   1124: aload #5
    //   1126: ifnull -> 1694
    //   1129: aload #6
    //   1131: aload #5
    //   1133: aload #8
    //   1135: getfield circleAngle : F
    //   1138: aload #8
    //   1140: getfield circleRadius : I
    //   1143: invokevirtual connectCircularConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   1146: goto -> 1694
    //   1149: iload #12
    //   1151: iconst_m1
    //   1152: if_icmpeq -> 1194
    //   1155: aload_0
    //   1156: iload #12
    //   1158: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1161: astore #5
    //   1163: aload #5
    //   1165: ifnull -> 1191
    //   1168: aload #6
    //   1170: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1173: aload #5
    //   1175: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1178: aload #8
    //   1180: getfield leftMargin : I
    //   1183: iload #14
    //   1185: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1188: goto -> 1233
    //   1191: goto -> 1233
    //   1194: iload #13
    //   1196: iconst_m1
    //   1197: if_icmpeq -> 1233
    //   1200: aload_0
    //   1201: iload #13
    //   1203: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1206: astore #5
    //   1208: aload #5
    //   1210: ifnull -> 1233
    //   1213: aload #6
    //   1215: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1218: aload #5
    //   1220: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1223: aload #8
    //   1225: getfield leftMargin : I
    //   1228: iload #14
    //   1230: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1233: iload #7
    //   1235: iconst_m1
    //   1236: if_icmpeq -> 1275
    //   1239: aload_0
    //   1240: iload #7
    //   1242: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1245: astore #5
    //   1247: aload #5
    //   1249: ifnull -> 1312
    //   1252: aload #6
    //   1254: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1257: aload #5
    //   1259: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1262: aload #8
    //   1264: getfield rightMargin : I
    //   1267: iload #15
    //   1269: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1272: goto -> 1312
    //   1275: iload_3
    //   1276: iconst_m1
    //   1277: if_icmpeq -> 1312
    //   1280: aload_0
    //   1281: iload_3
    //   1282: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1285: astore #5
    //   1287: aload #5
    //   1289: ifnull -> 1312
    //   1292: aload #6
    //   1294: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1297: aload #5
    //   1299: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1302: aload #8
    //   1304: getfield rightMargin : I
    //   1307: iload #15
    //   1309: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1312: aload #8
    //   1314: getfield topToTop : I
    //   1317: iconst_m1
    //   1318: if_icmpeq -> 1363
    //   1321: aload_0
    //   1322: aload #8
    //   1324: getfield topToTop : I
    //   1327: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1330: astore #5
    //   1332: aload #5
    //   1334: ifnull -> 1411
    //   1337: aload #6
    //   1339: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1342: aload #5
    //   1344: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1347: aload #8
    //   1349: getfield topMargin : I
    //   1352: aload #8
    //   1354: getfield goneTopMargin : I
    //   1357: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1360: goto -> 1411
    //   1363: aload #8
    //   1365: getfield topToBottom : I
    //   1368: iconst_m1
    //   1369: if_icmpeq -> 1411
    //   1372: aload_0
    //   1373: aload #8
    //   1375: getfield topToBottom : I
    //   1378: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1381: astore #5
    //   1383: aload #5
    //   1385: ifnull -> 1411
    //   1388: aload #6
    //   1390: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1393: aload #5
    //   1395: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1398: aload #8
    //   1400: getfield topMargin : I
    //   1403: aload #8
    //   1405: getfield goneTopMargin : I
    //   1408: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1411: aload #8
    //   1413: getfield bottomToTop : I
    //   1416: iconst_m1
    //   1417: if_icmpeq -> 1462
    //   1420: aload_0
    //   1421: aload #8
    //   1423: getfield bottomToTop : I
    //   1426: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1429: astore #5
    //   1431: aload #5
    //   1433: ifnull -> 1510
    //   1436: aload #6
    //   1438: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1441: aload #5
    //   1443: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1446: aload #8
    //   1448: getfield bottomMargin : I
    //   1451: aload #8
    //   1453: getfield goneBottomMargin : I
    //   1456: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1459: goto -> 1510
    //   1462: aload #8
    //   1464: getfield bottomToBottom : I
    //   1467: iconst_m1
    //   1468: if_icmpeq -> 1510
    //   1471: aload_0
    //   1472: aload #8
    //   1474: getfield bottomToBottom : I
    //   1477: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1480: astore #5
    //   1482: aload #5
    //   1484: ifnull -> 1510
    //   1487: aload #6
    //   1489: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1492: aload #5
    //   1494: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1497: aload #8
    //   1499: getfield bottomMargin : I
    //   1502: aload #8
    //   1504: getfield goneBottomMargin : I
    //   1507: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1510: aload #8
    //   1512: getfield baselineToBaseline : I
    //   1515: iconst_m1
    //   1516: if_icmpeq -> 1639
    //   1519: aload_0
    //   1520: getfield mChildrenByIds : Landroid/util/SparseArray;
    //   1523: aload #8
    //   1525: getfield baselineToBaseline : I
    //   1528: invokevirtual get : (I)Ljava/lang/Object;
    //   1531: checkcast android/view/View
    //   1534: astore #10
    //   1536: aload_0
    //   1537: aload #8
    //   1539: getfield baselineToBaseline : I
    //   1542: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1545: astore #5
    //   1547: aload #5
    //   1549: ifnull -> 1639
    //   1552: aload #10
    //   1554: ifnull -> 1639
    //   1557: aload #10
    //   1559: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1562: instanceof androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   1565: ifeq -> 1639
    //   1568: aload #10
    //   1570: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1573: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   1576: astore #10
    //   1578: aload #8
    //   1580: iconst_1
    //   1581: putfield needsBaseline : Z
    //   1584: aload #10
    //   1586: iconst_1
    //   1587: putfield needsBaseline : Z
    //   1590: aload #6
    //   1592: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1595: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1598: aload #5
    //   1600: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1603: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1606: iconst_0
    //   1607: iconst_m1
    //   1608: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength.STRONG : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength;
    //   1611: iconst_0
    //   1612: iconst_1
    //   1613: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IILandroidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength;IZ)Z
    //   1616: pop
    //   1617: aload #6
    //   1619: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1622: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1625: invokevirtual reset : ()V
    //   1628: aload #6
    //   1630: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1633: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1636: invokevirtual reset : ()V
    //   1639: fload #11
    //   1641: fconst_0
    //   1642: fcmpl
    //   1643: iflt -> 1662
    //   1646: fload #11
    //   1648: ldc_w 0.5
    //   1651: fcmpl
    //   1652: ifeq -> 1662
    //   1655: aload #6
    //   1657: fload #11
    //   1659: invokevirtual setHorizontalBiasPercent : (F)V
    //   1662: aload #8
    //   1664: getfield verticalBias : F
    //   1667: fconst_0
    //   1668: fcmpl
    //   1669: iflt -> 1694
    //   1672: aload #8
    //   1674: getfield verticalBias : F
    //   1677: ldc_w 0.5
    //   1680: fcmpl
    //   1681: ifeq -> 1694
    //   1684: aload #6
    //   1686: aload #8
    //   1688: getfield verticalBias : F
    //   1691: invokevirtual setVerticalBiasPercent : (F)V
    //   1694: iload_1
    //   1695: ifeq -> 1731
    //   1698: aload #8
    //   1700: getfield editorAbsoluteX : I
    //   1703: iconst_m1
    //   1704: if_icmpne -> 1716
    //   1707: aload #8
    //   1709: getfield editorAbsoluteY : I
    //   1712: iconst_m1
    //   1713: if_icmpeq -> 1731
    //   1716: aload #6
    //   1718: aload #8
    //   1720: getfield editorAbsoluteX : I
    //   1723: aload #8
    //   1725: getfield editorAbsoluteY : I
    //   1728: invokevirtual setOrigin : (II)V
    //   1731: aload #8
    //   1733: getfield horizontalDimensionFixed : Z
    //   1736: ifne -> 1808
    //   1739: aload #8
    //   1741: getfield width : I
    //   1744: iconst_m1
    //   1745: if_icmpne -> 1791
    //   1748: aload #6
    //   1750: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1753: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1756: aload #6
    //   1758: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1761: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1764: aload #8
    //   1766: getfield leftMargin : I
    //   1769: putfield mMargin : I
    //   1772: aload #6
    //   1774: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1777: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1780: aload #8
    //   1782: getfield rightMargin : I
    //   1785: putfield mMargin : I
    //   1788: goto -> 1826
    //   1791: aload #6
    //   1793: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1796: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1799: aload #6
    //   1801: iconst_0
    //   1802: invokevirtual setWidth : (I)V
    //   1805: goto -> 1826
    //   1808: aload #6
    //   1810: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1813: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1816: aload #6
    //   1818: aload #8
    //   1820: getfield width : I
    //   1823: invokevirtual setWidth : (I)V
    //   1826: aload #8
    //   1828: getfield verticalDimensionFixed : Z
    //   1831: ifne -> 1903
    //   1834: aload #8
    //   1836: getfield height : I
    //   1839: iconst_m1
    //   1840: if_icmpne -> 1886
    //   1843: aload #6
    //   1845: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1848: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1851: aload #6
    //   1853: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1856: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1859: aload #8
    //   1861: getfield topMargin : I
    //   1864: putfield mMargin : I
    //   1867: aload #6
    //   1869: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1872: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1875: aload #8
    //   1877: getfield bottomMargin : I
    //   1880: putfield mMargin : I
    //   1883: goto -> 1921
    //   1886: aload #6
    //   1888: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1891: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1894: aload #6
    //   1896: iconst_0
    //   1897: invokevirtual setHeight : (I)V
    //   1900: goto -> 1921
    //   1903: aload #6
    //   1905: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1908: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1911: aload #6
    //   1913: aload #8
    //   1915: getfield height : I
    //   1918: invokevirtual setHeight : (I)V
    //   1921: iconst_0
    //   1922: istore #7
    //   1924: aload #8
    //   1926: getfield dimensionRatio : Ljava/lang/String;
    //   1929: ifnull -> 1942
    //   1932: aload #6
    //   1934: aload #8
    //   1936: getfield dimensionRatio : Ljava/lang/String;
    //   1939: invokevirtual setDimensionRatio : (Ljava/lang/String;)V
    //   1942: aload #6
    //   1944: aload #8
    //   1946: getfield horizontalWeight : F
    //   1949: invokevirtual setHorizontalWeight : (F)V
    //   1952: aload #6
    //   1954: aload #8
    //   1956: getfield verticalWeight : F
    //   1959: invokevirtual setVerticalWeight : (F)V
    //   1962: aload #6
    //   1964: aload #8
    //   1966: getfield horizontalChainStyle : I
    //   1969: invokevirtual setHorizontalChainStyle : (I)V
    //   1972: aload #6
    //   1974: aload #8
    //   1976: getfield verticalChainStyle : I
    //   1979: invokevirtual setVerticalChainStyle : (I)V
    //   1982: aload #6
    //   1984: aload #8
    //   1986: getfield matchConstraintDefaultWidth : I
    //   1989: aload #8
    //   1991: getfield matchConstraintMinWidth : I
    //   1994: aload #8
    //   1996: getfield matchConstraintMaxWidth : I
    //   1999: aload #8
    //   2001: getfield matchConstraintPercentWidth : F
    //   2004: invokevirtual setHorizontalMatchStyle : (IIIF)V
    //   2007: aload #6
    //   2009: aload #8
    //   2011: getfield matchConstraintDefaultHeight : I
    //   2014: aload #8
    //   2016: getfield matchConstraintMinHeight : I
    //   2019: aload #8
    //   2021: getfield matchConstraintMaxHeight : I
    //   2024: aload #8
    //   2026: getfield matchConstraintPercentHeight : F
    //   2029: invokevirtual setVerticalMatchStyle : (IIIF)V
    //   2032: iinc #9, 1
    //   2035: iload #7
    //   2037: istore #4
    //   2039: goto -> 331
    //   2042: return
    //   2043: astore #8
    //   2045: goto -> 106
    // Exception table:
    //   from	to	target	type
    //   33	71	2043	android/content/res/Resources$NotFoundException
    //   81	92	2043	android/content/res/Resources$NotFoundException
    //   92	106	2043	android/content/res/Resources$NotFoundException
    //   402	463	466	android/content/res/Resources$NotFoundException
  }
  
  private void setSelfDimensionBehaviour(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore_1
    //   10: iload_2
    //   11: invokestatic getMode : (I)I
    //   14: istore #4
    //   16: iload_2
    //   17: invokestatic getSize : (I)I
    //   20: istore_2
    //   21: aload_0
    //   22: invokevirtual getPaddingTop : ()I
    //   25: istore #5
    //   27: aload_0
    //   28: invokevirtual getPaddingBottom : ()I
    //   31: istore #6
    //   33: aload_0
    //   34: invokevirtual getPaddingLeft : ()I
    //   37: istore #7
    //   39: aload_0
    //   40: invokevirtual getPaddingRight : ()I
    //   43: istore #8
    //   45: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   48: astore #9
    //   50: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   53: astore #10
    //   55: aload_0
    //   56: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   59: pop
    //   60: iload_3
    //   61: ldc_w -2147483648
    //   64: if_icmpeq -> 109
    //   67: iload_3
    //   68: ifeq -> 101
    //   71: iload_3
    //   72: ldc_w 1073741824
    //   75: if_icmpeq -> 83
    //   78: iconst_0
    //   79: istore_1
    //   80: goto -> 114
    //   83: aload_0
    //   84: getfield mMaxWidth : I
    //   87: iload_1
    //   88: invokestatic min : (II)I
    //   91: iload #7
    //   93: iload #8
    //   95: iadd
    //   96: isub
    //   97: istore_1
    //   98: goto -> 114
    //   101: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: astore #9
    //   106: goto -> 78
    //   109: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   112: astore #9
    //   114: iload #4
    //   116: ldc_w -2147483648
    //   119: if_icmpeq -> 166
    //   122: iload #4
    //   124: ifeq -> 158
    //   127: iload #4
    //   129: ldc_w 1073741824
    //   132: if_icmpeq -> 140
    //   135: iconst_0
    //   136: istore_2
    //   137: goto -> 171
    //   140: aload_0
    //   141: getfield mMaxHeight : I
    //   144: iload_2
    //   145: invokestatic min : (II)I
    //   148: iload #5
    //   150: iload #6
    //   152: iadd
    //   153: isub
    //   154: istore_2
    //   155: goto -> 171
    //   158: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   161: astore #10
    //   163: goto -> 135
    //   166: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   169: astore #10
    //   171: aload_0
    //   172: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   175: iconst_0
    //   176: invokevirtual setMinWidth : (I)V
    //   179: aload_0
    //   180: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   183: iconst_0
    //   184: invokevirtual setMinHeight : (I)V
    //   187: aload_0
    //   188: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   191: aload #9
    //   193: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   196: aload_0
    //   197: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   200: iload_1
    //   201: invokevirtual setWidth : (I)V
    //   204: aload_0
    //   205: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   208: aload #10
    //   210: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   213: aload_0
    //   214: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   217: iload_2
    //   218: invokevirtual setHeight : (I)V
    //   221: aload_0
    //   222: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   225: aload_0
    //   226: getfield mMinWidth : I
    //   229: aload_0
    //   230: invokevirtual getPaddingLeft : ()I
    //   233: isub
    //   234: aload_0
    //   235: invokevirtual getPaddingRight : ()I
    //   238: isub
    //   239: invokevirtual setMinWidth : (I)V
    //   242: aload_0
    //   243: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   246: aload_0
    //   247: getfield mMinHeight : I
    //   250: aload_0
    //   251: invokevirtual getPaddingTop : ()I
    //   254: isub
    //   255: aload_0
    //   256: invokevirtual getPaddingBottom : ()I
    //   259: isub
    //   260: invokevirtual setMinHeight : (I)V
    //   263: return
  }
  
  private void updateHierarchy() {
    boolean bool2;
    int i = getChildCount();
    boolean bool1 = false;
    byte b = 0;
    while (true) {
      bool2 = bool1;
      if (b < i) {
        if (getChildAt(b).isLayoutRequested()) {
          bool2 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool2) {
      this.mVariableDimensionsWidgets.clear();
      setChildrenConstraints();
    } 
  }
  
  private void updatePostMeasures() {
    int i = getChildCount();
    boolean bool = false;
    byte b;
    for (b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view instanceof Placeholder)
        ((Placeholder)view).updatePostMeasure(this); 
    } 
    i = this.mConstraintHelpers.size();
    if (i > 0)
      for (b = bool; b < i; b++)
        ((ConstraintHelper)this.mConstraintHelpers.get(b)).updatePostMeasure(this);  
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int i = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      for (byte b = 0; b < i; b++) {
        View view = getChildAt(b);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int j = Integer.parseInt((String)object[0]);
              int k = Integer.parseInt((String)object[1]);
              int m = Integer.parseInt((String)object[2]);
              int n = Integer.parseInt((String)object[3]);
              j = (int)(j / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              m = (int)(m / 1080.0F * f1);
              n = (int)(n / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = j;
              float f4 = k;
              float f5 = (j + m);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (k + n);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object<String, Integer> paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      String str = (String)paramObject;
      paramObject = (Object<String, Integer>)this.mDesignIds;
      if (paramObject != null && paramObject.containsKey(str))
        return this.mDesignIds.get(str); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    ConstraintWidget constraintWidget;
    if (paramView == this)
      return (ConstraintWidget)this.mLayoutWidget; 
    if (paramView == null) {
      paramView = null;
    } else {
      constraintWidget = ((LayoutParams)paramView.getLayoutParams()).widget;
    } 
    return constraintWidget;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || paramBoolean) && !layoutParams.isInPlaceholder) {
        int i = constraintWidget.getDrawX();
        int j = constraintWidget.getDrawY();
        int k = constraintWidget.getWidth() + i;
        paramInt4 = constraintWidget.getHeight() + j;
        view.layout(i, j, k, paramInt4);
        if (view instanceof Placeholder) {
          View view1 = ((Placeholder)view).getContent();
          if (view1 != null) {
            view1.setVisibility(0);
            view1.layout(i, j, k, paramInt4);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i4;
    boolean bool;
    System.currentTimeMillis();
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    int m = View.MeasureSpec.getSize(paramInt2);
    int n = getPaddingLeft();
    int i1 = getPaddingTop();
    this.mLayoutWidget.setX(n);
    this.mLayoutWidget.setY(i1);
    this.mLayoutWidget.setMaxWidth(this.mMaxWidth);
    this.mLayoutWidget.setMaxHeight(this.mMaxHeight);
    if (Build.VERSION.SDK_INT >= 17) {
      boolean bool1;
      ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
      if (getLayoutDirection() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      constraintWidgetContainer.setRtl(bool1);
    } 
    setSelfDimensionBehaviour(paramInt1, paramInt2);
    int i2 = this.mLayoutWidget.getWidth();
    int i3 = this.mLayoutWidget.getHeight();
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      updateHierarchy();
      i4 = 1;
    } else {
      i4 = 0;
    } 
    if ((this.mOptimizationLevel & 0x8) == 8) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      this.mLayoutWidget.preOptimize();
      this.mLayoutWidget.optimizeForDimensions(i2, i3);
      internalMeasureDimensions(paramInt1, paramInt2);
    } else {
      internalMeasureChildren(paramInt1, paramInt2);
    } 
    updatePostMeasures();
    if (getChildCount() > 0 && i4)
      Analyzer.determineGroups(this.mLayoutWidget); 
    if (this.mLayoutWidget.mGroupsWrapOptimized) {
      if (this.mLayoutWidget.mHorizontalWrapOptimized && i == Integer.MIN_VALUE) {
        if (this.mLayoutWidget.mWrapFixedWidth < j) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
          constraintWidgetContainer.setWidth(constraintWidgetContainer.mWrapFixedWidth);
        } 
        this.mLayoutWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      } 
      if (this.mLayoutWidget.mVerticalWrapOptimized && k == Integer.MIN_VALUE) {
        if (this.mLayoutWidget.mWrapFixedHeight < m) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
          constraintWidgetContainer.setHeight(constraintWidgetContainer.mWrapFixedHeight);
        } 
        this.mLayoutWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      } 
    } 
    if ((this.mOptimizationLevel & 0x20) == 32) {
      i4 = this.mLayoutWidget.getWidth();
      int i7 = this.mLayoutWidget.getHeight();
      if (this.mLastMeasureWidth != i4 && i == 1073741824)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, i4); 
      if (this.mLastMeasureHeight != i7 && k == 1073741824)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, i7); 
      if (this.mLayoutWidget.mHorizontalWrapOptimized && this.mLayoutWidget.mWrapFixedWidth > j)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, j); 
      if (this.mLayoutWidget.mVerticalWrapOptimized && this.mLayoutWidget.mWrapFixedHeight > m)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, m); 
    } 
    if (getChildCount() > 0)
      solveLinearSystem("First pass"); 
    int i5 = this.mVariableDimensionsWidgets.size();
    m = i1 + getPaddingBottom();
    int i6 = n + getPaddingRight();
    if (i5 > 0) {
      boolean bool1;
      if (this.mLayoutWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        k = 1;
      } else {
        k = 0;
      } 
      if (this.mLayoutWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      i1 = Math.max(this.mLayoutWidget.getWidth(), this.mMinWidth);
      n = Math.max(this.mLayoutWidget.getHeight(), this.mMinHeight);
      byte b = 0;
      i = 0;
      i4 = 0;
      while (b < i5) {
        ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(b);
        View view = (View)constraintWidget.getCompanionWidget();
        if (view != null) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          if (!layoutParams.isHelper && !layoutParams.isGuideline) {
            int i7 = view.getVisibility();
            j = i;
            if (i7 != 8 && (!bool || !constraintWidget.getResolutionWidth().isResolved() || !constraintWidget.getResolutionHeight().isResolved())) {
              if (layoutParams.width == -2 && layoutParams.horizontalDimensionFixed) {
                i = getChildMeasureSpec(paramInt1, i6, layoutParams.width);
              } else {
                i = View.MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824);
              } 
              if (layoutParams.height == -2 && layoutParams.verticalDimensionFixed) {
                i7 = getChildMeasureSpec(paramInt2, m, layoutParams.height);
              } else {
                i7 = View.MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824);
              } 
              view.measure(i, i7);
              Metrics metrics = this.mMetrics;
              if (metrics != null)
                metrics.additionalMeasures++; 
              int i8 = view.getMeasuredWidth();
              i7 = view.getMeasuredHeight();
              i = i1;
              if (i8 != constraintWidget.getWidth()) {
                constraintWidget.setWidth(i8);
                if (bool)
                  constraintWidget.getResolutionWidth().resolve(i8); 
                i = i1;
                if (k != 0) {
                  i = i1;
                  if (constraintWidget.getRight() > i1)
                    i = Math.max(i1, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
                } 
                j = 1;
              } 
              if (i7 != constraintWidget.getHeight()) {
                constraintWidget.setHeight(i7);
                if (bool)
                  constraintWidget.getResolutionHeight().resolve(i7); 
                i1 = n;
                if (bool1) {
                  i1 = n;
                  if (constraintWidget.getBottom() > n)
                    i1 = Math.max(n, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
                } 
                n = i1;
                j = 1;
              } 
              i1 = j;
              if (layoutParams.needsBaseline) {
                i7 = view.getBaseline();
                i1 = j;
                if (i7 != -1) {
                  i1 = j;
                  if (i7 != constraintWidget.getBaselineDistance()) {
                    constraintWidget.setBaselineDistance(i7);
                    i1 = 1;
                  } 
                } 
              } 
              if (Build.VERSION.SDK_INT >= 11)
                i4 = combineMeasuredStates(i4, view.getMeasuredState()); 
              j = i1;
              i1 = i;
              i = j;
            } 
          } 
        } 
        b++;
      } 
      if (i != 0) {
        this.mLayoutWidget.setWidth(i2);
        this.mLayoutWidget.setHeight(i3);
        if (bool)
          this.mLayoutWidget.solveGraph(); 
        solveLinearSystem("2nd pass");
        if (this.mLayoutWidget.getWidth() < i1) {
          this.mLayoutWidget.setWidth(i1);
          i1 = 1;
        } else {
          i1 = 0;
        } 
        if (this.mLayoutWidget.getHeight() < n) {
          this.mLayoutWidget.setHeight(n);
          i1 = 1;
        } 
        if (i1 != 0)
          solveLinearSystem("3rd pass"); 
      } 
      for (n = 0; n < i5; n++) {
        ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(n);
        View view = (View)constraintWidget.getCompanionWidget();
        if (view != null && (view.getMeasuredWidth() != constraintWidget.getWidth() || view.getMeasuredHeight() != constraintWidget.getHeight()) && constraintWidget.getVisibility() != 8) {
          view.measure(View.MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824));
          Metrics metrics = this.mMetrics;
          if (metrics != null)
            metrics.additionalMeasures++; 
        } 
      } 
    } else {
      i4 = 0;
    } 
    i1 = this.mLayoutWidget.getWidth() + i6;
    n = this.mLayoutWidget.getHeight() + m;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = resolveSizeAndState(i1, paramInt1, i4);
      i4 = resolveSizeAndState(n, paramInt2, i4 << 16);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      i4 = Math.min(this.mMaxHeight, i4 & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (this.mLayoutWidget.isWidthMeasuredTooSmall())
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = i4;
      if (this.mLayoutWidget.isHeightMeasuredTooSmall())
        paramInt2 = i4 | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
    } else {
      setMeasuredDimension(i1, n);
      this.mLastMeasureWidth = i1;
      this.mLastMeasureHeight = n;
    } 
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mVariableDimensionsWidgets.remove(constraintWidget);
    this.mDirtyHierarchy = true;
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    super.requestLayout();
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected void solveLinearSystem(String paramString) {
    this.mLayoutWidget.layout();
    Metrics metrics = this.mMetrics;
    if (metrics != null)
      metrics.resolutions++; 
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int END = 7;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public int baselineToBaseline = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = -1;
    
    int resolveGoneRightMargin = -1;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield circleConstraint : I
      //   72: aload_0
      //   73: iconst_0
      //   74: putfield circleRadius : I
      //   77: aload_0
      //   78: fconst_0
      //   79: putfield circleAngle : F
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield startToEnd : I
      //   87: aload_0
      //   88: iconst_m1
      //   89: putfield startToStart : I
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield endToStart : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield endToEnd : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield goneLeftMargin : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield goneTopMargin : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield goneRightMargin : I
      //   117: aload_0
      //   118: iconst_m1
      //   119: putfield goneBottomMargin : I
      //   122: aload_0
      //   123: iconst_m1
      //   124: putfield goneStartMargin : I
      //   127: aload_0
      //   128: iconst_m1
      //   129: putfield goneEndMargin : I
      //   132: aload_0
      //   133: ldc 0.5
      //   135: putfield horizontalBias : F
      //   138: aload_0
      //   139: ldc 0.5
      //   141: putfield verticalBias : F
      //   144: aload_0
      //   145: aconst_null
      //   146: putfield dimensionRatio : Ljava/lang/String;
      //   149: aload_0
      //   150: fconst_0
      //   151: putfield dimensionRatioValue : F
      //   154: aload_0
      //   155: iconst_1
      //   156: putfield dimensionRatioSide : I
      //   159: aload_0
      //   160: ldc -1.0
      //   162: putfield horizontalWeight : F
      //   165: aload_0
      //   166: ldc -1.0
      //   168: putfield verticalWeight : F
      //   171: aload_0
      //   172: iconst_0
      //   173: putfield horizontalChainStyle : I
      //   176: aload_0
      //   177: iconst_0
      //   178: putfield verticalChainStyle : I
      //   181: aload_0
      //   182: iconst_0
      //   183: putfield matchConstraintDefaultWidth : I
      //   186: aload_0
      //   187: iconst_0
      //   188: putfield matchConstraintDefaultHeight : I
      //   191: aload_0
      //   192: iconst_0
      //   193: putfield matchConstraintMinWidth : I
      //   196: aload_0
      //   197: iconst_0
      //   198: putfield matchConstraintMinHeight : I
      //   201: aload_0
      //   202: iconst_0
      //   203: putfield matchConstraintMaxWidth : I
      //   206: aload_0
      //   207: iconst_0
      //   208: putfield matchConstraintMaxHeight : I
      //   211: aload_0
      //   212: fconst_1
      //   213: putfield matchConstraintPercentWidth : F
      //   216: aload_0
      //   217: fconst_1
      //   218: putfield matchConstraintPercentHeight : F
      //   221: aload_0
      //   222: iconst_m1
      //   223: putfield editorAbsoluteX : I
      //   226: aload_0
      //   227: iconst_m1
      //   228: putfield editorAbsoluteY : I
      //   231: aload_0
      //   232: iconst_m1
      //   233: putfield orientation : I
      //   236: aload_0
      //   237: iconst_0
      //   238: putfield constrainedWidth : Z
      //   241: aload_0
      //   242: iconst_0
      //   243: putfield constrainedHeight : Z
      //   246: aload_0
      //   247: iconst_1
      //   248: putfield horizontalDimensionFixed : Z
      //   251: aload_0
      //   252: iconst_1
      //   253: putfield verticalDimensionFixed : Z
      //   256: aload_0
      //   257: iconst_0
      //   258: putfield needsBaseline : Z
      //   261: aload_0
      //   262: iconst_0
      //   263: putfield isGuideline : Z
      //   266: aload_0
      //   267: iconst_0
      //   268: putfield isHelper : Z
      //   271: aload_0
      //   272: iconst_0
      //   273: putfield isInPlaceholder : Z
      //   276: aload_0
      //   277: iconst_m1
      //   278: putfield resolvedLeftToLeft : I
      //   281: aload_0
      //   282: iconst_m1
      //   283: putfield resolvedLeftToRight : I
      //   286: aload_0
      //   287: iconst_m1
      //   288: putfield resolvedRightToLeft : I
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedRightToRight : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolveGoneLeftMargin : I
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolveGoneRightMargin : I
      //   306: aload_0
      //   307: ldc 0.5
      //   309: putfield resolvedHorizontalBias : F
      //   312: aload_0
      //   313: new androidx/constraintlayout/solver/widgets/ConstraintWidget
      //   316: dup
      //   317: invokespecial <init> : ()V
      //   320: putfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   323: aload_0
      //   324: iconst_0
      //   325: putfield helped : Z
      //   328: aload_1
      //   329: aload_2
      //   330: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   333: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   336: astore_1
      //   337: aload_1
      //   338: invokevirtual getIndexCount : ()I
      //   341: istore_3
      //   342: iconst_0
      //   343: istore #4
      //   345: iload #4
      //   347: iload_3
      //   348: if_icmpge -> 2063
      //   351: aload_1
      //   352: iload #4
      //   354: invokevirtual getIndex : (I)I
      //   357: istore #5
      //   359: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   362: iload #5
      //   364: invokevirtual get : (I)I
      //   367: istore #6
      //   369: iload #6
      //   371: tableswitch default -> 536, 1 -> 2043, 2 -> 2005, 3 -> 1988, 4 -> 1942, 5 -> 1925, 6 -> 1908, 7 -> 1891, 8 -> 1853, 9 -> 1815, 10 -> 1777, 11 -> 1739, 12 -> 1701, 13 -> 1663, 14 -> 1625, 15 -> 1587, 16 -> 1549, 17 -> 1511, 18 -> 1473, 19 -> 1435, 20 -> 1397, 21 -> 1380, 22 -> 1363, 23 -> 1346, 24 -> 1329, 25 -> 1312, 26 -> 1295, 27 -> 1278, 28 -> 1261, 29 -> 1244, 30 -> 1227, 31 -> 1193, 32 -> 1159, 33 -> 1117, 34 -> 1075, 35 -> 1054, 36 -> 1012, 37 -> 970, 38 -> 949
      //   536: iload #6
      //   538: tableswitch default -> 580, 44 -> 679, 45 -> 662, 46 -> 645, 47 -> 631, 48 -> 617, 49 -> 600, 50 -> 583
      //   580: goto -> 2057
      //   583: aload_0
      //   584: aload_1
      //   585: iload #5
      //   587: aload_0
      //   588: getfield editorAbsoluteY : I
      //   591: invokevirtual getDimensionPixelOffset : (II)I
      //   594: putfield editorAbsoluteY : I
      //   597: goto -> 2057
      //   600: aload_0
      //   601: aload_1
      //   602: iload #5
      //   604: aload_0
      //   605: getfield editorAbsoluteX : I
      //   608: invokevirtual getDimensionPixelOffset : (II)I
      //   611: putfield editorAbsoluteX : I
      //   614: goto -> 2057
      //   617: aload_0
      //   618: aload_1
      //   619: iload #5
      //   621: iconst_0
      //   622: invokevirtual getInt : (II)I
      //   625: putfield verticalChainStyle : I
      //   628: goto -> 2057
      //   631: aload_0
      //   632: aload_1
      //   633: iload #5
      //   635: iconst_0
      //   636: invokevirtual getInt : (II)I
      //   639: putfield horizontalChainStyle : I
      //   642: goto -> 2057
      //   645: aload_0
      //   646: aload_1
      //   647: iload #5
      //   649: aload_0
      //   650: getfield verticalWeight : F
      //   653: invokevirtual getFloat : (IF)F
      //   656: putfield verticalWeight : F
      //   659: goto -> 2057
      //   662: aload_0
      //   663: aload_1
      //   664: iload #5
      //   666: aload_0
      //   667: getfield horizontalWeight : F
      //   670: invokevirtual getFloat : (IF)F
      //   673: putfield horizontalWeight : F
      //   676: goto -> 2057
      //   679: aload_1
      //   680: iload #5
      //   682: invokevirtual getString : (I)Ljava/lang/String;
      //   685: astore_2
      //   686: aload_0
      //   687: aload_2
      //   688: putfield dimensionRatio : Ljava/lang/String;
      //   691: aload_0
      //   692: ldc_w NaN
      //   695: putfield dimensionRatioValue : F
      //   698: aload_0
      //   699: iconst_m1
      //   700: putfield dimensionRatioSide : I
      //   703: aload_2
      //   704: ifnull -> 2057
      //   707: aload_2
      //   708: invokevirtual length : ()I
      //   711: istore #6
      //   713: aload_0
      //   714: getfield dimensionRatio : Ljava/lang/String;
      //   717: bipush #44
      //   719: invokevirtual indexOf : (I)I
      //   722: istore #5
      //   724: iload #5
      //   726: ifle -> 788
      //   729: iload #5
      //   731: iload #6
      //   733: iconst_1
      //   734: isub
      //   735: if_icmpge -> 788
      //   738: aload_0
      //   739: getfield dimensionRatio : Ljava/lang/String;
      //   742: iconst_0
      //   743: iload #5
      //   745: invokevirtual substring : (II)Ljava/lang/String;
      //   748: astore_2
      //   749: aload_2
      //   750: ldc_w 'W'
      //   753: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   756: ifeq -> 767
      //   759: aload_0
      //   760: iconst_0
      //   761: putfield dimensionRatioSide : I
      //   764: goto -> 782
      //   767: aload_2
      //   768: ldc_w 'H'
      //   771: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   774: ifeq -> 782
      //   777: aload_0
      //   778: iconst_1
      //   779: putfield dimensionRatioSide : I
      //   782: iinc #5, 1
      //   785: goto -> 791
      //   788: iconst_0
      //   789: istore #5
      //   791: aload_0
      //   792: getfield dimensionRatio : Ljava/lang/String;
      //   795: bipush #58
      //   797: invokevirtual indexOf : (I)I
      //   800: istore #7
      //   802: iload #7
      //   804: iflt -> 921
      //   807: iload #7
      //   809: iload #6
      //   811: iconst_1
      //   812: isub
      //   813: if_icmpge -> 921
      //   816: aload_0
      //   817: getfield dimensionRatio : Ljava/lang/String;
      //   820: iload #5
      //   822: iload #7
      //   824: invokevirtual substring : (II)Ljava/lang/String;
      //   827: astore #8
      //   829: aload_0
      //   830: getfield dimensionRatio : Ljava/lang/String;
      //   833: iload #7
      //   835: iconst_1
      //   836: iadd
      //   837: invokevirtual substring : (I)Ljava/lang/String;
      //   840: astore_2
      //   841: aload #8
      //   843: invokevirtual length : ()I
      //   846: ifle -> 2057
      //   849: aload_2
      //   850: invokevirtual length : ()I
      //   853: ifle -> 2057
      //   856: aload #8
      //   858: invokestatic parseFloat : (Ljava/lang/String;)F
      //   861: fstore #9
      //   863: aload_2
      //   864: invokestatic parseFloat : (Ljava/lang/String;)F
      //   867: fstore #10
      //   869: fload #9
      //   871: fconst_0
      //   872: fcmpl
      //   873: ifle -> 2057
      //   876: fload #10
      //   878: fconst_0
      //   879: fcmpl
      //   880: ifle -> 2057
      //   883: aload_0
      //   884: getfield dimensionRatioSide : I
      //   887: iconst_1
      //   888: if_icmpne -> 906
      //   891: aload_0
      //   892: fload #10
      //   894: fload #9
      //   896: fdiv
      //   897: invokestatic abs : (F)F
      //   900: putfield dimensionRatioValue : F
      //   903: goto -> 2057
      //   906: aload_0
      //   907: fload #9
      //   909: fload #10
      //   911: fdiv
      //   912: invokestatic abs : (F)F
      //   915: putfield dimensionRatioValue : F
      //   918: goto -> 2057
      //   921: aload_0
      //   922: getfield dimensionRatio : Ljava/lang/String;
      //   925: iload #5
      //   927: invokevirtual substring : (I)Ljava/lang/String;
      //   930: astore_2
      //   931: aload_2
      //   932: invokevirtual length : ()I
      //   935: ifle -> 2057
      //   938: aload_0
      //   939: aload_2
      //   940: invokestatic parseFloat : (Ljava/lang/String;)F
      //   943: putfield dimensionRatioValue : F
      //   946: goto -> 2057
      //   949: aload_0
      //   950: fconst_0
      //   951: aload_1
      //   952: iload #5
      //   954: aload_0
      //   955: getfield matchConstraintPercentHeight : F
      //   958: invokevirtual getFloat : (IF)F
      //   961: invokestatic max : (FF)F
      //   964: putfield matchConstraintPercentHeight : F
      //   967: goto -> 2057
      //   970: aload_0
      //   971: aload_1
      //   972: iload #5
      //   974: aload_0
      //   975: getfield matchConstraintMaxHeight : I
      //   978: invokevirtual getDimensionPixelSize : (II)I
      //   981: putfield matchConstraintMaxHeight : I
      //   984: goto -> 2057
      //   987: astore_2
      //   988: aload_1
      //   989: iload #5
      //   991: aload_0
      //   992: getfield matchConstraintMaxHeight : I
      //   995: invokevirtual getInt : (II)I
      //   998: bipush #-2
      //   1000: if_icmpne -> 2057
      //   1003: aload_0
      //   1004: bipush #-2
      //   1006: putfield matchConstraintMaxHeight : I
      //   1009: goto -> 2057
      //   1012: aload_0
      //   1013: aload_1
      //   1014: iload #5
      //   1016: aload_0
      //   1017: getfield matchConstraintMinHeight : I
      //   1020: invokevirtual getDimensionPixelSize : (II)I
      //   1023: putfield matchConstraintMinHeight : I
      //   1026: goto -> 2057
      //   1029: astore_2
      //   1030: aload_1
      //   1031: iload #5
      //   1033: aload_0
      //   1034: getfield matchConstraintMinHeight : I
      //   1037: invokevirtual getInt : (II)I
      //   1040: bipush #-2
      //   1042: if_icmpne -> 2057
      //   1045: aload_0
      //   1046: bipush #-2
      //   1048: putfield matchConstraintMinHeight : I
      //   1051: goto -> 2057
      //   1054: aload_0
      //   1055: fconst_0
      //   1056: aload_1
      //   1057: iload #5
      //   1059: aload_0
      //   1060: getfield matchConstraintPercentWidth : F
      //   1063: invokevirtual getFloat : (IF)F
      //   1066: invokestatic max : (FF)F
      //   1069: putfield matchConstraintPercentWidth : F
      //   1072: goto -> 2057
      //   1075: aload_0
      //   1076: aload_1
      //   1077: iload #5
      //   1079: aload_0
      //   1080: getfield matchConstraintMaxWidth : I
      //   1083: invokevirtual getDimensionPixelSize : (II)I
      //   1086: putfield matchConstraintMaxWidth : I
      //   1089: goto -> 2057
      //   1092: astore_2
      //   1093: aload_1
      //   1094: iload #5
      //   1096: aload_0
      //   1097: getfield matchConstraintMaxWidth : I
      //   1100: invokevirtual getInt : (II)I
      //   1103: bipush #-2
      //   1105: if_icmpne -> 2057
      //   1108: aload_0
      //   1109: bipush #-2
      //   1111: putfield matchConstraintMaxWidth : I
      //   1114: goto -> 2057
      //   1117: aload_0
      //   1118: aload_1
      //   1119: iload #5
      //   1121: aload_0
      //   1122: getfield matchConstraintMinWidth : I
      //   1125: invokevirtual getDimensionPixelSize : (II)I
      //   1128: putfield matchConstraintMinWidth : I
      //   1131: goto -> 2057
      //   1134: astore_2
      //   1135: aload_1
      //   1136: iload #5
      //   1138: aload_0
      //   1139: getfield matchConstraintMinWidth : I
      //   1142: invokevirtual getInt : (II)I
      //   1145: bipush #-2
      //   1147: if_icmpne -> 2057
      //   1150: aload_0
      //   1151: bipush #-2
      //   1153: putfield matchConstraintMinWidth : I
      //   1156: goto -> 2057
      //   1159: aload_1
      //   1160: iload #5
      //   1162: iconst_0
      //   1163: invokevirtual getInt : (II)I
      //   1166: istore #5
      //   1168: aload_0
      //   1169: iload #5
      //   1171: putfield matchConstraintDefaultHeight : I
      //   1174: iload #5
      //   1176: iconst_1
      //   1177: if_icmpne -> 2057
      //   1180: ldc_w 'ConstraintLayout'
      //   1183: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1186: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1189: pop
      //   1190: goto -> 2057
      //   1193: aload_1
      //   1194: iload #5
      //   1196: iconst_0
      //   1197: invokevirtual getInt : (II)I
      //   1200: istore #5
      //   1202: aload_0
      //   1203: iload #5
      //   1205: putfield matchConstraintDefaultWidth : I
      //   1208: iload #5
      //   1210: iconst_1
      //   1211: if_icmpne -> 2057
      //   1214: ldc_w 'ConstraintLayout'
      //   1217: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1220: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1223: pop
      //   1224: goto -> 2057
      //   1227: aload_0
      //   1228: aload_1
      //   1229: iload #5
      //   1231: aload_0
      //   1232: getfield verticalBias : F
      //   1235: invokevirtual getFloat : (IF)F
      //   1238: putfield verticalBias : F
      //   1241: goto -> 2057
      //   1244: aload_0
      //   1245: aload_1
      //   1246: iload #5
      //   1248: aload_0
      //   1249: getfield horizontalBias : F
      //   1252: invokevirtual getFloat : (IF)F
      //   1255: putfield horizontalBias : F
      //   1258: goto -> 2057
      //   1261: aload_0
      //   1262: aload_1
      //   1263: iload #5
      //   1265: aload_0
      //   1266: getfield constrainedHeight : Z
      //   1269: invokevirtual getBoolean : (IZ)Z
      //   1272: putfield constrainedHeight : Z
      //   1275: goto -> 2057
      //   1278: aload_0
      //   1279: aload_1
      //   1280: iload #5
      //   1282: aload_0
      //   1283: getfield constrainedWidth : Z
      //   1286: invokevirtual getBoolean : (IZ)Z
      //   1289: putfield constrainedWidth : Z
      //   1292: goto -> 2057
      //   1295: aload_0
      //   1296: aload_1
      //   1297: iload #5
      //   1299: aload_0
      //   1300: getfield goneEndMargin : I
      //   1303: invokevirtual getDimensionPixelSize : (II)I
      //   1306: putfield goneEndMargin : I
      //   1309: goto -> 2057
      //   1312: aload_0
      //   1313: aload_1
      //   1314: iload #5
      //   1316: aload_0
      //   1317: getfield goneStartMargin : I
      //   1320: invokevirtual getDimensionPixelSize : (II)I
      //   1323: putfield goneStartMargin : I
      //   1326: goto -> 2057
      //   1329: aload_0
      //   1330: aload_1
      //   1331: iload #5
      //   1333: aload_0
      //   1334: getfield goneBottomMargin : I
      //   1337: invokevirtual getDimensionPixelSize : (II)I
      //   1340: putfield goneBottomMargin : I
      //   1343: goto -> 2057
      //   1346: aload_0
      //   1347: aload_1
      //   1348: iload #5
      //   1350: aload_0
      //   1351: getfield goneRightMargin : I
      //   1354: invokevirtual getDimensionPixelSize : (II)I
      //   1357: putfield goneRightMargin : I
      //   1360: goto -> 2057
      //   1363: aload_0
      //   1364: aload_1
      //   1365: iload #5
      //   1367: aload_0
      //   1368: getfield goneTopMargin : I
      //   1371: invokevirtual getDimensionPixelSize : (II)I
      //   1374: putfield goneTopMargin : I
      //   1377: goto -> 2057
      //   1380: aload_0
      //   1381: aload_1
      //   1382: iload #5
      //   1384: aload_0
      //   1385: getfield goneLeftMargin : I
      //   1388: invokevirtual getDimensionPixelSize : (II)I
      //   1391: putfield goneLeftMargin : I
      //   1394: goto -> 2057
      //   1397: aload_1
      //   1398: iload #5
      //   1400: aload_0
      //   1401: getfield endToEnd : I
      //   1404: invokevirtual getResourceId : (II)I
      //   1407: istore #6
      //   1409: aload_0
      //   1410: iload #6
      //   1412: putfield endToEnd : I
      //   1415: iload #6
      //   1417: iconst_m1
      //   1418: if_icmpne -> 2057
      //   1421: aload_0
      //   1422: aload_1
      //   1423: iload #5
      //   1425: iconst_m1
      //   1426: invokevirtual getInt : (II)I
      //   1429: putfield endToEnd : I
      //   1432: goto -> 2057
      //   1435: aload_1
      //   1436: iload #5
      //   1438: aload_0
      //   1439: getfield endToStart : I
      //   1442: invokevirtual getResourceId : (II)I
      //   1445: istore #6
      //   1447: aload_0
      //   1448: iload #6
      //   1450: putfield endToStart : I
      //   1453: iload #6
      //   1455: iconst_m1
      //   1456: if_icmpne -> 2057
      //   1459: aload_0
      //   1460: aload_1
      //   1461: iload #5
      //   1463: iconst_m1
      //   1464: invokevirtual getInt : (II)I
      //   1467: putfield endToStart : I
      //   1470: goto -> 2057
      //   1473: aload_1
      //   1474: iload #5
      //   1476: aload_0
      //   1477: getfield startToStart : I
      //   1480: invokevirtual getResourceId : (II)I
      //   1483: istore #6
      //   1485: aload_0
      //   1486: iload #6
      //   1488: putfield startToStart : I
      //   1491: iload #6
      //   1493: iconst_m1
      //   1494: if_icmpne -> 2057
      //   1497: aload_0
      //   1498: aload_1
      //   1499: iload #5
      //   1501: iconst_m1
      //   1502: invokevirtual getInt : (II)I
      //   1505: putfield startToStart : I
      //   1508: goto -> 2057
      //   1511: aload_1
      //   1512: iload #5
      //   1514: aload_0
      //   1515: getfield startToEnd : I
      //   1518: invokevirtual getResourceId : (II)I
      //   1521: istore #6
      //   1523: aload_0
      //   1524: iload #6
      //   1526: putfield startToEnd : I
      //   1529: iload #6
      //   1531: iconst_m1
      //   1532: if_icmpne -> 2057
      //   1535: aload_0
      //   1536: aload_1
      //   1537: iload #5
      //   1539: iconst_m1
      //   1540: invokevirtual getInt : (II)I
      //   1543: putfield startToEnd : I
      //   1546: goto -> 2057
      //   1549: aload_1
      //   1550: iload #5
      //   1552: aload_0
      //   1553: getfield baselineToBaseline : I
      //   1556: invokevirtual getResourceId : (II)I
      //   1559: istore #6
      //   1561: aload_0
      //   1562: iload #6
      //   1564: putfield baselineToBaseline : I
      //   1567: iload #6
      //   1569: iconst_m1
      //   1570: if_icmpne -> 2057
      //   1573: aload_0
      //   1574: aload_1
      //   1575: iload #5
      //   1577: iconst_m1
      //   1578: invokevirtual getInt : (II)I
      //   1581: putfield baselineToBaseline : I
      //   1584: goto -> 2057
      //   1587: aload_1
      //   1588: iload #5
      //   1590: aload_0
      //   1591: getfield bottomToBottom : I
      //   1594: invokevirtual getResourceId : (II)I
      //   1597: istore #6
      //   1599: aload_0
      //   1600: iload #6
      //   1602: putfield bottomToBottom : I
      //   1605: iload #6
      //   1607: iconst_m1
      //   1608: if_icmpne -> 2057
      //   1611: aload_0
      //   1612: aload_1
      //   1613: iload #5
      //   1615: iconst_m1
      //   1616: invokevirtual getInt : (II)I
      //   1619: putfield bottomToBottom : I
      //   1622: goto -> 2057
      //   1625: aload_1
      //   1626: iload #5
      //   1628: aload_0
      //   1629: getfield bottomToTop : I
      //   1632: invokevirtual getResourceId : (II)I
      //   1635: istore #6
      //   1637: aload_0
      //   1638: iload #6
      //   1640: putfield bottomToTop : I
      //   1643: iload #6
      //   1645: iconst_m1
      //   1646: if_icmpne -> 2057
      //   1649: aload_0
      //   1650: aload_1
      //   1651: iload #5
      //   1653: iconst_m1
      //   1654: invokevirtual getInt : (II)I
      //   1657: putfield bottomToTop : I
      //   1660: goto -> 2057
      //   1663: aload_1
      //   1664: iload #5
      //   1666: aload_0
      //   1667: getfield topToBottom : I
      //   1670: invokevirtual getResourceId : (II)I
      //   1673: istore #6
      //   1675: aload_0
      //   1676: iload #6
      //   1678: putfield topToBottom : I
      //   1681: iload #6
      //   1683: iconst_m1
      //   1684: if_icmpne -> 2057
      //   1687: aload_0
      //   1688: aload_1
      //   1689: iload #5
      //   1691: iconst_m1
      //   1692: invokevirtual getInt : (II)I
      //   1695: putfield topToBottom : I
      //   1698: goto -> 2057
      //   1701: aload_1
      //   1702: iload #5
      //   1704: aload_0
      //   1705: getfield topToTop : I
      //   1708: invokevirtual getResourceId : (II)I
      //   1711: istore #6
      //   1713: aload_0
      //   1714: iload #6
      //   1716: putfield topToTop : I
      //   1719: iload #6
      //   1721: iconst_m1
      //   1722: if_icmpne -> 2057
      //   1725: aload_0
      //   1726: aload_1
      //   1727: iload #5
      //   1729: iconst_m1
      //   1730: invokevirtual getInt : (II)I
      //   1733: putfield topToTop : I
      //   1736: goto -> 2057
      //   1739: aload_1
      //   1740: iload #5
      //   1742: aload_0
      //   1743: getfield rightToRight : I
      //   1746: invokevirtual getResourceId : (II)I
      //   1749: istore #6
      //   1751: aload_0
      //   1752: iload #6
      //   1754: putfield rightToRight : I
      //   1757: iload #6
      //   1759: iconst_m1
      //   1760: if_icmpne -> 2057
      //   1763: aload_0
      //   1764: aload_1
      //   1765: iload #5
      //   1767: iconst_m1
      //   1768: invokevirtual getInt : (II)I
      //   1771: putfield rightToRight : I
      //   1774: goto -> 2057
      //   1777: aload_1
      //   1778: iload #5
      //   1780: aload_0
      //   1781: getfield rightToLeft : I
      //   1784: invokevirtual getResourceId : (II)I
      //   1787: istore #6
      //   1789: aload_0
      //   1790: iload #6
      //   1792: putfield rightToLeft : I
      //   1795: iload #6
      //   1797: iconst_m1
      //   1798: if_icmpne -> 2057
      //   1801: aload_0
      //   1802: aload_1
      //   1803: iload #5
      //   1805: iconst_m1
      //   1806: invokevirtual getInt : (II)I
      //   1809: putfield rightToLeft : I
      //   1812: goto -> 2057
      //   1815: aload_1
      //   1816: iload #5
      //   1818: aload_0
      //   1819: getfield leftToRight : I
      //   1822: invokevirtual getResourceId : (II)I
      //   1825: istore #6
      //   1827: aload_0
      //   1828: iload #6
      //   1830: putfield leftToRight : I
      //   1833: iload #6
      //   1835: iconst_m1
      //   1836: if_icmpne -> 2057
      //   1839: aload_0
      //   1840: aload_1
      //   1841: iload #5
      //   1843: iconst_m1
      //   1844: invokevirtual getInt : (II)I
      //   1847: putfield leftToRight : I
      //   1850: goto -> 2057
      //   1853: aload_1
      //   1854: iload #5
      //   1856: aload_0
      //   1857: getfield leftToLeft : I
      //   1860: invokevirtual getResourceId : (II)I
      //   1863: istore #6
      //   1865: aload_0
      //   1866: iload #6
      //   1868: putfield leftToLeft : I
      //   1871: iload #6
      //   1873: iconst_m1
      //   1874: if_icmpne -> 2057
      //   1877: aload_0
      //   1878: aload_1
      //   1879: iload #5
      //   1881: iconst_m1
      //   1882: invokevirtual getInt : (II)I
      //   1885: putfield leftToLeft : I
      //   1888: goto -> 2057
      //   1891: aload_0
      //   1892: aload_1
      //   1893: iload #5
      //   1895: aload_0
      //   1896: getfield guidePercent : F
      //   1899: invokevirtual getFloat : (IF)F
      //   1902: putfield guidePercent : F
      //   1905: goto -> 2057
      //   1908: aload_0
      //   1909: aload_1
      //   1910: iload #5
      //   1912: aload_0
      //   1913: getfield guideEnd : I
      //   1916: invokevirtual getDimensionPixelOffset : (II)I
      //   1919: putfield guideEnd : I
      //   1922: goto -> 2057
      //   1925: aload_0
      //   1926: aload_1
      //   1927: iload #5
      //   1929: aload_0
      //   1930: getfield guideBegin : I
      //   1933: invokevirtual getDimensionPixelOffset : (II)I
      //   1936: putfield guideBegin : I
      //   1939: goto -> 2057
      //   1942: aload_1
      //   1943: iload #5
      //   1945: aload_0
      //   1946: getfield circleAngle : F
      //   1949: invokevirtual getFloat : (IF)F
      //   1952: ldc_w 360.0
      //   1955: frem
      //   1956: fstore #9
      //   1958: aload_0
      //   1959: fload #9
      //   1961: putfield circleAngle : F
      //   1964: fload #9
      //   1966: fconst_0
      //   1967: fcmpg
      //   1968: ifge -> 2057
      //   1971: aload_0
      //   1972: ldc_w 360.0
      //   1975: fload #9
      //   1977: fsub
      //   1978: ldc_w 360.0
      //   1981: frem
      //   1982: putfield circleAngle : F
      //   1985: goto -> 2057
      //   1988: aload_0
      //   1989: aload_1
      //   1990: iload #5
      //   1992: aload_0
      //   1993: getfield circleRadius : I
      //   1996: invokevirtual getDimensionPixelSize : (II)I
      //   1999: putfield circleRadius : I
      //   2002: goto -> 2057
      //   2005: aload_1
      //   2006: iload #5
      //   2008: aload_0
      //   2009: getfield circleConstraint : I
      //   2012: invokevirtual getResourceId : (II)I
      //   2015: istore #6
      //   2017: aload_0
      //   2018: iload #6
      //   2020: putfield circleConstraint : I
      //   2023: iload #6
      //   2025: iconst_m1
      //   2026: if_icmpne -> 2057
      //   2029: aload_0
      //   2030: aload_1
      //   2031: iload #5
      //   2033: iconst_m1
      //   2034: invokevirtual getInt : (II)I
      //   2037: putfield circleConstraint : I
      //   2040: goto -> 2057
      //   2043: aload_0
      //   2044: aload_1
      //   2045: iload #5
      //   2047: aload_0
      //   2048: getfield orientation : I
      //   2051: invokevirtual getInt : (II)I
      //   2054: putfield orientation : I
      //   2057: iinc #4, 1
      //   2060: goto -> 345
      //   2063: aload_1
      //   2064: invokevirtual recycle : ()V
      //   2067: aload_0
      //   2068: invokevirtual validate : ()V
      //   2071: return
      //   2072: astore_2
      //   2073: goto -> 2057
      // Exception table:
      //   from	to	target	type
      //   856	869	2072	java/lang/NumberFormatException
      //   883	903	2072	java/lang/NumberFormatException
      //   906	918	2072	java/lang/NumberFormatException
      //   938	946	2072	java/lang/NumberFormatException
      //   970	984	987	java/lang/Exception
      //   1012	1026	1029	java/lang/Exception
      //   1075	1089	1092	java/lang/Exception
      //   1117	1131	1134	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.widget = param1LayoutParams.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore_2
      //   5: aload_0
      //   6: getfield rightMargin : I
      //   9: istore_3
      //   10: aload_0
      //   11: iload_1
      //   12: invokespecial resolveLayoutDirection : (I)V
      //   15: aload_0
      //   16: iconst_m1
      //   17: putfield resolvedRightToLeft : I
      //   20: aload_0
      //   21: iconst_m1
      //   22: putfield resolvedRightToRight : I
      //   25: aload_0
      //   26: iconst_m1
      //   27: putfield resolvedLeftToLeft : I
      //   30: aload_0
      //   31: iconst_m1
      //   32: putfield resolvedLeftToRight : I
      //   35: aload_0
      //   36: iconst_m1
      //   37: putfield resolveGoneLeftMargin : I
      //   40: aload_0
      //   41: iconst_m1
      //   42: putfield resolveGoneRightMargin : I
      //   45: aload_0
      //   46: aload_0
      //   47: getfield goneLeftMargin : I
      //   50: putfield resolveGoneLeftMargin : I
      //   53: aload_0
      //   54: aload_0
      //   55: getfield goneRightMargin : I
      //   58: putfield resolveGoneRightMargin : I
      //   61: aload_0
      //   62: aload_0
      //   63: getfield horizontalBias : F
      //   66: putfield resolvedHorizontalBias : F
      //   69: aload_0
      //   70: aload_0
      //   71: getfield guideBegin : I
      //   74: putfield resolvedGuideBegin : I
      //   77: aload_0
      //   78: aload_0
      //   79: getfield guideEnd : I
      //   82: putfield resolvedGuideEnd : I
      //   85: aload_0
      //   86: aload_0
      //   87: getfield guidePercent : F
      //   90: putfield resolvedGuidePercent : F
      //   93: aload_0
      //   94: invokevirtual getLayoutDirection : ()I
      //   97: istore_1
      //   98: iconst_0
      //   99: istore #4
      //   101: iconst_1
      //   102: iload_1
      //   103: if_icmpne -> 111
      //   106: iconst_1
      //   107: istore_1
      //   108: goto -> 113
      //   111: iconst_0
      //   112: istore_1
      //   113: iload_1
      //   114: ifeq -> 359
      //   117: aload_0
      //   118: getfield startToEnd : I
      //   121: istore_1
      //   122: iload_1
      //   123: iconst_m1
      //   124: if_icmpeq -> 137
      //   127: aload_0
      //   128: iload_1
      //   129: putfield resolvedRightToLeft : I
      //   132: iconst_1
      //   133: istore_1
      //   134: goto -> 161
      //   137: aload_0
      //   138: getfield startToStart : I
      //   141: istore #5
      //   143: iload #4
      //   145: istore_1
      //   146: iload #5
      //   148: iconst_m1
      //   149: if_icmpeq -> 161
      //   152: aload_0
      //   153: iload #5
      //   155: putfield resolvedRightToRight : I
      //   158: goto -> 132
      //   161: aload_0
      //   162: getfield endToStart : I
      //   165: istore #4
      //   167: iload #4
      //   169: iconst_m1
      //   170: if_icmpeq -> 181
      //   173: aload_0
      //   174: iload #4
      //   176: putfield resolvedLeftToRight : I
      //   179: iconst_1
      //   180: istore_1
      //   181: aload_0
      //   182: getfield endToEnd : I
      //   185: istore #4
      //   187: iload #4
      //   189: iconst_m1
      //   190: if_icmpeq -> 201
      //   193: aload_0
      //   194: iload #4
      //   196: putfield resolvedLeftToLeft : I
      //   199: iconst_1
      //   200: istore_1
      //   201: aload_0
      //   202: getfield goneStartMargin : I
      //   205: istore #4
      //   207: iload #4
      //   209: iconst_m1
      //   210: if_icmpeq -> 219
      //   213: aload_0
      //   214: iload #4
      //   216: putfield resolveGoneRightMargin : I
      //   219: aload_0
      //   220: getfield goneEndMargin : I
      //   223: istore #4
      //   225: iload #4
      //   227: iconst_m1
      //   228: if_icmpeq -> 237
      //   231: aload_0
      //   232: iload #4
      //   234: putfield resolveGoneLeftMargin : I
      //   237: iload_1
      //   238: ifeq -> 251
      //   241: aload_0
      //   242: fconst_1
      //   243: aload_0
      //   244: getfield horizontalBias : F
      //   247: fsub
      //   248: putfield resolvedHorizontalBias : F
      //   251: aload_0
      //   252: getfield isGuideline : Z
      //   255: ifeq -> 449
      //   258: aload_0
      //   259: getfield orientation : I
      //   262: iconst_1
      //   263: if_icmpne -> 449
      //   266: aload_0
      //   267: getfield guidePercent : F
      //   270: fstore #6
      //   272: fload #6
      //   274: ldc -1.0
      //   276: fcmpl
      //   277: ifeq -> 301
      //   280: aload_0
      //   281: fconst_1
      //   282: fload #6
      //   284: fsub
      //   285: putfield resolvedGuidePercent : F
      //   288: aload_0
      //   289: iconst_m1
      //   290: putfield resolvedGuideBegin : I
      //   293: aload_0
      //   294: iconst_m1
      //   295: putfield resolvedGuideEnd : I
      //   298: goto -> 449
      //   301: aload_0
      //   302: getfield guideBegin : I
      //   305: istore_1
      //   306: iload_1
      //   307: iconst_m1
      //   308: if_icmpeq -> 330
      //   311: aload_0
      //   312: iload_1
      //   313: putfield resolvedGuideEnd : I
      //   316: aload_0
      //   317: iconst_m1
      //   318: putfield resolvedGuideBegin : I
      //   321: aload_0
      //   322: ldc -1.0
      //   324: putfield resolvedGuidePercent : F
      //   327: goto -> 449
      //   330: aload_0
      //   331: getfield guideEnd : I
      //   334: istore_1
      //   335: iload_1
      //   336: iconst_m1
      //   337: if_icmpeq -> 449
      //   340: aload_0
      //   341: iload_1
      //   342: putfield resolvedGuideBegin : I
      //   345: aload_0
      //   346: iconst_m1
      //   347: putfield resolvedGuideEnd : I
      //   350: aload_0
      //   351: ldc -1.0
      //   353: putfield resolvedGuidePercent : F
      //   356: goto -> 449
      //   359: aload_0
      //   360: getfield startToEnd : I
      //   363: istore_1
      //   364: iload_1
      //   365: iconst_m1
      //   366: if_icmpeq -> 374
      //   369: aload_0
      //   370: iload_1
      //   371: putfield resolvedLeftToRight : I
      //   374: aload_0
      //   375: getfield startToStart : I
      //   378: istore_1
      //   379: iload_1
      //   380: iconst_m1
      //   381: if_icmpeq -> 389
      //   384: aload_0
      //   385: iload_1
      //   386: putfield resolvedLeftToLeft : I
      //   389: aload_0
      //   390: getfield endToStart : I
      //   393: istore_1
      //   394: iload_1
      //   395: iconst_m1
      //   396: if_icmpeq -> 404
      //   399: aload_0
      //   400: iload_1
      //   401: putfield resolvedRightToLeft : I
      //   404: aload_0
      //   405: getfield endToEnd : I
      //   408: istore_1
      //   409: iload_1
      //   410: iconst_m1
      //   411: if_icmpeq -> 419
      //   414: aload_0
      //   415: iload_1
      //   416: putfield resolvedRightToRight : I
      //   419: aload_0
      //   420: getfield goneStartMargin : I
      //   423: istore_1
      //   424: iload_1
      //   425: iconst_m1
      //   426: if_icmpeq -> 434
      //   429: aload_0
      //   430: iload_1
      //   431: putfield resolveGoneLeftMargin : I
      //   434: aload_0
      //   435: getfield goneEndMargin : I
      //   438: istore_1
      //   439: iload_1
      //   440: iconst_m1
      //   441: if_icmpeq -> 449
      //   444: aload_0
      //   445: iload_1
      //   446: putfield resolveGoneRightMargin : I
      //   449: aload_0
      //   450: getfield endToStart : I
      //   453: iconst_m1
      //   454: if_icmpne -> 611
      //   457: aload_0
      //   458: getfield endToEnd : I
      //   461: iconst_m1
      //   462: if_icmpne -> 611
      //   465: aload_0
      //   466: getfield startToStart : I
      //   469: iconst_m1
      //   470: if_icmpne -> 611
      //   473: aload_0
      //   474: getfield startToEnd : I
      //   477: iconst_m1
      //   478: if_icmpne -> 611
      //   481: aload_0
      //   482: getfield rightToLeft : I
      //   485: istore_1
      //   486: iload_1
      //   487: iconst_m1
      //   488: if_icmpeq -> 515
      //   491: aload_0
      //   492: iload_1
      //   493: putfield resolvedRightToLeft : I
      //   496: aload_0
      //   497: getfield rightMargin : I
      //   500: ifgt -> 546
      //   503: iload_3
      //   504: ifle -> 546
      //   507: aload_0
      //   508: iload_3
      //   509: putfield rightMargin : I
      //   512: goto -> 546
      //   515: aload_0
      //   516: getfield rightToRight : I
      //   519: istore_1
      //   520: iload_1
      //   521: iconst_m1
      //   522: if_icmpeq -> 546
      //   525: aload_0
      //   526: iload_1
      //   527: putfield resolvedRightToRight : I
      //   530: aload_0
      //   531: getfield rightMargin : I
      //   534: ifgt -> 546
      //   537: iload_3
      //   538: ifle -> 546
      //   541: aload_0
      //   542: iload_3
      //   543: putfield rightMargin : I
      //   546: aload_0
      //   547: getfield leftToLeft : I
      //   550: istore_1
      //   551: iload_1
      //   552: iconst_m1
      //   553: if_icmpeq -> 580
      //   556: aload_0
      //   557: iload_1
      //   558: putfield resolvedLeftToLeft : I
      //   561: aload_0
      //   562: getfield leftMargin : I
      //   565: ifgt -> 611
      //   568: iload_2
      //   569: ifle -> 611
      //   572: aload_0
      //   573: iload_2
      //   574: putfield leftMargin : I
      //   577: goto -> 611
      //   580: aload_0
      //   581: getfield leftToRight : I
      //   584: istore_1
      //   585: iload_1
      //   586: iconst_m1
      //   587: if_icmpeq -> 611
      //   590: aload_0
      //   591: iload_1
      //   592: putfield resolvedLeftToRight : I
      //   595: aload_0
      //   596: getfield leftMargin : I
      //   599: ifgt -> 611
      //   602: iload_2
      //   603: ifle -> 611
      //   606: aload_0
      //   607: iload_2
      //   608: putfield leftMargin : I
      //   611: return
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        this.matchConstraintDefaultWidth = 1;
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        this.matchConstraintDefaultHeight = 1;
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        map = sparseIntArray;
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      map = sparseIntArray;
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
    }
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */