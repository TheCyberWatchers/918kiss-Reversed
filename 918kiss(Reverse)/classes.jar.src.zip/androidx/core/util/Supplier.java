package androidx.core.util;

public interface Supplier<T> {
  T get();
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\cor\\util\Supplier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */