package androidx.appcompat.widget;

public interface WithHint {
  CharSequence getHint();
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\appcompat\widget\WithHint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */