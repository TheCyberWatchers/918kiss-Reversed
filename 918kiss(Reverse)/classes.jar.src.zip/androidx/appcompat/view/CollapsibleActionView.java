package androidx.appcompat.view;

@Deprecated
public interface CollapsibleActionView {
  void onActionViewCollapsed();
  
  void onActionViewExpanded();
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\appcompat\view\CollapsibleActionView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */