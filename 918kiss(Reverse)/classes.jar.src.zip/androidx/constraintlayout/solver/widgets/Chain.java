package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;

class Chain {
  private static final boolean DEBUG = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt) {
    int i;
    ChainHead[] arrayOfChainHead;
    byte b2;
    byte b1 = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b2 = 0;
    } else {
      b2 = 2;
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
    } 
    while (b1 < i) {
      ChainHead chainHead = arrayOfChainHead[b1];
      chainHead.define();
      if (paramConstraintWidgetContainer.optimizeFor(4)) {
        if (!Optimizer.applyChainOptimized(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead))
          applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead); 
      } else {
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead);
      } 
      b1++;
    } 
  }
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: aload #4
    //   2: getfield mFirst : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   5: astore #5
    //   7: aload #4
    //   9: getfield mLast : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   12: astore #6
    //   14: aload #4
    //   16: getfield mFirstVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   19: astore #7
    //   21: aload #4
    //   23: getfield mLastVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   26: astore #8
    //   28: aload #4
    //   30: getfield mHead : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   33: astore #9
    //   35: aload #4
    //   37: getfield mTotalWeight : F
    //   40: fstore #10
    //   42: aload #4
    //   44: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   47: astore #11
    //   49: aload #4
    //   51: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #11
    //   56: aload_0
    //   57: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   60: iload_2
    //   61: aaload
    //   62: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   65: if_acmpne -> 74
    //   68: iconst_1
    //   69: istore #12
    //   71: goto -> 77
    //   74: iconst_0
    //   75: istore #12
    //   77: iload_2
    //   78: ifne -> 136
    //   81: aload #9
    //   83: getfield mHorizontalChainStyle : I
    //   86: ifne -> 95
    //   89: iconst_1
    //   90: istore #13
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #13
    //   98: aload #9
    //   100: getfield mHorizontalChainStyle : I
    //   103: iconst_1
    //   104: if_icmpne -> 113
    //   107: iconst_1
    //   108: istore #14
    //   110: goto -> 116
    //   113: iconst_0
    //   114: istore #14
    //   116: iload #13
    //   118: istore #15
    //   120: iload #14
    //   122: istore #16
    //   124: aload #9
    //   126: getfield mHorizontalChainStyle : I
    //   129: iconst_2
    //   130: if_icmpne -> 198
    //   133: goto -> 188
    //   136: aload #9
    //   138: getfield mVerticalChainStyle : I
    //   141: ifne -> 150
    //   144: iconst_1
    //   145: istore #13
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #13
    //   153: aload #9
    //   155: getfield mVerticalChainStyle : I
    //   158: iconst_1
    //   159: if_icmpne -> 168
    //   162: iconst_1
    //   163: istore #14
    //   165: goto -> 171
    //   168: iconst_0
    //   169: istore #14
    //   171: iload #13
    //   173: istore #15
    //   175: iload #14
    //   177: istore #16
    //   179: aload #9
    //   181: getfield mVerticalChainStyle : I
    //   184: iconst_2
    //   185: if_icmpne -> 198
    //   188: iconst_1
    //   189: istore #17
    //   191: iload #13
    //   193: istore #15
    //   195: goto -> 205
    //   198: iconst_0
    //   199: istore #17
    //   201: iload #16
    //   203: istore #14
    //   205: aload #5
    //   207: astore #18
    //   209: iload #15
    //   211: istore #16
    //   213: iconst_0
    //   214: istore #13
    //   216: iload #14
    //   218: istore #15
    //   220: aconst_null
    //   221: astore #19
    //   223: aconst_null
    //   224: astore #20
    //   226: iload #13
    //   228: ifne -> 610
    //   231: aload #18
    //   233: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   236: iload_3
    //   237: aaload
    //   238: astore #11
    //   240: iload #12
    //   242: ifne -> 259
    //   245: iload #17
    //   247: ifeq -> 253
    //   250: goto -> 259
    //   253: iconst_4
    //   254: istore #14
    //   256: goto -> 262
    //   259: iconst_1
    //   260: istore #14
    //   262: aload #11
    //   264: invokevirtual getMargin : ()I
    //   267: istore #21
    //   269: iload #21
    //   271: istore #22
    //   273: aload #11
    //   275: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   278: ifnull -> 305
    //   281: iload #21
    //   283: istore #22
    //   285: aload #18
    //   287: aload #5
    //   289: if_acmpeq -> 305
    //   292: iload #21
    //   294: aload #11
    //   296: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   299: invokevirtual getMargin : ()I
    //   302: iadd
    //   303: istore #22
    //   305: iload #17
    //   307: ifeq -> 331
    //   310: aload #18
    //   312: aload #5
    //   314: if_acmpeq -> 331
    //   317: aload #18
    //   319: aload #7
    //   321: if_acmpeq -> 331
    //   324: bipush #6
    //   326: istore #14
    //   328: goto -> 347
    //   331: iload #16
    //   333: ifeq -> 347
    //   336: iload #12
    //   338: ifeq -> 347
    //   341: iconst_4
    //   342: istore #14
    //   344: goto -> 347
    //   347: aload #11
    //   349: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   352: ifnull -> 431
    //   355: aload #18
    //   357: aload #7
    //   359: if_acmpne -> 385
    //   362: aload_1
    //   363: aload #11
    //   365: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   368: aload #11
    //   370: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   373: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   376: iload #22
    //   378: iconst_5
    //   379: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   382: goto -> 406
    //   385: aload_1
    //   386: aload #11
    //   388: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   391: aload #11
    //   393: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   396: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   399: iload #22
    //   401: bipush #6
    //   403: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   406: aload_1
    //   407: aload #11
    //   409: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   412: aload #11
    //   414: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   417: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   420: iload #22
    //   422: iload #14
    //   424: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   427: pop
    //   428: goto -> 431
    //   431: iload #12
    //   433: ifeq -> 516
    //   436: aload #18
    //   438: invokevirtual getVisibility : ()I
    //   441: bipush #8
    //   443: if_icmpeq -> 490
    //   446: aload #18
    //   448: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   451: iload_2
    //   452: aaload
    //   453: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   456: if_acmpne -> 490
    //   459: aload_1
    //   460: aload #18
    //   462: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   465: iload_3
    //   466: iconst_1
    //   467: iadd
    //   468: aaload
    //   469: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   472: aload #18
    //   474: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   477: iload_3
    //   478: aaload
    //   479: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   482: iconst_0
    //   483: iconst_5
    //   484: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   487: goto -> 490
    //   490: aload_1
    //   491: aload #18
    //   493: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   496: iload_3
    //   497: aaload
    //   498: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   501: aload_0
    //   502: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   505: iload_3
    //   506: aaload
    //   507: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   510: iconst_0
    //   511: bipush #6
    //   513: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   516: aload #18
    //   518: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   521: iload_3
    //   522: iconst_1
    //   523: iadd
    //   524: aaload
    //   525: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   528: astore #23
    //   530: aload #20
    //   532: astore #11
    //   534: aload #23
    //   536: ifnull -> 592
    //   539: aload #23
    //   541: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   544: astore #23
    //   546: aload #20
    //   548: astore #11
    //   550: aload #23
    //   552: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   555: iload_3
    //   556: aaload
    //   557: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   560: ifnull -> 592
    //   563: aload #23
    //   565: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   568: iload_3
    //   569: aaload
    //   570: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   573: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   576: aload #18
    //   578: if_acmpeq -> 588
    //   581: aload #20
    //   583: astore #11
    //   585: goto -> 592
    //   588: aload #23
    //   590: astore #11
    //   592: aload #11
    //   594: ifnull -> 604
    //   597: aload #11
    //   599: astore #18
    //   601: goto -> 607
    //   604: iconst_1
    //   605: istore #13
    //   607: goto -> 220
    //   610: aload #8
    //   612: ifnull -> 681
    //   615: aload #6
    //   617: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   620: astore #11
    //   622: iload_3
    //   623: iconst_1
    //   624: iadd
    //   625: istore #13
    //   627: aload #11
    //   629: iload #13
    //   631: aaload
    //   632: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   635: ifnull -> 681
    //   638: aload #8
    //   640: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   643: iload #13
    //   645: aaload
    //   646: astore #11
    //   648: aload_1
    //   649: aload #11
    //   651: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   654: aload #6
    //   656: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   659: iload #13
    //   661: aaload
    //   662: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   665: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   668: aload #11
    //   670: invokevirtual getMargin : ()I
    //   673: ineg
    //   674: iconst_5
    //   675: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   678: goto -> 681
    //   681: iload #12
    //   683: ifeq -> 731
    //   686: aload_0
    //   687: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   690: astore_0
    //   691: iload_3
    //   692: iconst_1
    //   693: iadd
    //   694: istore #13
    //   696: aload_1
    //   697: aload_0
    //   698: iload #13
    //   700: aaload
    //   701: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   704: aload #6
    //   706: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   709: iload #13
    //   711: aaload
    //   712: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   715: aload #6
    //   717: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   720: iload #13
    //   722: aaload
    //   723: invokevirtual getMargin : ()I
    //   726: bipush #6
    //   728: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   731: aload #4
    //   733: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   736: astore_0
    //   737: aload_0
    //   738: ifnull -> 1030
    //   741: aload_0
    //   742: invokevirtual size : ()I
    //   745: istore #14
    //   747: iload #14
    //   749: iconst_1
    //   750: if_icmple -> 1030
    //   753: aload #4
    //   755: getfield mHasUndefinedWeights : Z
    //   758: ifeq -> 780
    //   761: aload #4
    //   763: getfield mHasComplexMatchWeights : Z
    //   766: ifne -> 780
    //   769: aload #4
    //   771: getfield mWidgetsMatchCount : I
    //   774: i2f
    //   775: fstore #24
    //   777: goto -> 784
    //   780: fload #10
    //   782: fstore #24
    //   784: aconst_null
    //   785: astore #11
    //   787: iconst_0
    //   788: istore #13
    //   790: fconst_0
    //   791: fstore #25
    //   793: iload #13
    //   795: iload #14
    //   797: if_icmpge -> 1030
    //   800: aload_0
    //   801: iload #13
    //   803: invokevirtual get : (I)Ljava/lang/Object;
    //   806: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   809: astore #18
    //   811: aload #18
    //   813: getfield mWeight : [F
    //   816: iload_2
    //   817: faload
    //   818: fstore #10
    //   820: fload #10
    //   822: fconst_0
    //   823: fcmpg
    //   824: ifge -> 873
    //   827: aload #4
    //   829: getfield mHasComplexMatchWeights : Z
    //   832: ifeq -> 867
    //   835: aload_1
    //   836: aload #18
    //   838: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   841: iload_3
    //   842: iconst_1
    //   843: iadd
    //   844: aaload
    //   845: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   848: aload #18
    //   850: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   853: iload_3
    //   854: aaload
    //   855: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   858: iconst_0
    //   859: iconst_4
    //   860: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   863: pop
    //   864: goto -> 910
    //   867: fconst_1
    //   868: fstore #10
    //   870: goto -> 873
    //   873: fload #10
    //   875: fconst_0
    //   876: fcmpl
    //   877: ifne -> 917
    //   880: aload_1
    //   881: aload #18
    //   883: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   886: iload_3
    //   887: iconst_1
    //   888: iadd
    //   889: aaload
    //   890: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   893: aload #18
    //   895: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   898: iload_3
    //   899: aaload
    //   900: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   903: iconst_0
    //   904: bipush #6
    //   906: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   909: pop
    //   910: fload #25
    //   912: fstore #10
    //   914: goto -> 1020
    //   917: aload #11
    //   919: ifnull -> 1016
    //   922: aload #11
    //   924: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   927: iload_3
    //   928: aaload
    //   929: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   932: astore #20
    //   934: aload #11
    //   936: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   939: astore #11
    //   941: iload_3
    //   942: iconst_1
    //   943: iadd
    //   944: istore #12
    //   946: aload #11
    //   948: iload #12
    //   950: aaload
    //   951: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   954: astore #26
    //   956: aload #18
    //   958: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   961: iload_3
    //   962: aaload
    //   963: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   966: astore #11
    //   968: aload #18
    //   970: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   973: iload #12
    //   975: aaload
    //   976: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   979: astore #23
    //   981: aload_1
    //   982: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   985: astore #27
    //   987: aload #27
    //   989: fload #25
    //   991: fload #24
    //   993: fload #10
    //   995: aload #20
    //   997: aload #26
    //   999: aload #11
    //   1001: aload #23
    //   1003: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/ArrayRow;
    //   1006: pop
    //   1007: aload_1
    //   1008: aload #27
    //   1010: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   1013: goto -> 1016
    //   1016: aload #18
    //   1018: astore #11
    //   1020: iinc #13, 1
    //   1023: fload #10
    //   1025: fstore #25
    //   1027: goto -> 793
    //   1030: aload #7
    //   1032: ifnull -> 1236
    //   1035: aload #7
    //   1037: aload #8
    //   1039: if_acmpeq -> 1047
    //   1042: iload #17
    //   1044: ifeq -> 1236
    //   1047: aload #5
    //   1049: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1052: iload_3
    //   1053: aaload
    //   1054: astore #18
    //   1056: aload #6
    //   1058: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1061: astore_0
    //   1062: iload_3
    //   1063: iconst_1
    //   1064: iadd
    //   1065: istore #13
    //   1067: aload_0
    //   1068: iload #13
    //   1070: aaload
    //   1071: astore #11
    //   1073: aload #5
    //   1075: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1078: iload_3
    //   1079: aaload
    //   1080: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1083: ifnull -> 1103
    //   1086: aload #5
    //   1088: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1091: iload_3
    //   1092: aaload
    //   1093: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1096: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1099: astore_0
    //   1100: goto -> 1105
    //   1103: aconst_null
    //   1104: astore_0
    //   1105: aload #6
    //   1107: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1110: iload #13
    //   1112: aaload
    //   1113: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1116: ifnull -> 1138
    //   1119: aload #6
    //   1121: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1124: iload #13
    //   1126: aaload
    //   1127: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1130: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1133: astore #4
    //   1135: goto -> 1141
    //   1138: aconst_null
    //   1139: astore #4
    //   1141: aload #7
    //   1143: aload #8
    //   1145: if_acmpne -> 1167
    //   1148: aload #7
    //   1150: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1153: iload_3
    //   1154: aaload
    //   1155: astore #18
    //   1157: aload #7
    //   1159: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1162: iload #13
    //   1164: aaload
    //   1165: astore #11
    //   1167: aload_0
    //   1168: ifnull -> 2307
    //   1171: aload #4
    //   1173: ifnull -> 2307
    //   1176: iload_2
    //   1177: ifne -> 1190
    //   1180: aload #9
    //   1182: getfield mHorizontalBiasPercent : F
    //   1185: fstore #10
    //   1187: goto -> 1197
    //   1190: aload #9
    //   1192: getfield mVerticalBiasPercent : F
    //   1195: fstore #10
    //   1197: aload #18
    //   1199: invokevirtual getMargin : ()I
    //   1202: istore_2
    //   1203: aload #11
    //   1205: invokevirtual getMargin : ()I
    //   1208: istore #13
    //   1210: aload_1
    //   1211: aload #18
    //   1213: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1216: aload_0
    //   1217: iload_2
    //   1218: fload #10
    //   1220: aload #4
    //   1222: aload #11
    //   1224: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1227: iload #13
    //   1229: iconst_5
    //   1230: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1233: goto -> 2307
    //   1236: iload #16
    //   1238: ifeq -> 1736
    //   1241: aload #7
    //   1243: ifnull -> 1736
    //   1246: aload #4
    //   1248: getfield mWidgetsMatchCount : I
    //   1251: ifle -> 1273
    //   1254: aload #4
    //   1256: getfield mWidgetsCount : I
    //   1259: aload #4
    //   1261: getfield mWidgetsMatchCount : I
    //   1264: if_icmpne -> 1273
    //   1267: iconst_1
    //   1268: istore #12
    //   1270: goto -> 1276
    //   1273: iconst_0
    //   1274: istore #12
    //   1276: aload #7
    //   1278: astore #4
    //   1280: aload #4
    //   1282: astore #18
    //   1284: aload #4
    //   1286: ifnull -> 2307
    //   1289: aload #4
    //   1291: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1294: iload_2
    //   1295: aaload
    //   1296: astore #11
    //   1298: aload #11
    //   1300: ifnull -> 1325
    //   1303: aload #11
    //   1305: invokevirtual getVisibility : ()I
    //   1308: bipush #8
    //   1310: if_icmpne -> 1325
    //   1313: aload #11
    //   1315: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1318: iload_2
    //   1319: aaload
    //   1320: astore #11
    //   1322: goto -> 1298
    //   1325: aload #11
    //   1327: ifnonnull -> 1343
    //   1330: aload #4
    //   1332: aload #8
    //   1334: if_acmpne -> 1340
    //   1337: goto -> 1343
    //   1340: goto -> 1715
    //   1343: aload #4
    //   1345: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1348: iload_3
    //   1349: aaload
    //   1350: astore #20
    //   1352: aload #20
    //   1354: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1357: astore #26
    //   1359: aload #20
    //   1361: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1364: ifnull -> 1380
    //   1367: aload #20
    //   1369: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1372: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1375: astore #9
    //   1377: goto -> 1383
    //   1380: aconst_null
    //   1381: astore #9
    //   1383: aload #18
    //   1385: aload #4
    //   1387: if_acmpeq -> 1406
    //   1390: aload #18
    //   1392: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1395: iload_3
    //   1396: iconst_1
    //   1397: iadd
    //   1398: aaload
    //   1399: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1402: astore_0
    //   1403: goto -> 1458
    //   1406: aload #9
    //   1408: astore_0
    //   1409: aload #4
    //   1411: aload #7
    //   1413: if_acmpne -> 1458
    //   1416: aload #9
    //   1418: astore_0
    //   1419: aload #18
    //   1421: aload #4
    //   1423: if_acmpne -> 1458
    //   1426: aload #5
    //   1428: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1431: iload_3
    //   1432: aaload
    //   1433: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1436: ifnull -> 1456
    //   1439: aload #5
    //   1441: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1444: iload_3
    //   1445: aaload
    //   1446: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1449: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1452: astore_0
    //   1453: goto -> 1458
    //   1456: aconst_null
    //   1457: astore_0
    //   1458: aload #20
    //   1460: invokevirtual getMargin : ()I
    //   1463: istore #17
    //   1465: aload #4
    //   1467: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1470: astore #9
    //   1472: iload_3
    //   1473: iconst_1
    //   1474: iadd
    //   1475: istore #22
    //   1477: aload #9
    //   1479: iload #22
    //   1481: aaload
    //   1482: invokevirtual getMargin : ()I
    //   1485: istore #14
    //   1487: aload #11
    //   1489: ifnull -> 1524
    //   1492: aload #11
    //   1494: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1497: iload_3
    //   1498: aaload
    //   1499: astore #9
    //   1501: aload #9
    //   1503: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1506: astore #23
    //   1508: aload #4
    //   1510: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1513: iload #22
    //   1515: aaload
    //   1516: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1519: astore #20
    //   1521: goto -> 1576
    //   1524: aload #6
    //   1526: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1529: iload #22
    //   1531: aaload
    //   1532: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1535: astore #27
    //   1537: aload #27
    //   1539: ifnull -> 1552
    //   1542: aload #27
    //   1544: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1547: astore #9
    //   1549: goto -> 1555
    //   1552: aconst_null
    //   1553: astore #9
    //   1555: aload #4
    //   1557: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1560: iload #22
    //   1562: aaload
    //   1563: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1566: astore #20
    //   1568: aload #9
    //   1570: astore #23
    //   1572: aload #27
    //   1574: astore #9
    //   1576: iload #14
    //   1578: istore #13
    //   1580: aload #9
    //   1582: ifnull -> 1595
    //   1585: iload #14
    //   1587: aload #9
    //   1589: invokevirtual getMargin : ()I
    //   1592: iadd
    //   1593: istore #13
    //   1595: iload #17
    //   1597: istore #14
    //   1599: aload #18
    //   1601: ifnull -> 1620
    //   1604: iload #17
    //   1606: aload #18
    //   1608: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1611: iload #22
    //   1613: aaload
    //   1614: invokevirtual getMargin : ()I
    //   1617: iadd
    //   1618: istore #14
    //   1620: aload #26
    //   1622: ifnull -> 1340
    //   1625: aload_0
    //   1626: ifnull -> 1340
    //   1629: aload #23
    //   1631: ifnull -> 1340
    //   1634: aload #20
    //   1636: ifnull -> 1340
    //   1639: aload #4
    //   1641: aload #7
    //   1643: if_acmpne -> 1658
    //   1646: aload #7
    //   1648: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1651: iload_3
    //   1652: aaload
    //   1653: invokevirtual getMargin : ()I
    //   1656: istore #14
    //   1658: aload #4
    //   1660: aload #8
    //   1662: if_acmpne -> 1681
    //   1665: aload #8
    //   1667: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1670: iload #22
    //   1672: aaload
    //   1673: invokevirtual getMargin : ()I
    //   1676: istore #13
    //   1678: goto -> 1681
    //   1681: iload #12
    //   1683: ifeq -> 1693
    //   1686: bipush #6
    //   1688: istore #17
    //   1690: goto -> 1696
    //   1693: iconst_4
    //   1694: istore #17
    //   1696: aload_1
    //   1697: aload #26
    //   1699: aload_0
    //   1700: iload #14
    //   1702: ldc 0.5
    //   1704: aload #23
    //   1706: aload #20
    //   1708: iload #13
    //   1710: iload #17
    //   1712: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1715: aload #4
    //   1717: invokevirtual getVisibility : ()I
    //   1720: bipush #8
    //   1722: if_icmpeq -> 1729
    //   1725: aload #4
    //   1727: astore #18
    //   1729: aload #11
    //   1731: astore #4
    //   1733: goto -> 1284
    //   1736: iload #15
    //   1738: ifeq -> 2307
    //   1741: aload #7
    //   1743: ifnull -> 2307
    //   1746: aload #4
    //   1748: getfield mWidgetsMatchCount : I
    //   1751: ifle -> 1773
    //   1754: aload #4
    //   1756: getfield mWidgetsCount : I
    //   1759: aload #4
    //   1761: getfield mWidgetsMatchCount : I
    //   1764: if_icmpne -> 1773
    //   1767: iconst_1
    //   1768: istore #13
    //   1770: goto -> 1776
    //   1773: iconst_0
    //   1774: istore #13
    //   1776: aload #7
    //   1778: astore #11
    //   1780: aload #11
    //   1782: astore #4
    //   1784: aload #11
    //   1786: ifnull -> 2147
    //   1789: aload #11
    //   1791: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1794: iload_2
    //   1795: aaload
    //   1796: astore_0
    //   1797: aload_0
    //   1798: ifnull -> 1820
    //   1801: aload_0
    //   1802: invokevirtual getVisibility : ()I
    //   1805: bipush #8
    //   1807: if_icmpne -> 1820
    //   1810: aload_0
    //   1811: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1814: iload_2
    //   1815: aaload
    //   1816: astore_0
    //   1817: goto -> 1797
    //   1820: aload #11
    //   1822: aload #7
    //   1824: if_acmpeq -> 2120
    //   1827: aload #11
    //   1829: aload #8
    //   1831: if_acmpeq -> 2120
    //   1834: aload_0
    //   1835: ifnull -> 2120
    //   1838: aload_0
    //   1839: aload #8
    //   1841: if_acmpne -> 1849
    //   1844: aconst_null
    //   1845: astore_0
    //   1846: goto -> 1849
    //   1849: aload #11
    //   1851: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1854: iload_3
    //   1855: aaload
    //   1856: astore #9
    //   1858: aload #9
    //   1860: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1863: astore #23
    //   1865: aload #9
    //   1867: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1870: ifnull -> 1883
    //   1873: aload #9
    //   1875: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1878: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1881: astore #18
    //   1883: aload #4
    //   1885: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1888: astore #18
    //   1890: iload_3
    //   1891: iconst_1
    //   1892: iadd
    //   1893: istore #22
    //   1895: aload #18
    //   1897: iload #22
    //   1899: aaload
    //   1900: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1903: astore #27
    //   1905: aload #9
    //   1907: invokevirtual getMargin : ()I
    //   1910: istore #17
    //   1912: aload #11
    //   1914: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1917: iload #22
    //   1919: aaload
    //   1920: invokevirtual getMargin : ()I
    //   1923: istore #12
    //   1925: aload_0
    //   1926: ifnull -> 1971
    //   1929: aload_0
    //   1930: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1933: iload_3
    //   1934: aaload
    //   1935: astore #20
    //   1937: aload #20
    //   1939: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1942: astore #18
    //   1944: aload #20
    //   1946: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1949: ifnull -> 1965
    //   1952: aload #20
    //   1954: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1957: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1960: astore #9
    //   1962: goto -> 2015
    //   1965: aconst_null
    //   1966: astore #9
    //   1968: goto -> 2015
    //   1971: aload #11
    //   1973: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1976: iload #22
    //   1978: aaload
    //   1979: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1982: astore #20
    //   1984: aload #20
    //   1986: ifnull -> 1999
    //   1989: aload #20
    //   1991: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1994: astore #18
    //   1996: goto -> 2002
    //   1999: aconst_null
    //   2000: astore #18
    //   2002: aload #11
    //   2004: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2007: iload #22
    //   2009: aaload
    //   2010: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2013: astore #9
    //   2015: iload #12
    //   2017: istore #14
    //   2019: aload #20
    //   2021: ifnull -> 2034
    //   2024: iload #12
    //   2026: aload #20
    //   2028: invokevirtual getMargin : ()I
    //   2031: iadd
    //   2032: istore #14
    //   2034: iload #17
    //   2036: istore #12
    //   2038: aload #4
    //   2040: ifnull -> 2059
    //   2043: iload #17
    //   2045: aload #4
    //   2047: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2050: iload #22
    //   2052: aaload
    //   2053: invokevirtual getMargin : ()I
    //   2056: iadd
    //   2057: istore #12
    //   2059: iload #13
    //   2061: ifeq -> 2071
    //   2064: bipush #6
    //   2066: istore #17
    //   2068: goto -> 2074
    //   2071: iconst_4
    //   2072: istore #17
    //   2074: aload #23
    //   2076: ifnull -> 2117
    //   2079: aload #27
    //   2081: ifnull -> 2117
    //   2084: aload #18
    //   2086: ifnull -> 2117
    //   2089: aload #9
    //   2091: ifnull -> 2117
    //   2094: aload_1
    //   2095: aload #23
    //   2097: aload #27
    //   2099: iload #12
    //   2101: ldc 0.5
    //   2103: aload #18
    //   2105: aload #9
    //   2107: iload #14
    //   2109: iload #17
    //   2111: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2114: goto -> 2117
    //   2117: goto -> 2120
    //   2120: aload #11
    //   2122: invokevirtual getVisibility : ()I
    //   2125: bipush #8
    //   2127: if_icmpeq -> 2133
    //   2130: goto -> 2137
    //   2133: aload #4
    //   2135: astore #11
    //   2137: aload #11
    //   2139: astore #4
    //   2141: aload_0
    //   2142: astore #11
    //   2144: goto -> 1784
    //   2147: aload #7
    //   2149: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2152: iload_3
    //   2153: aaload
    //   2154: astore_0
    //   2155: aload #5
    //   2157: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2160: iload_3
    //   2161: aaload
    //   2162: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2165: astore #4
    //   2167: aload #8
    //   2169: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2172: astore #11
    //   2174: iload_3
    //   2175: iconst_1
    //   2176: iadd
    //   2177: istore_2
    //   2178: aload #11
    //   2180: iload_2
    //   2181: aaload
    //   2182: astore #9
    //   2184: aload #6
    //   2186: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2189: iload_2
    //   2190: aaload
    //   2191: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2194: astore #11
    //   2196: aload #4
    //   2198: ifnull -> 2273
    //   2201: aload #7
    //   2203: aload #8
    //   2205: if_acmpeq -> 2230
    //   2208: aload_1
    //   2209: aload_0
    //   2210: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2213: aload #4
    //   2215: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2218: aload_0
    //   2219: invokevirtual getMargin : ()I
    //   2222: iconst_5
    //   2223: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2226: pop
    //   2227: goto -> 2273
    //   2230: aload #11
    //   2232: ifnull -> 2273
    //   2235: aload_1
    //   2236: aload_0
    //   2237: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2240: aload #4
    //   2242: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2245: aload_0
    //   2246: invokevirtual getMargin : ()I
    //   2249: ldc 0.5
    //   2251: aload #9
    //   2253: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2256: aload #11
    //   2258: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2261: aload #9
    //   2263: invokevirtual getMargin : ()I
    //   2266: iconst_5
    //   2267: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2270: goto -> 2273
    //   2273: aload #11
    //   2275: ifnull -> 2307
    //   2278: aload #7
    //   2280: aload #8
    //   2282: if_acmpeq -> 2307
    //   2285: aload_1
    //   2286: aload #9
    //   2288: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2291: aload #11
    //   2293: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2296: aload #9
    //   2298: invokevirtual getMargin : ()I
    //   2301: ineg
    //   2302: iconst_5
    //   2303: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2306: pop
    //   2307: iload #16
    //   2309: ifne -> 2317
    //   2312: iload #15
    //   2314: ifeq -> 2525
    //   2317: aload #7
    //   2319: ifnull -> 2525
    //   2322: aload #7
    //   2324: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2327: iload_3
    //   2328: aaload
    //   2329: astore #11
    //   2331: aload #8
    //   2333: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2336: astore_0
    //   2337: iload_3
    //   2338: iconst_1
    //   2339: iadd
    //   2340: istore #13
    //   2342: aload_0
    //   2343: iload #13
    //   2345: aaload
    //   2346: astore #9
    //   2348: aload #11
    //   2350: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2353: ifnull -> 2369
    //   2356: aload #11
    //   2358: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2361: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2364: astore #4
    //   2366: goto -> 2372
    //   2369: aconst_null
    //   2370: astore #4
    //   2372: aload #9
    //   2374: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2377: ifnull -> 2392
    //   2380: aload #9
    //   2382: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2385: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2388: astore_0
    //   2389: goto -> 2394
    //   2392: aconst_null
    //   2393: astore_0
    //   2394: aload #6
    //   2396: aload #8
    //   2398: if_acmpeq -> 2434
    //   2401: aload #6
    //   2403: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2406: iload #13
    //   2408: aaload
    //   2409: astore #18
    //   2411: aload #19
    //   2413: astore_0
    //   2414: aload #18
    //   2416: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2419: ifnull -> 2431
    //   2422: aload #18
    //   2424: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2427: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2430: astore_0
    //   2431: goto -> 2434
    //   2434: aload #7
    //   2436: aload #8
    //   2438: if_acmpne -> 2460
    //   2441: aload #7
    //   2443: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2446: iload_3
    //   2447: aaload
    //   2448: astore #11
    //   2450: aload #7
    //   2452: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2455: iload #13
    //   2457: aaload
    //   2458: astore #9
    //   2460: aload #4
    //   2462: ifnull -> 2525
    //   2465: aload_0
    //   2466: ifnull -> 2525
    //   2469: aload #11
    //   2471: invokevirtual getMargin : ()I
    //   2474: istore_2
    //   2475: aload #8
    //   2477: ifnonnull -> 2487
    //   2480: aload #6
    //   2482: astore #18
    //   2484: goto -> 2491
    //   2487: aload #8
    //   2489: astore #18
    //   2491: aload #18
    //   2493: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2496: iload #13
    //   2498: aaload
    //   2499: invokevirtual getMargin : ()I
    //   2502: istore_3
    //   2503: aload_1
    //   2504: aload #11
    //   2506: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2509: aload #4
    //   2511: iload_2
    //   2512: ldc 0.5
    //   2514: aload_0
    //   2515: aload #9
    //   2517: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2520: iload_3
    //   2521: iconst_5
    //   2522: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2525: return
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\constraintlayout\solver\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */