package androidx.core.util;

public interface Predicate<T> {
  boolean test(T paramT);
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\cor\\util\Predicate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */