package androidx.core.view;

import android.view.View;

public interface ViewPropertyAnimatorListener {
  void onAnimationCancel(View paramView);
  
  void onAnimationEnd(View paramView);
  
  void onAnimationStart(View paramView);
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\core\view\ViewPropertyAnimatorListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */