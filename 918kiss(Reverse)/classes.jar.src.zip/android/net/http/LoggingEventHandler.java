package android.net.http;

public class LoggingEventHandler implements EventHandler {
  public LoggingEventHandler() {
    throw new RuntimeException("Stub!");
  }
  
  public void certificate(SslCertificate paramSslCertificate) {
    throw new RuntimeException("Stub!");
  }
  
  public void data(byte[] paramArrayOfbyte, int paramInt) {
    throw new RuntimeException("Stub!");
  }
  
  public void endData() {
    throw new RuntimeException("Stub!");
  }
  
  public void error(int paramInt, String paramString) {
    throw new RuntimeException("Stub!");
  }
  
  public boolean handleSslErrorRequest(SslError paramSslError) {
    throw new RuntimeException("Stub!");
  }
  
  public void headers(Headers paramHeaders) {
    throw new RuntimeException("Stub!");
  }
  
  public void locationChanged(String paramString, boolean paramBoolean) {
    throw new RuntimeException("Stub!");
  }
  
  public void requestSent() {
    throw new RuntimeException("Stub!");
  }
  
  public void status(int paramInt1, int paramInt2, int paramInt3, String paramString) {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\android\net\http\LoggingEventHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */