package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ConstraintWidgetGroup {
  public List<ConstraintWidget> mConstrainedGroup;
  
  public final int[] mGroupDimensions = new int[] { -1, -1 };
  
  int mGroupHeight = -1;
  
  int mGroupWidth = -1;
  
  public boolean mSkipSolver = false;
  
  List<ConstraintWidget> mStartHorizontalWidgets = new ArrayList<ConstraintWidget>();
  
  List<ConstraintWidget> mStartVerticalWidgets = new ArrayList<ConstraintWidget>();
  
  List<ConstraintWidget> mUnresolvedWidgets = new ArrayList<ConstraintWidget>();
  
  HashSet<ConstraintWidget> mWidgetsToSetHorizontal = new HashSet<ConstraintWidget>();
  
  HashSet<ConstraintWidget> mWidgetsToSetVertical = new HashSet<ConstraintWidget>();
  
  List<ConstraintWidget> mWidgetsToSolve = new ArrayList<ConstraintWidget>();
  
  ConstraintWidgetGroup(List<ConstraintWidget> paramList) {
    this.mConstrainedGroup = paramList;
  }
  
  ConstraintWidgetGroup(List<ConstraintWidget> paramList, boolean paramBoolean) {
    this.mConstrainedGroup = paramList;
    this.mSkipSolver = paramBoolean;
  }
  
  private void getWidgetsToSolveTraversal(ArrayList<ConstraintWidget> paramArrayList, ConstraintWidget paramConstraintWidget) {
    if (paramConstraintWidget.mGroupsToSolver)
      return; 
    paramArrayList.add(paramConstraintWidget);
    paramConstraintWidget.mGroupsToSolver = true;
    if (paramConstraintWidget.isFullyResolved())
      return; 
    boolean bool = paramConstraintWidget instanceof Helper;
    byte b1 = 0;
    if (bool) {
      Helper helper = (Helper)paramConstraintWidget;
      int j = helper.mWidgetsCount;
      for (byte b = 0; b < j; b++)
        getWidgetsToSolveTraversal(paramArrayList, helper.mWidgets[b]); 
    } 
    int i = paramConstraintWidget.mListAnchors.length;
    for (byte b2 = b1; b2 < i; b2++) {
      ConstraintAnchor constraintAnchor = (paramConstraintWidget.mListAnchors[b2]).mTarget;
      if (constraintAnchor != null) {
        ConstraintWidget constraintWidget = constraintAnchor.mOwner;
        if (constraintAnchor != null && constraintWidget != paramConstraintWidget.getParent())
          getWidgetsToSolveTraversal(paramArrayList, constraintWidget); 
      } 
    } 
  }
  
  private void updateResolvedDimension(ConstraintWidget paramConstraintWidget) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mOptimizerMeasurable : Z
    //   4: ifeq -> 434
    //   7: aload_1
    //   8: invokevirtual isFullyResolved : ()Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   19: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   22: astore_2
    //   23: iconst_0
    //   24: istore_3
    //   25: aload_2
    //   26: ifnull -> 35
    //   29: iconst_1
    //   30: istore #4
    //   32: goto -> 38
    //   35: iconst_0
    //   36: istore #4
    //   38: iload #4
    //   40: ifeq -> 54
    //   43: aload_1
    //   44: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   47: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   50: astore_2
    //   51: goto -> 62
    //   54: aload_1
    //   55: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   58: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   61: astore_2
    //   62: aload_2
    //   63: ifnull -> 136
    //   66: aload_2
    //   67: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   70: getfield mOptimizerMeasured : Z
    //   73: ifne -> 84
    //   76: aload_0
    //   77: aload_2
    //   78: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   81: invokespecial updateResolvedDimension : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   84: aload_2
    //   85: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   88: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   91: if_acmpne -> 114
    //   94: aload_2
    //   95: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   98: getfield mX : I
    //   101: aload_2
    //   102: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   105: invokevirtual getWidth : ()I
    //   108: iadd
    //   109: istore #5
    //   111: goto -> 139
    //   114: aload_2
    //   115: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   118: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   121: if_acmpne -> 136
    //   124: aload_2
    //   125: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   128: getfield mX : I
    //   131: istore #5
    //   133: goto -> 139
    //   136: iconst_0
    //   137: istore #5
    //   139: iload #4
    //   141: ifeq -> 159
    //   144: iload #5
    //   146: aload_1
    //   147: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   150: invokevirtual getMargin : ()I
    //   153: isub
    //   154: istore #5
    //   156: goto -> 176
    //   159: iload #5
    //   161: aload_1
    //   162: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   165: invokevirtual getMargin : ()I
    //   168: aload_1
    //   169: invokevirtual getWidth : ()I
    //   172: iadd
    //   173: iadd
    //   174: istore #5
    //   176: aload_1
    //   177: iload #5
    //   179: aload_1
    //   180: invokevirtual getWidth : ()I
    //   183: isub
    //   184: iload #5
    //   186: invokevirtual setHorizontalDimension : (II)V
    //   189: aload_1
    //   190: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   193: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   196: ifnull -> 266
    //   199: aload_1
    //   200: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   203: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   206: astore_2
    //   207: aload_2
    //   208: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   211: getfield mOptimizerMeasured : Z
    //   214: ifne -> 225
    //   217: aload_0
    //   218: aload_2
    //   219: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   222: invokespecial updateResolvedDimension : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   225: aload_2
    //   226: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   229: getfield mY : I
    //   232: aload_2
    //   233: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   236: getfield mBaselineDistance : I
    //   239: iadd
    //   240: aload_1
    //   241: getfield mBaselineDistance : I
    //   244: isub
    //   245: istore #5
    //   247: aload_1
    //   248: iload #5
    //   250: aload_1
    //   251: getfield mHeight : I
    //   254: iload #5
    //   256: iadd
    //   257: invokevirtual setVerticalDimension : (II)V
    //   260: aload_1
    //   261: iconst_1
    //   262: putfield mOptimizerMeasured : Z
    //   265: return
    //   266: aload_1
    //   267: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   270: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   273: ifnull -> 278
    //   276: iconst_1
    //   277: istore_3
    //   278: iload_3
    //   279: ifeq -> 293
    //   282: aload_1
    //   283: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   286: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   289: astore_2
    //   290: goto -> 301
    //   293: aload_1
    //   294: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   297: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   300: astore_2
    //   301: iload #5
    //   303: istore #4
    //   305: aload_2
    //   306: ifnull -> 380
    //   309: aload_2
    //   310: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   313: getfield mOptimizerMeasured : Z
    //   316: ifne -> 327
    //   319: aload_0
    //   320: aload_2
    //   321: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   324: invokespecial updateResolvedDimension : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   327: aload_2
    //   328: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   331: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   334: if_acmpne -> 357
    //   337: aload_2
    //   338: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   341: getfield mY : I
    //   344: aload_2
    //   345: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   348: invokevirtual getHeight : ()I
    //   351: iadd
    //   352: istore #4
    //   354: goto -> 380
    //   357: iload #5
    //   359: istore #4
    //   361: aload_2
    //   362: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   365: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   368: if_acmpne -> 380
    //   371: aload_2
    //   372: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   375: getfield mY : I
    //   378: istore #4
    //   380: iload_3
    //   381: ifeq -> 399
    //   384: iload #4
    //   386: aload_1
    //   387: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   390: invokevirtual getMargin : ()I
    //   393: isub
    //   394: istore #5
    //   396: goto -> 416
    //   399: iload #4
    //   401: aload_1
    //   402: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   405: invokevirtual getMargin : ()I
    //   408: aload_1
    //   409: invokevirtual getHeight : ()I
    //   412: iadd
    //   413: iadd
    //   414: istore #5
    //   416: aload_1
    //   417: iload #5
    //   419: aload_1
    //   420: invokevirtual getHeight : ()I
    //   423: isub
    //   424: iload #5
    //   426: invokevirtual setVerticalDimension : (II)V
    //   429: aload_1
    //   430: iconst_1
    //   431: putfield mOptimizerMeasured : Z
    //   434: return
  }
  
  void addWidgetsToSet(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      this.mWidgetsToSetHorizontal.add(paramConstraintWidget);
    } else if (paramInt == 1) {
      this.mWidgetsToSetVertical.add(paramConstraintWidget);
    } 
  }
  
  public List<ConstraintWidget> getStartWidgets(int paramInt) {
    return (paramInt == 0) ? this.mStartHorizontalWidgets : ((paramInt == 1) ? this.mStartVerticalWidgets : null);
  }
  
  Set<ConstraintWidget> getWidgetsToSet(int paramInt) {
    return (paramInt == 0) ? this.mWidgetsToSetHorizontal : ((paramInt == 1) ? this.mWidgetsToSetVertical : null);
  }
  
  List<ConstraintWidget> getWidgetsToSolve() {
    if (!this.mWidgetsToSolve.isEmpty())
      return this.mWidgetsToSolve; 
    int i = this.mConstrainedGroup.size();
    for (byte b = 0; b < i; b++) {
      ConstraintWidget constraintWidget = this.mConstrainedGroup.get(b);
      if (!constraintWidget.mOptimizerMeasurable)
        getWidgetsToSolveTraversal((ArrayList<ConstraintWidget>)this.mWidgetsToSolve, constraintWidget); 
    } 
    this.mUnresolvedWidgets.clear();
    this.mUnresolvedWidgets.addAll(this.mConstrainedGroup);
    this.mUnresolvedWidgets.removeAll(this.mWidgetsToSolve);
    return this.mWidgetsToSolve;
  }
  
  void updateUnresolvedWidgets() {
    int i = this.mUnresolvedWidgets.size();
    for (byte b = 0; b < i; b++)
      updateResolvedDimension(this.mUnresolvedWidgets.get(b)); 
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidgetGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */