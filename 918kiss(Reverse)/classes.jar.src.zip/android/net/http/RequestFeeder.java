package android.net.http;

import org.apache.http.HttpHost;

interface RequestFeeder {
  Request getRequest();
  
  Request getRequest(HttpHost paramHttpHost);
  
  boolean haveRequest(HttpHost paramHttpHost);
  
  void requeueRequest(Request paramRequest);
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\android\net\http\RequestFeeder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */