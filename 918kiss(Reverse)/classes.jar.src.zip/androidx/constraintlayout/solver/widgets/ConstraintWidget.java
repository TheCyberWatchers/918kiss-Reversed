package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import java.util.ArrayList;

public class ConstraintWidget {
  protected static final int ANCHOR_BASELINE = 4;
  
  protected static final int ANCHOR_BOTTOM = 3;
  
  protected static final int ANCHOR_LEFT = 0;
  
  protected static final int ANCHOR_RIGHT = 1;
  
  protected static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  ConstraintWidgetGroup mBelongingGroup = null;
  
  ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  protected float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  private int mDrawHeight;
  
  private int mDrawWidth;
  
  private int mDrawX;
  
  private int mDrawY;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  boolean mIsHeightWrapContent;
  
  boolean mIsWidthWrapContent;
  
  ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  protected ConstraintAnchor[] mListAnchors;
  
  protected DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  int mMatchConstraintDefaultHeight = 0;
  
  int mMatchConstraintDefaultWidth = 0;
  
  int mMatchConstraintMaxHeight = 0;
  
  int mMatchConstraintMaxWidth = 0;
  
  int mMatchConstraintMinHeight = 0;
  
  int mMatchConstraintMinWidth = 0;
  
  float mMatchConstraintPercentHeight = 1.0F;
  
  float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  boolean mOptimizerMeasurable;
  
  boolean mOptimizerMeasured;
  
  ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  ResolutionDimension mResolutionHeight;
  
  ResolutionDimension mResolutionWidth;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  int[] mResolvedMatchConstraintDefault = new int[2];
  
  ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  float[] mWeight;
  
  int mWidth;
  
  private int mWrapHeight;
  
  private int mWrapWidth;
  
  protected int mX;
  
  protected int mY;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mDrawX = 0;
    this.mDrawY = 0;
    this.mDrawWidth = 0;
    this.mDrawHeight = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mDrawX = 0;
    this.mDrawY = 0;
    this.mDrawWidth = 0;
    this.mDrawHeight = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
    forceUpdateDrawPosition();
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean2, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, int paramInt6, int paramInt7, float paramFloat2, boolean paramBoolean5) {
    // Byte code:
    //   0: aload_1
    //   1: aload #7
    //   3: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   6: astore #21
    //   8: aload_1
    //   9: aload #8
    //   11: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   14: astore #22
    //   16: aload_1
    //   17: aload #7
    //   19: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   22: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   25: astore #23
    //   27: aload_1
    //   28: aload #8
    //   30: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   36: astore #24
    //   38: aload_1
    //   39: getfield graphOptimizer : Z
    //   42: ifeq -> 128
    //   45: aload #7
    //   47: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   50: getfield state : I
    //   53: iconst_1
    //   54: if_icmpne -> 128
    //   57: aload #8
    //   59: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   62: getfield state : I
    //   65: iconst_1
    //   66: if_icmpne -> 128
    //   69: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   72: ifnull -> 89
    //   75: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   78: astore_3
    //   79: aload_3
    //   80: aload_3
    //   81: getfield resolvedWidgets : J
    //   84: lconst_1
    //   85: ladd
    //   86: putfield resolvedWidgets : J
    //   89: aload #7
    //   91: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   94: aload_1
    //   95: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   98: aload #8
    //   100: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   103: aload_1
    //   104: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   107: iload #15
    //   109: ifne -> 127
    //   112: iload_2
    //   113: ifeq -> 127
    //   116: aload_1
    //   117: aload #4
    //   119: aload #22
    //   121: iconst_0
    //   122: bipush #6
    //   124: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   127: return
    //   128: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   131: ifnull -> 151
    //   134: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   137: astore #25
    //   139: aload #25
    //   141: aload #25
    //   143: getfield nonresolvedWidgets : J
    //   146: lconst_1
    //   147: ladd
    //   148: putfield nonresolvedWidgets : J
    //   151: aload #7
    //   153: invokevirtual isConnected : ()Z
    //   156: istore #26
    //   158: aload #8
    //   160: invokevirtual isConnected : ()Z
    //   163: istore #27
    //   165: aload_0
    //   166: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   169: invokevirtual isConnected : ()Z
    //   172: istore #28
    //   174: iload #26
    //   176: ifeq -> 185
    //   179: iconst_1
    //   180: istore #29
    //   182: goto -> 188
    //   185: iconst_0
    //   186: istore #29
    //   188: iload #29
    //   190: istore #30
    //   192: iload #27
    //   194: ifeq -> 203
    //   197: iload #29
    //   199: iconst_1
    //   200: iadd
    //   201: istore #30
    //   203: iload #30
    //   205: istore #29
    //   207: iload #28
    //   209: ifeq -> 218
    //   212: iload #30
    //   214: iconst_1
    //   215: iadd
    //   216: istore #29
    //   218: iload #14
    //   220: ifeq -> 229
    //   223: iconst_3
    //   224: istore #30
    //   226: goto -> 233
    //   229: iload #16
    //   231: istore #30
    //   233: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
    //   236: aload #5
    //   238: invokevirtual ordinal : ()I
    //   241: iaload
    //   242: istore #16
    //   244: iload #16
    //   246: iconst_1
    //   247: if_icmpeq -> 268
    //   250: iload #16
    //   252: iconst_2
    //   253: if_icmpeq -> 268
    //   256: iload #16
    //   258: iconst_3
    //   259: if_icmpeq -> 268
    //   262: iload #16
    //   264: iconst_4
    //   265: if_icmpeq -> 274
    //   268: iconst_0
    //   269: istore #16
    //   271: goto -> 286
    //   274: iload #30
    //   276: iconst_4
    //   277: if_icmpne -> 283
    //   280: goto -> 268
    //   283: iconst_1
    //   284: istore #16
    //   286: aload_0
    //   287: getfield mVisibility : I
    //   290: bipush #8
    //   292: if_icmpne -> 304
    //   295: iconst_0
    //   296: istore #10
    //   298: iconst_0
    //   299: istore #16
    //   301: goto -> 304
    //   304: iload #20
    //   306: ifeq -> 364
    //   309: iload #26
    //   311: ifne -> 335
    //   314: iload #27
    //   316: ifne -> 335
    //   319: iload #28
    //   321: ifne -> 335
    //   324: aload_1
    //   325: aload #21
    //   327: iload #9
    //   329: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   332: goto -> 364
    //   335: iload #26
    //   337: ifeq -> 364
    //   340: iload #27
    //   342: ifne -> 364
    //   345: aload_1
    //   346: aload #21
    //   348: aload #23
    //   350: aload #7
    //   352: invokevirtual getMargin : ()I
    //   355: bipush #6
    //   357: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   360: pop
    //   361: goto -> 364
    //   364: iload #16
    //   366: ifne -> 452
    //   369: iload #6
    //   371: ifeq -> 424
    //   374: aload_1
    //   375: aload #22
    //   377: aload #21
    //   379: iconst_0
    //   380: iconst_3
    //   381: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   384: pop
    //   385: iload #11
    //   387: ifle -> 402
    //   390: aload_1
    //   391: aload #22
    //   393: aload #21
    //   395: iload #11
    //   397: bipush #6
    //   399: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   402: iload #12
    //   404: ldc 2147483647
    //   406: if_icmpge -> 421
    //   409: aload_1
    //   410: aload #22
    //   412: aload #21
    //   414: iload #12
    //   416: bipush #6
    //   418: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   421: goto -> 437
    //   424: aload_1
    //   425: aload #22
    //   427: aload #21
    //   429: iload #10
    //   431: bipush #6
    //   433: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   436: pop
    //   437: iload #16
    //   439: istore #12
    //   441: iload #18
    //   443: istore #10
    //   445: iload #17
    //   447: istore #16
    //   449: goto -> 826
    //   452: iload #17
    //   454: istore #9
    //   456: iload #17
    //   458: bipush #-2
    //   460: if_icmpne -> 467
    //   463: iload #10
    //   465: istore #9
    //   467: iload #18
    //   469: istore #12
    //   471: iload #18
    //   473: bipush #-2
    //   475: if_icmpne -> 482
    //   478: iload #10
    //   480: istore #12
    //   482: iload #10
    //   484: istore #17
    //   486: iload #9
    //   488: ifle -> 512
    //   491: aload_1
    //   492: aload #22
    //   494: aload #21
    //   496: iload #9
    //   498: bipush #6
    //   500: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   503: iload #10
    //   505: iload #9
    //   507: invokestatic max : (II)I
    //   510: istore #17
    //   512: iload #17
    //   514: istore #18
    //   516: iload #12
    //   518: ifle -> 542
    //   521: aload_1
    //   522: aload #22
    //   524: aload #21
    //   526: iload #12
    //   528: bipush #6
    //   530: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   533: iload #17
    //   535: iload #12
    //   537: invokestatic min : (II)I
    //   540: istore #18
    //   542: iload #30
    //   544: iconst_1
    //   545: if_icmpne -> 603
    //   548: iload_2
    //   549: ifeq -> 568
    //   552: aload_1
    //   553: aload #22
    //   555: aload #21
    //   557: iload #18
    //   559: bipush #6
    //   561: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   564: pop
    //   565: goto -> 736
    //   568: iload #15
    //   570: ifeq -> 588
    //   573: aload_1
    //   574: aload #22
    //   576: aload #21
    //   578: iload #18
    //   580: iconst_4
    //   581: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   584: pop
    //   585: goto -> 736
    //   588: aload_1
    //   589: aload #22
    //   591: aload #21
    //   593: iload #18
    //   595: iconst_1
    //   596: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   599: pop
    //   600: goto -> 736
    //   603: iload #30
    //   605: iconst_2
    //   606: if_icmpne -> 736
    //   609: aload #7
    //   611: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   614: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   617: if_acmpeq -> 673
    //   620: aload #7
    //   622: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   625: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   628: if_acmpne -> 634
    //   631: goto -> 673
    //   634: aload_1
    //   635: aload_0
    //   636: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   639: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   642: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   645: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   648: astore #5
    //   650: aload_0
    //   651: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   654: astore #25
    //   656: aload_1
    //   657: aload #25
    //   659: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   662: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   665: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   668: astore #25
    //   670: goto -> 709
    //   673: aload_1
    //   674: aload_0
    //   675: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   678: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   681: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   684: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   687: astore #5
    //   689: aload_0
    //   690: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   693: astore #25
    //   695: aload_1
    //   696: aload #25
    //   698: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   701: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   704: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   707: astore #25
    //   709: aload_1
    //   710: aload_1
    //   711: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   714: aload #22
    //   716: aload #21
    //   718: aload #25
    //   720: aload #5
    //   722: fload #19
    //   724: invokevirtual createRowDimensionRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;F)Landroidx/constraintlayout/solver/ArrayRow;
    //   727: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   730: iconst_0
    //   731: istore #10
    //   733: goto -> 740
    //   736: iload #16
    //   738: istore #10
    //   740: iload #12
    //   742: istore #17
    //   744: iload #10
    //   746: ifeq -> 814
    //   749: iload #29
    //   751: iconst_2
    //   752: if_icmpeq -> 814
    //   755: iload #14
    //   757: ifne -> 814
    //   760: iload #9
    //   762: iload #18
    //   764: invokestatic max : (II)I
    //   767: istore #12
    //   769: iload #12
    //   771: istore #10
    //   773: iload #17
    //   775: ifle -> 787
    //   778: iload #17
    //   780: iload #12
    //   782: invokestatic min : (II)I
    //   785: istore #10
    //   787: aload_1
    //   788: aload #22
    //   790: aload #21
    //   792: iload #10
    //   794: bipush #6
    //   796: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   799: pop
    //   800: iconst_0
    //   801: istore #12
    //   803: iload #17
    //   805: istore #10
    //   807: iload #9
    //   809: istore #16
    //   811: goto -> 826
    //   814: iload #10
    //   816: istore #12
    //   818: iload #9
    //   820: istore #16
    //   822: iload #17
    //   824: istore #10
    //   826: aload #23
    //   828: astore #25
    //   830: aload #24
    //   832: astore #5
    //   834: iload #20
    //   836: ifeq -> 1450
    //   839: iload #15
    //   841: ifeq -> 847
    //   844: goto -> 1450
    //   847: iload #26
    //   849: ifne -> 879
    //   852: iload #27
    //   854: ifne -> 879
    //   857: iload #28
    //   859: ifne -> 879
    //   862: iload_2
    //   863: ifeq -> 1434
    //   866: aload_1
    //   867: aload #4
    //   869: aload #22
    //   871: iconst_0
    //   872: iconst_5
    //   873: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   876: goto -> 1434
    //   879: iload #26
    //   881: ifeq -> 906
    //   884: iload #27
    //   886: ifne -> 906
    //   889: iload_2
    //   890: ifeq -> 1434
    //   893: aload_1
    //   894: aload #4
    //   896: aload #22
    //   898: iconst_0
    //   899: iconst_5
    //   900: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   903: goto -> 1434
    //   906: iload #26
    //   908: ifne -> 949
    //   911: iload #27
    //   913: ifeq -> 949
    //   916: aload_1
    //   917: aload #22
    //   919: aload #5
    //   921: aload #8
    //   923: invokevirtual getMargin : ()I
    //   926: ineg
    //   927: bipush #6
    //   929: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   932: pop
    //   933: iload_2
    //   934: ifeq -> 1434
    //   937: aload_1
    //   938: aload #21
    //   940: aload_3
    //   941: iconst_0
    //   942: iconst_5
    //   943: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   946: goto -> 1434
    //   949: iload #26
    //   951: ifeq -> 1434
    //   954: iload #27
    //   956: ifeq -> 1434
    //   959: iload #12
    //   961: ifeq -> 1204
    //   964: aload #5
    //   966: astore #24
    //   968: iload_2
    //   969: ifeq -> 988
    //   972: iload #11
    //   974: ifne -> 988
    //   977: aload_1
    //   978: aload #22
    //   980: aload #21
    //   982: iconst_0
    //   983: bipush #6
    //   985: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   988: iload #30
    //   990: ifne -> 1091
    //   993: iload #10
    //   995: ifgt -> 1016
    //   998: iload #16
    //   1000: ifle -> 1006
    //   1003: goto -> 1016
    //   1006: bipush #6
    //   1008: istore #11
    //   1010: iconst_0
    //   1011: istore #9
    //   1013: goto -> 1022
    //   1016: iconst_4
    //   1017: istore #11
    //   1019: iconst_1
    //   1020: istore #9
    //   1022: aload_1
    //   1023: aload #21
    //   1025: aload #25
    //   1027: aload #7
    //   1029: invokevirtual getMargin : ()I
    //   1032: iload #11
    //   1034: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1037: pop
    //   1038: aload_1
    //   1039: aload #22
    //   1041: aload #24
    //   1043: aload #8
    //   1045: invokevirtual getMargin : ()I
    //   1048: ineg
    //   1049: iload #11
    //   1051: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1054: pop
    //   1055: iload #10
    //   1057: ifgt -> 1074
    //   1060: iload #16
    //   1062: ifle -> 1068
    //   1065: goto -> 1074
    //   1068: iconst_0
    //   1069: istore #11
    //   1071: goto -> 1077
    //   1074: iconst_1
    //   1075: istore #11
    //   1077: iconst_5
    //   1078: istore #16
    //   1080: iload #9
    //   1082: istore #10
    //   1084: iload #16
    //   1086: istore #9
    //   1088: goto -> 1107
    //   1091: iload #30
    //   1093: iconst_1
    //   1094: if_icmpne -> 1122
    //   1097: iconst_1
    //   1098: istore #11
    //   1100: iconst_1
    //   1101: istore #10
    //   1103: bipush #6
    //   1105: istore #9
    //   1107: iload #11
    //   1109: istore #17
    //   1111: iload #10
    //   1113: istore #11
    //   1115: iload #9
    //   1117: istore #16
    //   1119: goto -> 1221
    //   1122: iload #30
    //   1124: iconst_3
    //   1125: if_icmpne -> 1198
    //   1128: iload #14
    //   1130: ifne -> 1153
    //   1133: aload_0
    //   1134: getfield mResolvedDimensionRatioSide : I
    //   1137: iconst_m1
    //   1138: if_icmpeq -> 1153
    //   1141: iload #10
    //   1143: ifgt -> 1153
    //   1146: bipush #6
    //   1148: istore #9
    //   1150: goto -> 1156
    //   1153: iconst_4
    //   1154: istore #9
    //   1156: aload_1
    //   1157: aload #21
    //   1159: aload #25
    //   1161: aload #7
    //   1163: invokevirtual getMargin : ()I
    //   1166: iload #9
    //   1168: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1171: pop
    //   1172: aload_1
    //   1173: aload #22
    //   1175: aload #24
    //   1177: aload #8
    //   1179: invokevirtual getMargin : ()I
    //   1182: ineg
    //   1183: iload #9
    //   1185: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1188: pop
    //   1189: iconst_1
    //   1190: istore #9
    //   1192: iconst_1
    //   1193: istore #10
    //   1195: goto -> 1210
    //   1198: iconst_0
    //   1199: istore #9
    //   1201: goto -> 1207
    //   1204: iconst_1
    //   1205: istore #9
    //   1207: iconst_0
    //   1208: istore #10
    //   1210: iconst_5
    //   1211: istore #16
    //   1213: iload #10
    //   1215: istore #11
    //   1217: iload #9
    //   1219: istore #17
    //   1221: iload #17
    //   1223: ifeq -> 1330
    //   1226: aload_1
    //   1227: aload #21
    //   1229: aload #25
    //   1231: aload #7
    //   1233: invokevirtual getMargin : ()I
    //   1236: fload #13
    //   1238: aload #5
    //   1240: aload #22
    //   1242: aload #8
    //   1244: invokevirtual getMargin : ()I
    //   1247: iload #16
    //   1249: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1252: aload #7
    //   1254: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1257: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1260: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1263: istore #6
    //   1265: aload #8
    //   1267: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1270: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1273: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1276: istore #14
    //   1278: iload #6
    //   1280: ifeq -> 1304
    //   1283: iload #14
    //   1285: ifne -> 1304
    //   1288: iload_2
    //   1289: istore #6
    //   1291: bipush #6
    //   1293: istore #10
    //   1295: iconst_5
    //   1296: istore #9
    //   1298: iconst_1
    //   1299: istore #14
    //   1301: goto -> 1343
    //   1304: iload #6
    //   1306: ifne -> 1330
    //   1309: iload #14
    //   1311: ifeq -> 1330
    //   1314: iload_2
    //   1315: istore #14
    //   1317: iconst_5
    //   1318: istore #10
    //   1320: bipush #6
    //   1322: istore #9
    //   1324: iconst_1
    //   1325: istore #6
    //   1327: goto -> 1343
    //   1330: iload_2
    //   1331: istore #6
    //   1333: iload #6
    //   1335: istore #14
    //   1337: iconst_5
    //   1338: istore #10
    //   1340: iconst_5
    //   1341: istore #9
    //   1343: iload #11
    //   1345: ifeq -> 1356
    //   1348: bipush #6
    //   1350: istore #10
    //   1352: bipush #6
    //   1354: istore #9
    //   1356: iload #12
    //   1358: ifne -> 1366
    //   1361: iload #6
    //   1363: ifne -> 1371
    //   1366: iload #11
    //   1368: ifeq -> 1386
    //   1371: aload_1
    //   1372: aload #21
    //   1374: aload #25
    //   1376: aload #7
    //   1378: invokevirtual getMargin : ()I
    //   1381: iload #9
    //   1383: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1386: iload #12
    //   1388: ifne -> 1396
    //   1391: iload #14
    //   1393: ifne -> 1401
    //   1396: iload #11
    //   1398: ifeq -> 1417
    //   1401: aload_1
    //   1402: aload #22
    //   1404: aload #5
    //   1406: aload #8
    //   1408: invokevirtual getMargin : ()I
    //   1411: ineg
    //   1412: iload #10
    //   1414: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1417: iload_2
    //   1418: ifeq -> 1434
    //   1421: aload_1
    //   1422: aload #21
    //   1424: aload_3
    //   1425: iconst_0
    //   1426: bipush #6
    //   1428: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1431: goto -> 1434
    //   1434: iload_2
    //   1435: ifeq -> 1449
    //   1438: aload_1
    //   1439: aload #4
    //   1441: aload #22
    //   1443: iconst_0
    //   1444: bipush #6
    //   1446: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1449: return
    //   1450: iload #29
    //   1452: iconst_2
    //   1453: if_icmpge -> 1481
    //   1456: iload_2
    //   1457: ifeq -> 1481
    //   1460: aload_1
    //   1461: aload #21
    //   1463: aload_3
    //   1464: iconst_0
    //   1465: bipush #6
    //   1467: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1470: aload_1
    //   1471: aload #4
    //   1473: aload #22
    //   1475: iconst_0
    //   1476: bipush #6
    //   1478: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1481: return
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget;
    null = true;
    if (constraintAnchor != null) {
      ConstraintAnchor constraintAnchor1 = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor1 != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return null;  
    } 
    return false;
  }
  
  public void addToSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   8: astore_2
    //   9: aload_1
    //   10: aload_0
    //   11: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   17: astore_3
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   23: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   26: astore #4
    //   28: aload_1
    //   29: aload_0
    //   30: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   36: astore #5
    //   38: aload_1
    //   39: aload_0
    //   40: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   43: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   46: astore #6
    //   48: aload_0
    //   49: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   52: astore #7
    //   54: aload #7
    //   56: ifnull -> 310
    //   59: aload #7
    //   61: ifnull -> 83
    //   64: aload #7
    //   66: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   69: iconst_0
    //   70: aaload
    //   71: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   74: if_acmpne -> 83
    //   77: iconst_1
    //   78: istore #8
    //   80: goto -> 86
    //   83: iconst_0
    //   84: istore #8
    //   86: aload_0
    //   87: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   90: astore #7
    //   92: aload #7
    //   94: ifnull -> 116
    //   97: aload #7
    //   99: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   102: iconst_1
    //   103: aaload
    //   104: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   107: if_acmpne -> 116
    //   110: iconst_1
    //   111: istore #9
    //   113: goto -> 119
    //   116: iconst_0
    //   117: istore #9
    //   119: aload_0
    //   120: iconst_0
    //   121: invokespecial isChainHead : (I)Z
    //   124: ifeq -> 145
    //   127: aload_0
    //   128: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   131: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   134: aload_0
    //   135: iconst_0
    //   136: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   139: iconst_1
    //   140: istore #10
    //   142: goto -> 151
    //   145: aload_0
    //   146: invokevirtual isInHorizontalChain : ()Z
    //   149: istore #10
    //   151: aload_0
    //   152: iconst_1
    //   153: invokespecial isChainHead : (I)Z
    //   156: ifeq -> 177
    //   159: aload_0
    //   160: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   163: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   166: aload_0
    //   167: iconst_1
    //   168: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   171: iconst_1
    //   172: istore #11
    //   174: goto -> 183
    //   177: aload_0
    //   178: invokevirtual isInVerticalChain : ()Z
    //   181: istore #11
    //   183: iload #8
    //   185: ifeq -> 235
    //   188: aload_0
    //   189: getfield mVisibility : I
    //   192: bipush #8
    //   194: if_icmpeq -> 235
    //   197: aload_0
    //   198: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   201: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   204: ifnonnull -> 235
    //   207: aload_0
    //   208: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   211: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   214: ifnonnull -> 235
    //   217: aload_1
    //   218: aload_1
    //   219: aload_0
    //   220: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   223: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   226: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   229: aload_3
    //   230: iconst_0
    //   231: iconst_1
    //   232: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   235: iload #9
    //   237: ifeq -> 295
    //   240: aload_0
    //   241: getfield mVisibility : I
    //   244: bipush #8
    //   246: if_icmpeq -> 295
    //   249: aload_0
    //   250: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   253: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   256: ifnonnull -> 295
    //   259: aload_0
    //   260: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   263: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   266: ifnonnull -> 295
    //   269: aload_0
    //   270: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   273: ifnonnull -> 295
    //   276: aload_1
    //   277: aload_1
    //   278: aload_0
    //   279: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   282: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   285: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   288: aload #5
    //   290: iconst_0
    //   291: iconst_1
    //   292: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   295: iload #11
    //   297: istore #12
    //   299: iload #8
    //   301: istore #11
    //   303: iload #12
    //   305: istore #8
    //   307: goto -> 322
    //   310: iconst_0
    //   311: istore #11
    //   313: iconst_0
    //   314: istore #9
    //   316: iconst_0
    //   317: istore #10
    //   319: iconst_0
    //   320: istore #8
    //   322: aload_0
    //   323: getfield mWidth : I
    //   326: istore #13
    //   328: aload_0
    //   329: getfield mMinWidth : I
    //   332: istore #14
    //   334: iload #13
    //   336: istore #15
    //   338: iload #13
    //   340: iload #14
    //   342: if_icmpge -> 349
    //   345: iload #14
    //   347: istore #15
    //   349: aload_0
    //   350: getfield mHeight : I
    //   353: istore #16
    //   355: aload_0
    //   356: getfield mMinHeight : I
    //   359: istore #14
    //   361: iload #16
    //   363: istore #13
    //   365: iload #16
    //   367: iload #14
    //   369: if_icmpge -> 376
    //   372: iload #14
    //   374: istore #13
    //   376: aload_0
    //   377: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   380: iconst_0
    //   381: aaload
    //   382: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   385: if_acmpeq -> 394
    //   388: iconst_1
    //   389: istore #12
    //   391: goto -> 397
    //   394: iconst_0
    //   395: istore #12
    //   397: aload_0
    //   398: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   401: iconst_1
    //   402: aaload
    //   403: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   406: if_acmpeq -> 415
    //   409: iconst_1
    //   410: istore #17
    //   412: goto -> 418
    //   415: iconst_0
    //   416: istore #17
    //   418: aload_0
    //   419: aload_0
    //   420: getfield mDimensionRatioSide : I
    //   423: putfield mResolvedDimensionRatioSide : I
    //   426: aload_0
    //   427: getfield mDimensionRatio : F
    //   430: fstore #18
    //   432: aload_0
    //   433: fload #18
    //   435: putfield mResolvedDimensionRatio : F
    //   438: aload_0
    //   439: getfield mMatchConstraintDefaultWidth : I
    //   442: istore #16
    //   444: aload_0
    //   445: getfield mMatchConstraintDefaultHeight : I
    //   448: istore #19
    //   450: fload #18
    //   452: fconst_0
    //   453: fcmpl
    //   454: ifle -> 782
    //   457: aload_0
    //   458: getfield mVisibility : I
    //   461: bipush #8
    //   463: if_icmpeq -> 782
    //   466: iload #16
    //   468: istore #14
    //   470: aload_0
    //   471: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   474: iconst_0
    //   475: aaload
    //   476: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   479: if_acmpne -> 494
    //   482: iload #16
    //   484: istore #14
    //   486: iload #16
    //   488: ifne -> 494
    //   491: iconst_3
    //   492: istore #14
    //   494: iload #19
    //   496: istore #16
    //   498: aload_0
    //   499: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   502: iconst_1
    //   503: aaload
    //   504: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   507: if_acmpne -> 522
    //   510: iload #19
    //   512: istore #16
    //   514: iload #19
    //   516: ifne -> 522
    //   519: iconst_3
    //   520: istore #16
    //   522: aload_0
    //   523: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   526: iconst_0
    //   527: aaload
    //   528: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   531: if_acmpne -> 573
    //   534: aload_0
    //   535: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   538: iconst_1
    //   539: aaload
    //   540: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   543: if_acmpne -> 573
    //   546: iload #14
    //   548: iconst_3
    //   549: if_icmpne -> 573
    //   552: iload #16
    //   554: iconst_3
    //   555: if_icmpne -> 573
    //   558: aload_0
    //   559: iload #11
    //   561: iload #9
    //   563: iload #12
    //   565: iload #17
    //   567: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   570: goto -> 760
    //   573: aload_0
    //   574: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   577: iconst_0
    //   578: aaload
    //   579: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   582: if_acmpne -> 645
    //   585: iload #14
    //   587: iconst_3
    //   588: if_icmpne -> 645
    //   591: aload_0
    //   592: iconst_0
    //   593: putfield mResolvedDimensionRatioSide : I
    //   596: aload_0
    //   597: getfield mResolvedDimensionRatio : F
    //   600: aload_0
    //   601: getfield mHeight : I
    //   604: i2f
    //   605: fmul
    //   606: f2i
    //   607: istore #15
    //   609: aload_0
    //   610: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   613: iconst_1
    //   614: aaload
    //   615: astore #7
    //   617: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   620: astore #20
    //   622: aload #7
    //   624: aload #20
    //   626: if_acmpeq -> 642
    //   629: iload #16
    //   631: istore #19
    //   633: iconst_0
    //   634: istore #14
    //   636: iconst_4
    //   637: istore #16
    //   639: goto -> 785
    //   642: goto -> 760
    //   645: aload_0
    //   646: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   649: iconst_1
    //   650: aaload
    //   651: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   654: if_acmpne -> 760
    //   657: iload #16
    //   659: iconst_3
    //   660: if_icmpne -> 760
    //   663: aload_0
    //   664: iconst_1
    //   665: putfield mResolvedDimensionRatioSide : I
    //   668: aload_0
    //   669: getfield mDimensionRatioSide : I
    //   672: iconst_m1
    //   673: if_icmpne -> 686
    //   676: aload_0
    //   677: fconst_1
    //   678: aload_0
    //   679: getfield mResolvedDimensionRatio : F
    //   682: fdiv
    //   683: putfield mResolvedDimensionRatio : F
    //   686: aload_0
    //   687: getfield mResolvedDimensionRatio : F
    //   690: aload_0
    //   691: getfield mWidth : I
    //   694: i2f
    //   695: fmul
    //   696: f2i
    //   697: istore #19
    //   699: aload_0
    //   700: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   703: iconst_0
    //   704: aaload
    //   705: astore #7
    //   707: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   710: astore #20
    //   712: iload #14
    //   714: istore #21
    //   716: iload #15
    //   718: istore #22
    //   720: iload #22
    //   722: istore #15
    //   724: iload #19
    //   726: istore #13
    //   728: aload #7
    //   730: aload #20
    //   732: if_acmpeq -> 760
    //   735: iconst_0
    //   736: istore #14
    //   738: iconst_4
    //   739: istore #23
    //   741: iload #22
    //   743: istore #15
    //   745: iload #19
    //   747: istore #13
    //   749: iload #21
    //   751: istore #16
    //   753: iload #23
    //   755: istore #19
    //   757: goto -> 785
    //   760: iload #14
    //   762: istore #19
    //   764: iload #16
    //   766: istore #22
    //   768: iconst_1
    //   769: istore #14
    //   771: iload #19
    //   773: istore #16
    //   775: iload #22
    //   777: istore #19
    //   779: goto -> 785
    //   782: iconst_0
    //   783: istore #14
    //   785: aload_0
    //   786: getfield mResolvedMatchConstraintDefault : [I
    //   789: astore #7
    //   791: aload #7
    //   793: iconst_0
    //   794: iload #16
    //   796: iastore
    //   797: aload #7
    //   799: iconst_1
    //   800: iload #19
    //   802: iastore
    //   803: iload #14
    //   805: ifeq -> 831
    //   808: aload_0
    //   809: getfield mResolvedDimensionRatioSide : I
    //   812: istore #22
    //   814: iload #22
    //   816: ifeq -> 825
    //   819: iload #22
    //   821: iconst_m1
    //   822: if_icmpne -> 831
    //   825: iconst_1
    //   826: istore #12
    //   828: goto -> 834
    //   831: iconst_0
    //   832: istore #12
    //   834: aload_0
    //   835: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   838: iconst_0
    //   839: aaload
    //   840: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   843: if_acmpne -> 859
    //   846: aload_0
    //   847: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   850: ifeq -> 859
    //   853: iconst_1
    //   854: istore #17
    //   856: goto -> 862
    //   859: iconst_0
    //   860: istore #17
    //   862: aload_0
    //   863: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   866: invokevirtual isConnected : ()Z
    //   869: iconst_1
    //   870: ixor
    //   871: istore #24
    //   873: aload_0
    //   874: getfield mHorizontalResolution : I
    //   877: iconst_2
    //   878: if_icmpeq -> 1007
    //   881: aload_0
    //   882: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   885: astore #7
    //   887: aload #7
    //   889: ifnull -> 906
    //   892: aload_1
    //   893: aload #7
    //   895: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   898: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   901: astore #7
    //   903: goto -> 909
    //   906: aconst_null
    //   907: astore #7
    //   909: aload_0
    //   910: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   913: astore #20
    //   915: aload #20
    //   917: ifnull -> 934
    //   920: aload_1
    //   921: aload #20
    //   923: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   926: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   929: astore #20
    //   931: goto -> 937
    //   934: aconst_null
    //   935: astore #20
    //   937: aload_0
    //   938: aload_1
    //   939: iload #11
    //   941: aload #20
    //   943: aload #7
    //   945: aload_0
    //   946: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   949: iconst_0
    //   950: aaload
    //   951: iload #17
    //   953: aload_0
    //   954: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   957: aload_0
    //   958: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   961: aload_0
    //   962: getfield mX : I
    //   965: iload #15
    //   967: aload_0
    //   968: getfield mMinWidth : I
    //   971: aload_0
    //   972: getfield mMaxDimension : [I
    //   975: iconst_0
    //   976: iaload
    //   977: aload_0
    //   978: getfield mHorizontalBiasPercent : F
    //   981: iload #12
    //   983: iload #10
    //   985: iload #16
    //   987: aload_0
    //   988: getfield mMatchConstraintMinWidth : I
    //   991: aload_0
    //   992: getfield mMatchConstraintMaxWidth : I
    //   995: aload_0
    //   996: getfield mMatchConstraintPercentWidth : F
    //   999: iload #24
    //   1001: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V
    //   1004: goto -> 1007
    //   1007: aload #4
    //   1009: astore #7
    //   1011: aload_0
    //   1012: getfield mVerticalResolution : I
    //   1015: iconst_2
    //   1016: if_icmpne -> 1020
    //   1019: return
    //   1020: aload_0
    //   1021: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1024: iconst_1
    //   1025: aaload
    //   1026: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1029: if_acmpne -> 1045
    //   1032: aload_0
    //   1033: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1036: ifeq -> 1045
    //   1039: iconst_1
    //   1040: istore #10
    //   1042: goto -> 1048
    //   1045: iconst_0
    //   1046: istore #10
    //   1048: iload #14
    //   1050: ifeq -> 1077
    //   1053: aload_0
    //   1054: getfield mResolvedDimensionRatioSide : I
    //   1057: istore #15
    //   1059: iload #15
    //   1061: iconst_1
    //   1062: if_icmpeq -> 1071
    //   1065: iload #15
    //   1067: iconst_m1
    //   1068: if_icmpne -> 1077
    //   1071: iconst_1
    //   1072: istore #11
    //   1074: goto -> 1080
    //   1077: iconst_0
    //   1078: istore #11
    //   1080: aload_0
    //   1081: getfield mBaselineDistance : I
    //   1084: ifle -> 1173
    //   1087: aload_0
    //   1088: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1091: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   1094: getfield state : I
    //   1097: iconst_1
    //   1098: if_icmpne -> 1115
    //   1101: aload_0
    //   1102: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1105: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   1108: aload_1
    //   1109: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   1112: goto -> 1173
    //   1115: aload_1
    //   1116: astore #20
    //   1118: aload #20
    //   1120: aload #6
    //   1122: aload #7
    //   1124: aload_0
    //   1125: invokevirtual getBaselineDistance : ()I
    //   1128: bipush #6
    //   1130: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1133: pop
    //   1134: aload_0
    //   1135: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1138: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1141: ifnull -> 1173
    //   1144: aload #20
    //   1146: aload #6
    //   1148: aload #20
    //   1150: aload_0
    //   1151: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1154: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1157: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1160: iconst_0
    //   1161: bipush #6
    //   1163: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1166: pop
    //   1167: iconst_0
    //   1168: istore #12
    //   1170: goto -> 1177
    //   1173: iload #24
    //   1175: istore #12
    //   1177: aload_1
    //   1178: astore #4
    //   1180: aload #7
    //   1182: astore #20
    //   1184: aload_0
    //   1185: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1188: astore #6
    //   1190: aload #6
    //   1192: ifnull -> 1210
    //   1195: aload #4
    //   1197: aload #6
    //   1199: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1202: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1205: astore #6
    //   1207: goto -> 1213
    //   1210: aconst_null
    //   1211: astore #6
    //   1213: aload_0
    //   1214: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1217: astore #7
    //   1219: aload #7
    //   1221: ifnull -> 1239
    //   1224: aload #4
    //   1226: aload #7
    //   1228: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1231: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1234: astore #7
    //   1236: goto -> 1242
    //   1239: aconst_null
    //   1240: astore #7
    //   1242: aload_0
    //   1243: aload_1
    //   1244: iload #9
    //   1246: aload #7
    //   1248: aload #6
    //   1250: aload_0
    //   1251: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1254: iconst_1
    //   1255: aaload
    //   1256: iload #10
    //   1258: aload_0
    //   1259: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1262: aload_0
    //   1263: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1266: aload_0
    //   1267: getfield mY : I
    //   1270: iload #13
    //   1272: aload_0
    //   1273: getfield mMinHeight : I
    //   1276: aload_0
    //   1277: getfield mMaxDimension : [I
    //   1280: iconst_1
    //   1281: iaload
    //   1282: aload_0
    //   1283: getfield mVerticalBiasPercent : F
    //   1286: iload #11
    //   1288: iload #8
    //   1290: iload #19
    //   1292: aload_0
    //   1293: getfield mMatchConstraintMinHeight : I
    //   1296: aload_0
    //   1297: getfield mMatchConstraintMaxHeight : I
    //   1300: aload_0
    //   1301: getfield mMatchConstraintPercentHeight : F
    //   1304: iload #12
    //   1306: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V
    //   1309: iload #14
    //   1311: ifeq -> 1366
    //   1314: aload_0
    //   1315: astore #6
    //   1317: aload #6
    //   1319: getfield mResolvedDimensionRatioSide : I
    //   1322: iconst_1
    //   1323: if_icmpne -> 1346
    //   1326: aload_1
    //   1327: aload #5
    //   1329: aload #20
    //   1331: aload_3
    //   1332: aload_2
    //   1333: aload #6
    //   1335: getfield mResolvedDimensionRatio : F
    //   1338: bipush #6
    //   1340: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   1343: goto -> 1366
    //   1346: aload_1
    //   1347: aload_3
    //   1348: aload_2
    //   1349: aload #5
    //   1351: aload #20
    //   1353: aload #6
    //   1355: getfield mResolvedDimensionRatio : F
    //   1358: bipush #6
    //   1360: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   1363: goto -> 1366
    //   1366: aload_0
    //   1367: astore #6
    //   1369: aload #6
    //   1371: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1374: invokevirtual isConnected : ()Z
    //   1377: ifeq -> 1419
    //   1380: aload_1
    //   1381: aload #6
    //   1383: aload #6
    //   1385: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1388: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1391: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1394: aload #6
    //   1396: getfield mCircleConstraintAngle : F
    //   1399: ldc_w 90.0
    //   1402: fadd
    //   1403: f2d
    //   1404: invokestatic toRadians : (D)D
    //   1407: d2f
    //   1408: aload #6
    //   1410: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1413: invokevirtual getMargin : ()I
    //   1416: invokevirtual addCenterPoint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   1419: return
  }
  
  public boolean allowedInBarrier() {
    boolean bool;
    if (this.mVisibility != 8) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void analyze(int paramInt) {
    Optimizer.analyze(paramInt, this);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0, ConstraintAnchor.Strength.STRONG);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    connect(paramType1, paramConstraintWidget, paramType2, paramInt, ConstraintAnchor.Strength.STRONG);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt, ConstraintAnchor.Strength paramStrength) {
    connect(paramType1, paramConstraintWidget, paramType2, paramInt, paramStrength, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, ConstraintAnchor.Strength paramStrength, int paramInt2) {
    ConstraintAnchor constraintAnchor;
    ConstraintAnchor.Type type = ConstraintAnchor.Type.CENTER;
    boolean bool = false;
    if (paramType1 == type) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.LEFT);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.RIGHT);
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
        bool = true;
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          paramInt1 = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0, paramStrength, paramInt2);
          paramInt1 = 1;
        } 
        if ((constraintAnchor1 != null && constraintAnchor1.isConnected()) || (constraintAnchor != null && constraintAnchor.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0, paramStrength, paramInt2);
        } 
        if (paramInt1 != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0, paramInt2);
        } else if (paramInt1 != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0, paramInt2);
        } else if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0, paramInt2);
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      ConstraintAnchor constraintAnchor2;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor, 0, paramInt2);
        constraintAnchor2.connect(constraintAnchor, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor, 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
      } else {
        ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
        constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
          if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
            constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
            constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
            if (constraintAnchor1 != null)
              constraintAnchor1.reset(); 
            paramInt1 = bool;
            if (constraintAnchor != null) {
              constraintAnchor.reset();
              paramInt1 = bool;
            } 
          } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
            constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
            if (constraintAnchor != null)
              constraintAnchor.reset(); 
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
            if (constraintAnchor.getTarget() != constraintAnchor2)
              constraintAnchor.reset(); 
            constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_Y);
            if (constraintAnchor.isConnected()) {
              constraintAnchor1.reset();
              constraintAnchor.reset();
            } 
          } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
            if (constraintAnchor.getTarget() != constraintAnchor2)
              constraintAnchor.reset(); 
            constraintAnchor = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
            constraintAnchor1 = getAnchor(ConstraintAnchor.Type.CENTER_X);
            if (constraintAnchor1.isConnected()) {
              constraintAnchor.reset();
              constraintAnchor1.reset();
            } 
          } 
          constraintAnchor3.connect(constraintAnchor2, paramInt1, paramStrength, paramInt2);
          constraintAnchor2.getOwner().connectedTo(constraintAnchor3.getOwner());
        } 
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    connect(paramConstraintAnchor1, paramConstraintAnchor2, paramInt, ConstraintAnchor.Strength.STRONG, 0);
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2) {
    connect(paramConstraintAnchor1, paramConstraintAnchor2, paramInt1, ConstraintAnchor.Strength.STRONG, paramInt2);
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, ConstraintAnchor.Strength paramStrength, int paramInt2) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt1, paramStrength, paramInt2); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void connectedTo(ConstraintWidget paramConstraintWidget) {}
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void disconnectUnlockedWidget(ConstraintWidget paramConstraintWidget) {
    ArrayList<ConstraintAnchor> arrayList = getAnchors();
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      ConstraintAnchor constraintAnchor = arrayList.get(b);
      if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == paramConstraintWidget && constraintAnchor.getConnectionCreator() == 2)
        constraintAnchor.reset(); 
    } 
  }
  
  public void disconnectWidget(ConstraintWidget paramConstraintWidget) {
    ArrayList<ConstraintAnchor> arrayList = getAnchors();
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      ConstraintAnchor constraintAnchor = arrayList.get(b);
      if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == paramConstraintWidget)
        constraintAnchor.reset(); 
    } 
  }
  
  public void forceUpdateDrawPosition() {
    int i = this.mX;
    int j = this.mY;
    int k = this.mWidth;
    int m = this.mHeight;
    this.mDrawX = i;
    this.mDrawY = j;
    this.mDrawWidth = k + i - i;
    this.mDrawHeight = m + j - j;
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public int getDrawBottom() {
    return getDrawY() + this.mDrawHeight;
  }
  
  public int getDrawHeight() {
    return this.mDrawHeight;
  }
  
  public int getDrawRight() {
    return getDrawX() + this.mDrawWidth;
  }
  
  public int getDrawWidth() {
    return this.mDrawWidth;
  }
  
  public int getDrawX() {
    return this.mDrawX + this.mOffsetX;
  }
  
  public int getDrawY() {
    return this.mDrawY + this.mOffsetY;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      constraintWidget = this;
      ConstraintWidget constraintWidget1 = null;
      while (true) {
        if (constraintWidget1 == null && constraintWidget != null) {
          ConstraintWidget constraintWidget2;
          ConstraintAnchor constraintAnchor2;
          ConstraintAnchor constraintAnchor1 = constraintWidget.getAnchor(ConstraintAnchor.Type.LEFT);
          if (constraintAnchor1 == null) {
            constraintAnchor1 = null;
          } else {
            constraintAnchor1 = constraintAnchor1.getTarget();
          } 
          if (constraintAnchor1 == null) {
            constraintAnchor1 = null;
          } else {
            constraintWidget2 = constraintAnchor1.getOwner();
          } 
          if (constraintWidget2 == getParent())
            break; 
          if (constraintWidget2 == null) {
            constraintAnchor2 = null;
          } else {
            constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
          } 
          if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget) {
            constraintWidget1 = constraintWidget;
            continue;
          } 
          constraintWidget = constraintWidget2;
          continue;
        } 
        constraintWidget = constraintWidget1;
        break;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getInternalDrawBottom() {
    return this.mDrawY + this.mDrawHeight;
  }
  
  public int getInternalDrawRight() {
    return this.mDrawX + this.mDrawWidth;
  }
  
  int getInternalDrawX() {
    return this.mDrawX;
  }
  
  int getInternalDrawY() {
    return this.mDrawY;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public ResolutionDimension getResolutionHeight() {
    if (this.mResolutionHeight == null)
      this.mResolutionHeight = new ResolutionDimension(); 
    return this.mResolutionHeight;
  }
  
  public ResolutionDimension getResolutionWidth() {
    if (this.mResolutionWidth == null)
      this.mResolutionWidth = new ResolutionDimension(); 
    return this.mResolutionWidth;
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  public WidgetContainer getRootWidgetContainer() {
    ConstraintWidget constraintWidget;
    for (constraintWidget = this; constraintWidget.getParent() != null; constraintWidget = constraintWidget.getParent());
    return (constraintWidget instanceof WidgetContainer) ? (WidgetContainer)constraintWidget : null;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      constraintWidget = this;
      ConstraintWidget constraintWidget1 = null;
      while (true) {
        if (constraintWidget1 == null && constraintWidget != null) {
          ConstraintWidget constraintWidget2;
          ConstraintAnchor constraintAnchor2;
          ConstraintAnchor constraintAnchor1 = constraintWidget.getAnchor(ConstraintAnchor.Type.TOP);
          if (constraintAnchor1 == null) {
            constraintAnchor1 = null;
          } else {
            constraintAnchor1 = constraintAnchor1.getTarget();
          } 
          if (constraintAnchor1 == null) {
            constraintAnchor1 = null;
          } else {
            constraintWidget2 = constraintAnchor1.getOwner();
          } 
          if (constraintWidget2 == getParent())
            break; 
          if (constraintWidget2 == null) {
            constraintAnchor2 = null;
          } else {
            constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
          } 
          if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget) {
            constraintWidget1 = constraintWidget;
            continue;
          } 
          constraintWidget = constraintWidget2;
          continue;
        } 
        constraintWidget = constraintWidget1;
        break;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapHeight() {
    return this.mWrapHeight;
  }
  
  public int getWrapWidth() {
    return this.mWrapWidth;
  }
  
  public int getX() {
    return this.mX;
  }
  
  public int getY() {
    return this.mY;
  }
  
  public boolean hasAncestor(ConstraintWidget paramConstraintWidget) {
    ConstraintWidget constraintWidget1 = getParent();
    if (constraintWidget1 == paramConstraintWidget)
      return true; 
    ConstraintWidget constraintWidget2 = constraintWidget1;
    if (constraintWidget1 == paramConstraintWidget.getParent())
      return false; 
    while (constraintWidget2 != null) {
      if (constraintWidget2 == paramConstraintWidget)
        return true; 
      if (constraintWidget2 == paramConstraintWidget.getParent())
        return true; 
      constraintWidget2 = constraintWidget2.getParent();
    } 
    return false;
  }
  
  public boolean hasBaseline() {
    boolean bool;
    if (this.mBaselineDistance > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, ConstraintAnchor.Strength.STRONG, 0, true);
  }
  
  public boolean isFullyResolved() {
    return ((this.mLeft.getResolutionNode()).state == 1 && (this.mRight.getResolutionNode()).state == 1 && (this.mTop.getResolutionNode()).state == 1 && (this.mBottom.getResolutionNode()).state == 1);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInsideConstraintLayout() {
    ConstraintWidget constraintWidget1 = getParent();
    ConstraintWidget constraintWidget2 = constraintWidget1;
    if (constraintWidget1 == null)
      return false; 
    while (constraintWidget2 != null) {
      if (constraintWidget2 instanceof ConstraintWidgetContainer)
        return true; 
      constraintWidget2 = constraintWidget2.getParent();
    } 
    return false;
  }
  
  public boolean isRoot() {
    boolean bool;
    if (this.mParent == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isRootContainer() {
    if (this instanceof ConstraintWidgetContainer) {
      ConstraintWidget constraintWidget = this.mParent;
      if (constraintWidget == null || !(constraintWidget instanceof ConstraintWidgetContainer))
        return true; 
    } 
    return false;
  }
  
  public boolean isSpreadHeight() {
    int i = this.mMatchConstraintDefaultHeight;
    boolean bool = true;
    if (i != 0 || this.mDimensionRatio != 0.0F || this.mMatchConstraintMinHeight != 0 || this.mMatchConstraintMaxHeight != 0 || this.mListDimensionBehaviors[1] != DimensionBehaviour.MATCH_CONSTRAINT)
      bool = false; 
    return bool;
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (i == 0) {
      bool2 = bool1;
      if (this.mDimensionRatio == 0.0F) {
        bool2 = bool1;
        if (this.mMatchConstraintMinWidth == 0) {
          bool2 = bool1;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool2 = bool1;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool2 = true; 
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mDrawX = 0;
    this.mDrawY = 0;
    this.mDrawWidth = 0;
    this.mDrawHeight = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    this.mWrapWidth = 0;
    this.mWrapHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt = this.mMaxDimension;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    ResolutionDimension resolutionDimension = this.mResolutionWidth;
    if (resolutionDimension != null)
      resolutionDimension.reset(); 
    resolutionDimension = this.mResolutionHeight;
    if (resolutionDimension != null)
      resolutionDimension.reset(); 
    this.mBelongingGroup = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
    if (this instanceof ConstraintWidgetContainer)
      return; 
    if (getHorizontalDimensionBehaviour() == DimensionBehaviour.MATCH_CONSTRAINT)
      if (getWidth() == getWrapWidth()) {
        setHorizontalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
      } else if (getWidth() > getMinWidth()) {
        setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
      }  
    if (getVerticalDimensionBehaviour() == DimensionBehaviour.MATCH_CONSTRAINT)
      if (getHeight() == getWrapHeight()) {
        setVerticalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
      } else if (getHeight() > getMinHeight()) {
        setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
      }  
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    byte b = 0;
    int i = this.mAnchors.size();
    while (b < i) {
      ((ConstraintAnchor)this.mAnchors.get(b)).reset();
      b++;
    } 
  }
  
  public void resetAnchors(int paramInt) {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    byte b = 0;
    int i = this.mAnchors.size();
    while (b < i) {
      ConstraintAnchor constraintAnchor = this.mAnchors.get(b);
      if (paramInt == constraintAnchor.getConnectionCreator()) {
        if (constraintAnchor.isVerticalAnchor()) {
          setVerticalBiasPercent(DEFAULT_BIAS);
        } else {
          setHorizontalBiasPercent(DEFAULT_BIAS);
        } 
        constraintAnchor.reset();
      } 
      b++;
    } 
  }
  
  public void resetResolutionNodes() {
    for (byte b = 0; b < 6; b++)
      this.mListAnchors[b].getResolutionNode().reset(); 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resolve() {}
  
  public void setBaselineDistance(int paramInt) {
    this.mBaselineDistance = paramInt;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
    } else {
      this.mContainerItemSkip = 0;
    } 
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".left");
    solverVariable1.setName(stringBuilder3.toString());
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".top");
    solverVariable2.setName(stringBuilder3.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".right");
    solverVariable3.setName(stringBuilder1.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable4.setName(stringBuilder2.toString());
    if (this.mBaselineDistance > 0) {
      SolverVariable solverVariable = paramLinearSystem.createObjectVariable(this.mBaseline);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(".baseline");
      solverVariable.setName(stringBuilder.toString());
    } 
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 263
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 263
    //   14: iconst_m1
    //   15: istore_2
    //   16: aload_1
    //   17: invokevirtual length : ()I
    //   20: istore_3
    //   21: aload_1
    //   22: bipush #44
    //   24: invokevirtual indexOf : (I)I
    //   27: istore #4
    //   29: iconst_0
    //   30: istore #5
    //   32: iload_2
    //   33: istore #6
    //   35: iload #5
    //   37: istore #7
    //   39: iload #4
    //   41: ifle -> 108
    //   44: iload_2
    //   45: istore #6
    //   47: iload #5
    //   49: istore #7
    //   51: iload #4
    //   53: iload_3
    //   54: iconst_1
    //   55: isub
    //   56: if_icmpge -> 108
    //   59: aload_1
    //   60: iconst_0
    //   61: iload #4
    //   63: invokevirtual substring : (II)Ljava/lang/String;
    //   66: astore #8
    //   68: aload #8
    //   70: ldc_w 'W'
    //   73: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   76: ifeq -> 85
    //   79: iconst_0
    //   80: istore #6
    //   82: goto -> 102
    //   85: iload_2
    //   86: istore #6
    //   88: aload #8
    //   90: ldc_w 'H'
    //   93: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   96: ifeq -> 102
    //   99: iconst_1
    //   100: istore #6
    //   102: iload #4
    //   104: iconst_1
    //   105: iadd
    //   106: istore #7
    //   108: aload_1
    //   109: bipush #58
    //   111: invokevirtual indexOf : (I)I
    //   114: istore_2
    //   115: iload_2
    //   116: iflt -> 217
    //   119: iload_2
    //   120: iload_3
    //   121: iconst_1
    //   122: isub
    //   123: if_icmpge -> 217
    //   126: aload_1
    //   127: iload #7
    //   129: iload_2
    //   130: invokevirtual substring : (II)Ljava/lang/String;
    //   133: astore #8
    //   135: aload_1
    //   136: iload_2
    //   137: iconst_1
    //   138: iadd
    //   139: invokevirtual substring : (I)Ljava/lang/String;
    //   142: astore_1
    //   143: aload #8
    //   145: invokevirtual length : ()I
    //   148: ifle -> 240
    //   151: aload_1
    //   152: invokevirtual length : ()I
    //   155: ifle -> 240
    //   158: aload #8
    //   160: invokestatic parseFloat : (Ljava/lang/String;)F
    //   163: fstore #9
    //   165: aload_1
    //   166: invokestatic parseFloat : (Ljava/lang/String;)F
    //   169: fstore #10
    //   171: fload #9
    //   173: fconst_0
    //   174: fcmpl
    //   175: ifle -> 240
    //   178: fload #10
    //   180: fconst_0
    //   181: fcmpl
    //   182: ifle -> 240
    //   185: iload #6
    //   187: iconst_1
    //   188: if_icmpne -> 204
    //   191: fload #10
    //   193: fload #9
    //   195: fdiv
    //   196: invokestatic abs : (F)F
    //   199: fstore #10
    //   201: goto -> 243
    //   204: fload #9
    //   206: fload #10
    //   208: fdiv
    //   209: invokestatic abs : (F)F
    //   212: fstore #10
    //   214: goto -> 243
    //   217: aload_1
    //   218: iload #7
    //   220: invokevirtual substring : (I)Ljava/lang/String;
    //   223: astore_1
    //   224: aload_1
    //   225: invokevirtual length : ()I
    //   228: ifle -> 240
    //   231: aload_1
    //   232: invokestatic parseFloat : (Ljava/lang/String;)F
    //   235: fstore #10
    //   237: goto -> 243
    //   240: fconst_0
    //   241: fstore #10
    //   243: fload #10
    //   245: fconst_0
    //   246: fcmpl
    //   247: ifle -> 262
    //   250: aload_0
    //   251: fload #10
    //   253: putfield mDimensionRatio : F
    //   256: aload_0
    //   257: iload #6
    //   259: putfield mDimensionRatioSide : I
    //   262: return
    //   263: aload_0
    //   264: fconst_0
    //   265: putfield mDimensionRatio : F
    //   268: return
    //   269: astore_1
    //   270: goto -> 240
    // Exception table:
    //   from	to	target	type
    //   158	171	269	java/lang/NumberFormatException
    //   191	201	269	java/lang/NumberFormatException
    //   204	214	269	java/lang/NumberFormatException
    //   231	237	269	java/lang/NumberFormatException
  }
  
  public void setDrawHeight(int paramInt) {
    this.mDrawHeight = paramInt;
  }
  
  public void setDrawOrigin(int paramInt1, int paramInt2) {
    paramInt1 -= this.mOffsetX;
    this.mDrawX = paramInt1;
    paramInt2 -= this.mOffsetY;
    this.mDrawY = paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setDrawWidth(int paramInt) {
    this.mDrawWidth = paramInt;
  }
  
  public void setDrawX(int paramInt) {
    paramInt -= this.mOffsetX;
    this.mDrawX = paramInt;
    this.mX = paramInt;
  }
  
  public void setDrawY(int paramInt) {
    paramInt -= this.mOffsetY;
    this.mDrawY = paramInt;
    this.mY = paramInt;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
    } else if (paramInt3 == 1) {
      setVerticalDimension(paramInt1, paramInt2);
    } 
    this.mOptimizerMeasured = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
    paramInt1 = this.mWidth;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
    this.mOptimizerMeasured = true;
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            this.mBottom.mGoneMargin = paramInt; 
        } else {
          this.mRight.mGoneMargin = paramInt;
        } 
      } else {
        this.mTop.mGoneMargin = paramInt;
      } 
    } else {
      this.mLeft.mGoneMargin = paramInt;
    } 
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt2 -= paramInt1;
    this.mWidth = paramInt2;
    paramInt1 = this.mMinWidth;
    if (paramInt2 < paramInt1)
      this.mWidth = paramInt1; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
    if (paramDimensionBehaviour == DimensionBehaviour.WRAP_CONTENT)
      setWidth(this.mWrapWidth); 
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    this.mMatchConstraintMaxWidth = paramInt3;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
    } else if (paramInt2 == 1) {
      setHeight(paramInt1);
    } 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
    } else {
      this.mMinHeight = paramInt;
    } 
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
    } else {
      this.mMinWidth = paramInt;
    } 
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
    } else if (paramInt2 == 1) {
      this.mRelY = paramInt1;
    } 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
    if (paramDimensionBehaviour == DimensionBehaviour.WRAP_CONTENT)
      setHeight(this.mWrapHeight); 
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    this.mMatchConstraintMaxHeight = paramInt3;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapHeight(int paramInt) {
    this.mWrapHeight = paramInt;
  }
  
  public void setWrapWidth(int paramInt) {
    this.mWrapWidth = paramInt;
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean1 && !paramBoolean2) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean1 && paramBoolean2) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1)
      if (this.mMatchConstraintMinWidth > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1 && paramBoolean1 && paramBoolean2) {
      this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
      this.mResolvedDimensionRatioSide = 1;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(") wrap: (");
    stringBuilder.append(this.mWrapWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mWrapHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateDrawPosition() {
    int i = this.mX;
    int j = this.mY;
    int k = this.mWidth;
    int m = this.mHeight;
    this.mDrawX = i;
    this.mDrawY = j;
    this.mDrawWidth = k + i - i;
    this.mDrawHeight = m + j - j;
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore_2
    //   9: aload_1
    //   10: aload_0
    //   11: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   17: istore_3
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   23: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   26: istore #4
    //   28: aload_1
    //   29: aload_0
    //   30: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   36: istore #5
    //   38: iload #4
    //   40: iload_2
    //   41: isub
    //   42: iflt -> 112
    //   45: iload #5
    //   47: iload_3
    //   48: isub
    //   49: iflt -> 112
    //   52: iload_2
    //   53: ldc_w -2147483648
    //   56: if_icmpeq -> 112
    //   59: iload_2
    //   60: ldc 2147483647
    //   62: if_icmpeq -> 112
    //   65: iload_3
    //   66: ldc_w -2147483648
    //   69: if_icmpeq -> 112
    //   72: iload_3
    //   73: ldc 2147483647
    //   75: if_icmpeq -> 112
    //   78: iload #4
    //   80: ldc_w -2147483648
    //   83: if_icmpeq -> 112
    //   86: iload #4
    //   88: ldc 2147483647
    //   90: if_icmpeq -> 112
    //   93: iload #5
    //   95: ldc_w -2147483648
    //   98: if_icmpeq -> 112
    //   101: iload #5
    //   103: istore #6
    //   105: iload #5
    //   107: ldc 2147483647
    //   109: if_icmpne -> 122
    //   112: iconst_0
    //   113: istore #6
    //   115: iconst_0
    //   116: istore_2
    //   117: iconst_0
    //   118: istore_3
    //   119: iconst_0
    //   120: istore #4
    //   122: aload_0
    //   123: iload_2
    //   124: iload_3
    //   125: iload #4
    //   127: iload #6
    //   129: invokevirtual setFrame : (IIII)V
    //   132: return
  }
  
  public void updateResolutionNodes() {
    for (byte b = 0; b < 6; b++)
      this.mListAnchors[b].getResolutionNode().update(); 
  }
  
  public enum ContentAlignment {
    BEGIN, BOTTOM, END, LEFT, MIDDLE, RIGHT, TOP, VERTICAL_MIDDLE;
    
    static {
      BOTTOM = new ContentAlignment("BOTTOM", 5);
      LEFT = new ContentAlignment("LEFT", 6);
      ContentAlignment contentAlignment = new ContentAlignment("RIGHT", 7);
      RIGHT = contentAlignment;
      $VALUES = new ContentAlignment[] { BEGIN, MIDDLE, END, TOP, VERTICAL_MIDDLE, BOTTOM, LEFT, contentAlignment };
    }
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour;
      $VALUES = new DimensionBehaviour[] { FIXED, WRAP_CONTENT, MATCH_CONSTRAINT, dimensionBehaviour };
    }
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */