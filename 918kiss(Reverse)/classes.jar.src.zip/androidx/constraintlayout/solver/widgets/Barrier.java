package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.ArrayList;

public class Barrier extends Helper {
  public static final int BOTTOM = 3;
  
  public static final int LEFT = 0;
  
  public static final int RIGHT = 1;
  
  public static final int TOP = 2;
  
  private boolean mAllowsGoneWidget = true;
  
  private int mBarrierType = 0;
  
  private ArrayList<ResolutionAnchor> mNodes = new ArrayList<ResolutionAnchor>(4);
  
  public void addToSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   4: iconst_0
    //   5: aload_0
    //   6: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   9: aastore
    //   10: aload_0
    //   11: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: iconst_2
    //   15: aload_0
    //   16: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   19: aastore
    //   20: aload_0
    //   21: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   24: iconst_1
    //   25: aload_0
    //   26: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   29: aastore
    //   30: aload_0
    //   31: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   34: iconst_3
    //   35: aload_0
    //   36: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   39: aastore
    //   40: iconst_0
    //   41: istore_2
    //   42: iload_2
    //   43: aload_0
    //   44: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   47: arraylength
    //   48: if_icmpge -> 76
    //   51: aload_0
    //   52: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   55: iload_2
    //   56: aaload
    //   57: aload_1
    //   58: aload_0
    //   59: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   62: iload_2
    //   63: aaload
    //   64: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   67: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   70: iinc #2, 1
    //   73: goto -> 42
    //   76: aload_0
    //   77: getfield mBarrierType : I
    //   80: istore_2
    //   81: iload_2
    //   82: iflt -> 617
    //   85: iload_2
    //   86: iconst_4
    //   87: if_icmpge -> 617
    //   90: aload_0
    //   91: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   94: aload_0
    //   95: getfield mBarrierType : I
    //   98: aaload
    //   99: astore_3
    //   100: iconst_0
    //   101: istore_2
    //   102: iload_2
    //   103: aload_0
    //   104: getfield mWidgetsCount : I
    //   107: if_icmpge -> 208
    //   110: aload_0
    //   111: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   114: iload_2
    //   115: aaload
    //   116: astore #4
    //   118: aload_0
    //   119: getfield mAllowsGoneWidget : Z
    //   122: ifne -> 136
    //   125: aload #4
    //   127: invokevirtual allowedInBarrier : ()Z
    //   130: ifne -> 136
    //   133: goto -> 202
    //   136: aload_0
    //   137: getfield mBarrierType : I
    //   140: istore #5
    //   142: iload #5
    //   144: ifeq -> 153
    //   147: iload #5
    //   149: iconst_1
    //   150: if_icmpne -> 170
    //   153: aload #4
    //   155: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   158: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   161: if_acmpne -> 170
    //   164: iconst_1
    //   165: istore #6
    //   167: goto -> 211
    //   170: aload_0
    //   171: getfield mBarrierType : I
    //   174: istore #5
    //   176: iload #5
    //   178: iconst_2
    //   179: if_icmpeq -> 188
    //   182: iload #5
    //   184: iconst_3
    //   185: if_icmpne -> 202
    //   188: aload #4
    //   190: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   193: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   196: if_acmpne -> 202
    //   199: goto -> 164
    //   202: iinc #2, 1
    //   205: goto -> 102
    //   208: iconst_0
    //   209: istore #6
    //   211: aload_0
    //   212: getfield mBarrierType : I
    //   215: istore_2
    //   216: iload_2
    //   217: ifeq -> 244
    //   220: iload_2
    //   221: iconst_1
    //   222: if_icmpne -> 228
    //   225: goto -> 244
    //   228: aload_0
    //   229: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   232: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   235: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   238: if_acmpne -> 260
    //   241: goto -> 257
    //   244: aload_0
    //   245: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   248: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   251: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   254: if_acmpne -> 260
    //   257: iconst_0
    //   258: istore #6
    //   260: iconst_0
    //   261: istore_2
    //   262: iload_2
    //   263: aload_0
    //   264: getfield mWidgetsCount : I
    //   267: if_icmpge -> 380
    //   270: aload_0
    //   271: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   274: iload_2
    //   275: aaload
    //   276: astore #7
    //   278: aload_0
    //   279: getfield mAllowsGoneWidget : Z
    //   282: ifne -> 296
    //   285: aload #7
    //   287: invokevirtual allowedInBarrier : ()Z
    //   290: ifne -> 296
    //   293: goto -> 374
    //   296: aload_1
    //   297: aload #7
    //   299: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   302: aload_0
    //   303: getfield mBarrierType : I
    //   306: aaload
    //   307: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   310: astore #4
    //   312: aload #7
    //   314: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   317: aload_0
    //   318: getfield mBarrierType : I
    //   321: aaload
    //   322: aload #4
    //   324: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   327: aload_0
    //   328: getfield mBarrierType : I
    //   331: istore #5
    //   333: iload #5
    //   335: ifeq -> 362
    //   338: iload #5
    //   340: iconst_2
    //   341: if_icmpne -> 347
    //   344: goto -> 362
    //   347: aload_1
    //   348: aload_3
    //   349: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   352: aload #4
    //   354: iload #6
    //   356: invokevirtual addGreaterBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Z)V
    //   359: goto -> 374
    //   362: aload_1
    //   363: aload_3
    //   364: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   367: aload #4
    //   369: iload #6
    //   371: invokevirtual addLowerBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Z)V
    //   374: iinc #2, 1
    //   377: goto -> 262
    //   380: aload_0
    //   381: getfield mBarrierType : I
    //   384: istore_2
    //   385: iload_2
    //   386: ifne -> 443
    //   389: aload_1
    //   390: aload_0
    //   391: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   394: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   397: aload_0
    //   398: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   401: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   404: iconst_0
    //   405: bipush #6
    //   407: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   410: pop
    //   411: iload #6
    //   413: ifne -> 617
    //   416: aload_1
    //   417: aload_0
    //   418: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   421: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   424: aload_0
    //   425: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   428: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   431: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   434: iconst_0
    //   435: iconst_5
    //   436: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   439: pop
    //   440: goto -> 617
    //   443: iload_2
    //   444: iconst_1
    //   445: if_icmpne -> 502
    //   448: aload_1
    //   449: aload_0
    //   450: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   453: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   456: aload_0
    //   457: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   460: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   463: iconst_0
    //   464: bipush #6
    //   466: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   469: pop
    //   470: iload #6
    //   472: ifne -> 617
    //   475: aload_1
    //   476: aload_0
    //   477: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   480: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   483: aload_0
    //   484: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   487: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   490: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   493: iconst_0
    //   494: iconst_5
    //   495: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   498: pop
    //   499: goto -> 617
    //   502: iload_2
    //   503: iconst_2
    //   504: if_icmpne -> 561
    //   507: aload_1
    //   508: aload_0
    //   509: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   512: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   515: aload_0
    //   516: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   519: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   522: iconst_0
    //   523: bipush #6
    //   525: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   528: pop
    //   529: iload #6
    //   531: ifne -> 617
    //   534: aload_1
    //   535: aload_0
    //   536: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   539: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   542: aload_0
    //   543: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   546: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   549: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   552: iconst_0
    //   553: iconst_5
    //   554: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   557: pop
    //   558: goto -> 617
    //   561: iload_2
    //   562: iconst_3
    //   563: if_icmpne -> 617
    //   566: aload_1
    //   567: aload_0
    //   568: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   571: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   574: aload_0
    //   575: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   578: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   581: iconst_0
    //   582: bipush #6
    //   584: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   587: pop
    //   588: iload #6
    //   590: ifne -> 617
    //   593: aload_1
    //   594: aload_0
    //   595: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   598: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   601: aload_0
    //   602: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   605: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   608: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   611: iconst_0
    //   612: iconst_5
    //   613: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   616: pop
    //   617: return
  }
  
  public boolean allowedInBarrier() {
    return true;
  }
  
  public boolean allowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public void analyze(int paramInt) {
    ResolutionAnchor resolutionAnchor;
    if (this.mParent == null)
      return; 
    if (!((ConstraintWidgetContainer)this.mParent).optimizeFor(2))
      return; 
    paramInt = this.mBarrierType;
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3)
            return; 
          resolutionAnchor = this.mBottom.getResolutionNode();
        } else {
          resolutionAnchor = this.mTop.getResolutionNode();
        } 
      } else {
        resolutionAnchor = this.mRight.getResolutionNode();
      } 
    } else {
      resolutionAnchor = this.mLeft.getResolutionNode();
    } 
    resolutionAnchor.setType(5);
    paramInt = this.mBarrierType;
    if (paramInt == 0 || paramInt == 1) {
      this.mTop.getResolutionNode().resolve((ResolutionAnchor)null, 0.0F);
      this.mBottom.getResolutionNode().resolve((ResolutionAnchor)null, 0.0F);
    } else {
      this.mLeft.getResolutionNode().resolve((ResolutionAnchor)null, 0.0F);
      this.mRight.getResolutionNode().resolve((ResolutionAnchor)null, 0.0F);
    } 
    this.mNodes.clear();
    for (paramInt = 0; paramInt < this.mWidgetsCount; paramInt++) {
      ConstraintWidget constraintWidget = this.mWidgets[paramInt];
      if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
        ResolutionAnchor resolutionAnchor1;
        int i = this.mBarrierType;
        if (i != 0) {
          if (i != 1) {
            if (i != 2) {
              if (i != 3) {
                constraintWidget = null;
              } else {
                resolutionAnchor1 = constraintWidget.mBottom.getResolutionNode();
              } 
            } else {
              resolutionAnchor1 = ((ConstraintWidget)resolutionAnchor1).mTop.getResolutionNode();
            } 
          } else {
            resolutionAnchor1 = ((ConstraintWidget)resolutionAnchor1).mRight.getResolutionNode();
          } 
        } else {
          resolutionAnchor1 = ((ConstraintWidget)resolutionAnchor1).mLeft.getResolutionNode();
        } 
        if (resolutionAnchor1 != null) {
          this.mNodes.add(resolutionAnchor1);
          resolutionAnchor1.addDependent(resolutionAnchor);
        } 
      } 
    } 
  }
  
  public void resetResolutionNodes() {
    super.resetResolutionNodes();
    this.mNodes.clear();
  }
  
  public void resolve() {
    int i = this.mBarrierType;
    float f1 = Float.MAX_VALUE;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          ResolutionAnchor resolutionAnchor = this.mBottom.getResolutionNode();
        } else {
          ResolutionAnchor resolutionAnchor = this.mTop.getResolutionNode();
          int k = this.mNodes.size();
          Object object1 = null;
          i = 0;
          float f = f1;
        } 
      } else {
        ResolutionAnchor resolutionAnchor = this.mRight.getResolutionNode();
      } 
      f1 = 0.0F;
    } else {
      ResolutionAnchor resolutionAnchor = this.mLeft.getResolutionNode();
    } 
    int j = this.mNodes.size();
    Object object = null;
    i = 0;
    float f2 = f1;
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.mAllowsGoneWidget = paramBoolean;
  }
  
  public void setBarrierType(int paramInt) {
    this.mBarrierType = paramInt;
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\constraintlayout\solver\widgets\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */