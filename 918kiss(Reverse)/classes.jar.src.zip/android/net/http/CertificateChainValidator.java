package android.net.http;

import java.io.IOException;
import javax.net.ssl.SSLSocket;

public class CertificateChainValidator {
  CertificateChainValidator() {
    throw new RuntimeException("Stub!");
  }
  
  public static CertificateChainValidator getInstance() {
    throw new RuntimeException("Stub!");
  }
  
  public static void handleTrustStorageUpdate() {
    throw new RuntimeException("Stub!");
  }
  
  public static SslError verifyServerCertificates(byte[][] paramArrayOfbyte, String paramString1, String paramString2) throws IOException {
    throw new RuntimeException("Stub!");
  }
  
  public SslError doHandshakeAndValidateServerCertificates(HttpsConnection paramHttpsConnection, SSLSocket paramSSLSocket, String paramString) throws IOException {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\android\net\http\CertificateChainValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */