package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class PathParser {
  private static final String LOGTAG = "PathParser";
  
  private static void addNode(ArrayList<PathDataNode> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new PathDataNode(paramChar, paramArrayOffloat));
  }
  
  public static boolean canMorph(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    if (paramArrayOfPathDataNode1 == null || paramArrayOfPathDataNode2 == null)
      return false; 
    if (paramArrayOfPathDataNode1.length != paramArrayOfPathDataNode2.length)
      return false; 
    for (byte b = 0; b < paramArrayOfPathDataNode1.length; b++) {
      if ((paramArrayOfPathDataNode1[b]).mType != (paramArrayOfPathDataNode2[b]).mType || (paramArrayOfPathDataNode1[b]).mParams.length != (paramArrayOfPathDataNode2[b]).mParams.length)
        return false; 
    } 
    return true;
  }
  
  static float[] copyOfRange(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        paramInt2 -= paramInt1;
        i = Math.min(paramInt2, i - paramInt1);
        float[] arrayOfFloat = new float[paramInt2];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, i);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  public static PathDataNode[] createNodesFromPathData(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<PathDataNode> arrayList = new ArrayList();
    int i = 1;
    int j = 0;
    while (i < paramString.length()) {
      i = nextStart(paramString, i);
      String str = paramString.substring(j, i).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = getFloats(str);
        addNode(arrayList, str.charAt(0), arrayOfFloat);
      } 
      j = i;
      i++;
    } 
    if (i - j == 1 && j < paramString.length())
      addNode(arrayList, paramString.charAt(j), new float[0]); 
    return arrayList.<PathDataNode>toArray(new PathDataNode[arrayList.size()]);
  }
  
  public static Path createPathFromPathData(String paramString) {
    Path path = new Path();
    PathDataNode[] arrayOfPathDataNode = createNodesFromPathData(paramString);
    if (arrayOfPathDataNode != null)
      try {
        PathDataNode.nodesToPath(arrayOfPathDataNode, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static PathDataNode[] deepCopyNodes(PathDataNode[] paramArrayOfPathDataNode) {
    if (paramArrayOfPathDataNode == null)
      return null; 
    PathDataNode[] arrayOfPathDataNode = new PathDataNode[paramArrayOfPathDataNode.length];
    for (byte b = 0; b < paramArrayOfPathDataNode.length; b++)
      arrayOfPathDataNode[b] = new PathDataNode(paramArrayOfPathDataNode[b]); 
    return arrayOfPathDataNode;
  }
  
  private static void extract(String paramString, int paramInt, ExtractFloatResult paramExtractFloatResult) {
    paramExtractFloatResult.mEndWithNegOrDot = false;
    int i = paramInt;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != ' ') {
        if (c != 'E' && c != 'e') {
          switch (c) {
            default:
              bool1 = false;
              break;
            case '.':
              if (!bool2) {
                bool1 = false;
                bool2 = true;
                break;
              } 
              paramExtractFloatResult.mEndWithNegOrDot = true;
            case '-':
            
            case ',':
              bool1 = false;
              bool3 = true;
              break;
          } 
        } else {
          bool1 = true;
        } 
        if (bool3)
          break; 
        continue;
      } 
      i++;
    } 
    paramExtractFloatResult.mEndPosition = i;
  }
  
  private static float[] getFloats(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      float[] arrayOfFloat = new float[paramString.length()];
      ExtractFloatResult extractFloatResult = new ExtractFloatResult();
      this();
      int i = paramString.length();
      int j = 1;
      int k;
      for (k = 0; j < i; k = n) {
        extract(paramString, j, extractFloatResult);
        int m = extractFloatResult.mEndPosition;
        int n = k;
        if (j < m) {
          arrayOfFloat[k] = Float.parseFloat(paramString.substring(j, m));
          n = k + 1;
        } 
        if (extractFloatResult.mEndWithNegOrDot) {
          j = m;
          k = n;
          continue;
        } 
        j = m + 1;
      } 
      return copyOfRange(arrayOfFloat, 0, k);
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  public static boolean interpolatePathDataNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2, PathDataNode[] paramArrayOfPathDataNode3, float paramFloat) {
    if (paramArrayOfPathDataNode1 != null && paramArrayOfPathDataNode2 != null && paramArrayOfPathDataNode3 != null) {
      if (paramArrayOfPathDataNode1.length == paramArrayOfPathDataNode2.length && paramArrayOfPathDataNode2.length == paramArrayOfPathDataNode3.length) {
        boolean bool = canMorph(paramArrayOfPathDataNode2, paramArrayOfPathDataNode3);
        byte b = 0;
        if (!bool)
          return false; 
        while (b < paramArrayOfPathDataNode1.length) {
          paramArrayOfPathDataNode1[b].interpolatePathDataNode(paramArrayOfPathDataNode2[b], paramArrayOfPathDataNode3[b], paramFloat);
          b++;
        } 
        return true;
      } 
      throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
    throw illegalArgumentException;
  }
  
  private static int nextStart(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  public static void updateNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    for (byte b = 0; b < paramArrayOfPathDataNode2.length; b++) {
      (paramArrayOfPathDataNode1[b]).mType = (char)(paramArrayOfPathDataNode2[b]).mType;
      for (byte b1 = 0; b1 < (paramArrayOfPathDataNode2[b]).mParams.length; b1++)
        (paramArrayOfPathDataNode1[b]).mParams[b1] = (paramArrayOfPathDataNode2[b]).mParams[b1]; 
    } 
  }
  
  private static class ExtractFloatResult {
    int mEndPosition;
    
    boolean mEndWithNegOrDot;
  }
  
  public static class PathDataNode {
    public float[] mParams;
    
    public char mType;
    
    PathDataNode(char param1Char, float[] param1ArrayOffloat) {
      this.mType = (char)param1Char;
      this.mParams = param1ArrayOffloat;
    }
    
    PathDataNode(PathDataNode param1PathDataNode) {
      this.mType = (char)param1PathDataNode.mType;
      float[] arrayOfFloat = param1PathDataNode.mParams;
      this.mParams = PathParser.copyOfRange(arrayOfFloat, 0, arrayOfFloat.length);
    }
    
    private static void addCommand(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: faload
      //   3: fstore #5
      //   5: aload_1
      //   6: iconst_1
      //   7: faload
      //   8: fstore #6
      //   10: aload_1
      //   11: iconst_2
      //   12: faload
      //   13: fstore #7
      //   15: aload_1
      //   16: iconst_3
      //   17: faload
      //   18: fstore #8
      //   20: aload_1
      //   21: iconst_4
      //   22: faload
      //   23: fstore #9
      //   25: aload_1
      //   26: iconst_5
      //   27: faload
      //   28: fstore #10
      //   30: fload #5
      //   32: fstore #11
      //   34: fload #6
      //   36: fstore #12
      //   38: fload #7
      //   40: fstore #13
      //   42: fload #8
      //   44: fstore #14
      //   46: iload_3
      //   47: lookupswitch default -> 216, 65 -> 336, 67 -> 313, 72 -> 291, 76 -> 232, 77 -> 232, 81 -> 269, 83 -> 269, 84 -> 232, 86 -> 291, 90 -> 238, 97 -> 336, 99 -> 313, 104 -> 291, 108 -> 232, 109 -> 232, 113 -> 269, 115 -> 269, 116 -> 232, 118 -> 291, 122 -> 238
      //   216: fload #8
      //   218: fstore #14
      //   220: fload #7
      //   222: fstore #13
      //   224: fload #6
      //   226: fstore #12
      //   228: fload #5
      //   230: fstore #11
      //   232: iconst_2
      //   233: istore #15
      //   235: goto -> 356
      //   238: aload_0
      //   239: invokevirtual close : ()V
      //   242: aload_0
      //   243: fload #9
      //   245: fload #10
      //   247: invokevirtual moveTo : (FF)V
      //   250: fload #9
      //   252: fstore #11
      //   254: fload #11
      //   256: fstore #13
      //   258: fload #10
      //   260: fstore #12
      //   262: fload #12
      //   264: fstore #14
      //   266: goto -> 232
      //   269: iconst_4
      //   270: istore #15
      //   272: fload #5
      //   274: fstore #11
      //   276: fload #6
      //   278: fstore #12
      //   280: fload #7
      //   282: fstore #13
      //   284: fload #8
      //   286: fstore #14
      //   288: goto -> 356
      //   291: iconst_1
      //   292: istore #15
      //   294: fload #5
      //   296: fstore #11
      //   298: fload #6
      //   300: fstore #12
      //   302: fload #7
      //   304: fstore #13
      //   306: fload #8
      //   308: fstore #14
      //   310: goto -> 356
      //   313: bipush #6
      //   315: istore #15
      //   317: fload #5
      //   319: fstore #11
      //   321: fload #6
      //   323: fstore #12
      //   325: fload #7
      //   327: fstore #13
      //   329: fload #8
      //   331: fstore #14
      //   333: goto -> 356
      //   336: bipush #7
      //   338: istore #15
      //   340: fload #8
      //   342: fstore #14
      //   344: fload #7
      //   346: fstore #13
      //   348: fload #6
      //   350: fstore #12
      //   352: fload #5
      //   354: fstore #11
      //   356: iconst_0
      //   357: istore #16
      //   359: iload_2
      //   360: istore #17
      //   362: fload #10
      //   364: fstore #6
      //   366: fload #9
      //   368: fstore #5
      //   370: iload #16
      //   372: istore_2
      //   373: iload_3
      //   374: istore #16
      //   376: iload_2
      //   377: aload #4
      //   379: arraylength
      //   380: if_icmpge -> 2145
      //   383: iload #16
      //   385: bipush #65
      //   387: if_icmpeq -> 1991
      //   390: iload #16
      //   392: bipush #67
      //   394: if_icmpeq -> 1878
      //   397: iload #16
      //   399: bipush #72
      //   401: if_icmpeq -> 1852
      //   404: iload #16
      //   406: bipush #81
      //   408: if_icmpeq -> 1761
      //   411: iload #16
      //   413: bipush #86
      //   415: if_icmpeq -> 1735
      //   418: iload #16
      //   420: bipush #97
      //   422: if_icmpeq -> 1595
      //   425: iload #16
      //   427: bipush #99
      //   429: if_icmpeq -> 1452
      //   432: iload #16
      //   434: bipush #104
      //   436: if_icmpeq -> 1424
      //   439: iload #16
      //   441: bipush #113
      //   443: if_icmpeq -> 1324
      //   446: iload #16
      //   448: bipush #118
      //   450: if_icmpeq -> 1299
      //   453: iload #16
      //   455: bipush #76
      //   457: if_icmpeq -> 1254
      //   460: iload #16
      //   462: bipush #77
      //   464: if_icmpeq -> 1184
      //   467: iload #16
      //   469: bipush #83
      //   471: if_icmpeq -> 1039
      //   474: iload #16
      //   476: bipush #84
      //   478: if_icmpeq -> 928
      //   481: iload #16
      //   483: bipush #108
      //   485: if_icmpeq -> 873
      //   488: iload #16
      //   490: bipush #109
      //   492: if_icmpeq -> 805
      //   495: iload #16
      //   497: bipush #115
      //   499: if_icmpeq -> 643
      //   502: iload #16
      //   504: bipush #116
      //   506: if_icmpeq -> 512
      //   509: goto -> 2134
      //   512: iload #17
      //   514: bipush #113
      //   516: if_icmpeq -> 552
      //   519: iload #17
      //   521: bipush #116
      //   523: if_icmpeq -> 552
      //   526: iload #17
      //   528: bipush #81
      //   530: if_icmpeq -> 552
      //   533: iload #17
      //   535: bipush #84
      //   537: if_icmpne -> 543
      //   540: goto -> 552
      //   543: fconst_0
      //   544: fstore #14
      //   546: fconst_0
      //   547: fstore #13
      //   549: goto -> 566
      //   552: fload #11
      //   554: fload #13
      //   556: fsub
      //   557: fstore #13
      //   559: fload #12
      //   561: fload #14
      //   563: fsub
      //   564: fstore #14
      //   566: iload_2
      //   567: iconst_0
      //   568: iadd
      //   569: istore #17
      //   571: aload #4
      //   573: iload #17
      //   575: faload
      //   576: fstore #10
      //   578: iload_2
      //   579: iconst_1
      //   580: iadd
      //   581: istore #16
      //   583: aload_0
      //   584: fload #13
      //   586: fload #14
      //   588: fload #10
      //   590: aload #4
      //   592: iload #16
      //   594: faload
      //   595: invokevirtual rQuadTo : (FFFF)V
      //   598: fload #11
      //   600: aload #4
      //   602: iload #17
      //   604: faload
      //   605: fadd
      //   606: fstore #10
      //   608: fload #12
      //   610: aload #4
      //   612: iload #16
      //   614: faload
      //   615: fadd
      //   616: fstore #9
      //   618: fload #14
      //   620: fload #12
      //   622: fadd
      //   623: fstore #14
      //   625: fload #13
      //   627: fload #11
      //   629: fadd
      //   630: fstore #13
      //   632: fload #9
      //   634: fstore #12
      //   636: fload #10
      //   638: fstore #11
      //   640: goto -> 509
      //   643: iload #17
      //   645: bipush #99
      //   647: if_icmpeq -> 683
      //   650: iload #17
      //   652: bipush #115
      //   654: if_icmpeq -> 683
      //   657: iload #17
      //   659: bipush #67
      //   661: if_icmpeq -> 683
      //   664: iload #17
      //   666: bipush #83
      //   668: if_icmpne -> 674
      //   671: goto -> 683
      //   674: fconst_0
      //   675: fstore #14
      //   677: fconst_0
      //   678: fstore #13
      //   680: goto -> 701
      //   683: fload #12
      //   685: fload #14
      //   687: fsub
      //   688: fstore #10
      //   690: fload #11
      //   692: fload #13
      //   694: fsub
      //   695: fstore #14
      //   697: fload #10
      //   699: fstore #13
      //   701: iload_2
      //   702: iconst_0
      //   703: iadd
      //   704: istore #18
      //   706: aload #4
      //   708: iload #18
      //   710: faload
      //   711: fstore #9
      //   713: iload_2
      //   714: iconst_1
      //   715: iadd
      //   716: istore #17
      //   718: aload #4
      //   720: iload #17
      //   722: faload
      //   723: fstore #10
      //   725: iload_2
      //   726: iconst_2
      //   727: iadd
      //   728: istore #16
      //   730: aload #4
      //   732: iload #16
      //   734: faload
      //   735: fstore #7
      //   737: iload_2
      //   738: iconst_3
      //   739: iadd
      //   740: istore #19
      //   742: aload_0
      //   743: fload #14
      //   745: fload #13
      //   747: fload #9
      //   749: fload #10
      //   751: fload #7
      //   753: aload #4
      //   755: iload #19
      //   757: faload
      //   758: invokevirtual rCubicTo : (FFFFFF)V
      //   761: aload #4
      //   763: iload #18
      //   765: faload
      //   766: fload #11
      //   768: fadd
      //   769: fstore #9
      //   771: aload #4
      //   773: iload #17
      //   775: faload
      //   776: fload #12
      //   778: fadd
      //   779: fstore #13
      //   781: fload #11
      //   783: aload #4
      //   785: iload #16
      //   787: faload
      //   788: fadd
      //   789: fstore #14
      //   791: aload #4
      //   793: iload #19
      //   795: faload
      //   796: fstore #10
      //   798: fload #9
      //   800: fstore #11
      //   802: goto -> 1569
      //   805: iload_2
      //   806: iconst_0
      //   807: iadd
      //   808: istore #17
      //   810: fload #11
      //   812: aload #4
      //   814: iload #17
      //   816: faload
      //   817: fadd
      //   818: fstore #11
      //   820: iload_2
      //   821: iconst_1
      //   822: iadd
      //   823: istore #16
      //   825: fload #12
      //   827: aload #4
      //   829: iload #16
      //   831: faload
      //   832: fadd
      //   833: fstore #12
      //   835: iload_2
      //   836: ifle -> 856
      //   839: aload_0
      //   840: aload #4
      //   842: iload #17
      //   844: faload
      //   845: aload #4
      //   847: iload #16
      //   849: faload
      //   850: invokevirtual rLineTo : (FF)V
      //   853: goto -> 509
      //   856: aload_0
      //   857: aload #4
      //   859: iload #17
      //   861: faload
      //   862: aload #4
      //   864: iload #16
      //   866: faload
      //   867: invokevirtual rMoveTo : (FF)V
      //   870: goto -> 1243
      //   873: iload_2
      //   874: iconst_0
      //   875: iadd
      //   876: istore #17
      //   878: aload #4
      //   880: iload #17
      //   882: faload
      //   883: fstore #10
      //   885: iload_2
      //   886: iconst_1
      //   887: iadd
      //   888: istore #16
      //   890: aload_0
      //   891: fload #10
      //   893: aload #4
      //   895: iload #16
      //   897: faload
      //   898: invokevirtual rLineTo : (FF)V
      //   901: fload #11
      //   903: aload #4
      //   905: iload #17
      //   907: faload
      //   908: fadd
      //   909: fstore #11
      //   911: aload #4
      //   913: iload #16
      //   915: faload
      //   916: fstore #10
      //   918: fload #12
      //   920: fload #10
      //   922: fadd
      //   923: fstore #12
      //   925: goto -> 509
      //   928: iload #17
      //   930: bipush #113
      //   932: if_icmpeq -> 964
      //   935: iload #17
      //   937: bipush #116
      //   939: if_icmpeq -> 964
      //   942: iload #17
      //   944: bipush #81
      //   946: if_icmpeq -> 964
      //   949: fload #12
      //   951: fstore #9
      //   953: fload #11
      //   955: fstore #10
      //   957: iload #17
      //   959: bipush #84
      //   961: if_icmpne -> 982
      //   964: fload #11
      //   966: fconst_2
      //   967: fmul
      //   968: fload #13
      //   970: fsub
      //   971: fstore #10
      //   973: fload #12
      //   975: fconst_2
      //   976: fmul
      //   977: fload #14
      //   979: fsub
      //   980: fstore #9
      //   982: iload_2
      //   983: iconst_0
      //   984: iadd
      //   985: istore #16
      //   987: aload #4
      //   989: iload #16
      //   991: faload
      //   992: fstore #11
      //   994: iload_2
      //   995: iconst_1
      //   996: iadd
      //   997: istore #17
      //   999: aload_0
      //   1000: fload #10
      //   1002: fload #9
      //   1004: fload #11
      //   1006: aload #4
      //   1008: iload #17
      //   1010: faload
      //   1011: invokevirtual quadTo : (FFFF)V
      //   1014: aload #4
      //   1016: iload #16
      //   1018: faload
      //   1019: fstore #11
      //   1021: aload #4
      //   1023: iload #17
      //   1025: faload
      //   1026: fstore #12
      //   1028: fload #9
      //   1030: fstore #14
      //   1032: fload #10
      //   1034: fstore #13
      //   1036: goto -> 2134
      //   1039: iload #17
      //   1041: bipush #99
      //   1043: if_icmpeq -> 1075
      //   1046: iload #17
      //   1048: bipush #115
      //   1050: if_icmpeq -> 1075
      //   1053: iload #17
      //   1055: bipush #67
      //   1057: if_icmpeq -> 1075
      //   1060: fload #12
      //   1062: fstore #9
      //   1064: fload #11
      //   1066: fstore #10
      //   1068: iload #17
      //   1070: bipush #83
      //   1072: if_icmpne -> 1093
      //   1075: fload #11
      //   1077: fconst_2
      //   1078: fmul
      //   1079: fload #13
      //   1081: fsub
      //   1082: fstore #10
      //   1084: fload #12
      //   1086: fconst_2
      //   1087: fmul
      //   1088: fload #14
      //   1090: fsub
      //   1091: fstore #9
      //   1093: iload_2
      //   1094: iconst_0
      //   1095: iadd
      //   1096: istore #16
      //   1098: aload #4
      //   1100: iload #16
      //   1102: faload
      //   1103: fstore #13
      //   1105: iload_2
      //   1106: iconst_1
      //   1107: iadd
      //   1108: istore #17
      //   1110: aload #4
      //   1112: iload #17
      //   1114: faload
      //   1115: fstore #12
      //   1117: iload_2
      //   1118: iconst_2
      //   1119: iadd
      //   1120: istore #19
      //   1122: aload #4
      //   1124: iload #19
      //   1126: faload
      //   1127: fstore #11
      //   1129: iload_2
      //   1130: iconst_3
      //   1131: iadd
      //   1132: istore #18
      //   1134: aload_0
      //   1135: fload #10
      //   1137: fload #9
      //   1139: fload #13
      //   1141: fload #12
      //   1143: fload #11
      //   1145: aload #4
      //   1147: iload #18
      //   1149: faload
      //   1150: invokevirtual cubicTo : (FFFFFF)V
      //   1153: aload #4
      //   1155: iload #16
      //   1157: faload
      //   1158: fstore #11
      //   1160: aload #4
      //   1162: iload #17
      //   1164: faload
      //   1165: fstore #13
      //   1167: aload #4
      //   1169: iload #19
      //   1171: faload
      //   1172: fstore #10
      //   1174: aload #4
      //   1176: iload #18
      //   1178: faload
      //   1179: fstore #12
      //   1181: goto -> 1580
      //   1184: iload_2
      //   1185: iconst_0
      //   1186: iadd
      //   1187: istore #16
      //   1189: aload #4
      //   1191: iload #16
      //   1193: faload
      //   1194: fstore #11
      //   1196: iload_2
      //   1197: iconst_1
      //   1198: iadd
      //   1199: istore #17
      //   1201: aload #4
      //   1203: iload #17
      //   1205: faload
      //   1206: fstore #12
      //   1208: iload_2
      //   1209: ifle -> 1229
      //   1212: aload_0
      //   1213: aload #4
      //   1215: iload #16
      //   1217: faload
      //   1218: aload #4
      //   1220: iload #17
      //   1222: faload
      //   1223: invokevirtual lineTo : (FF)V
      //   1226: goto -> 509
      //   1229: aload_0
      //   1230: aload #4
      //   1232: iload #16
      //   1234: faload
      //   1235: aload #4
      //   1237: iload #17
      //   1239: faload
      //   1240: invokevirtual moveTo : (FF)V
      //   1243: fload #12
      //   1245: fstore #6
      //   1247: fload #11
      //   1249: fstore #5
      //   1251: goto -> 2134
      //   1254: iload_2
      //   1255: iconst_0
      //   1256: iadd
      //   1257: istore #17
      //   1259: aload #4
      //   1261: iload #17
      //   1263: faload
      //   1264: fstore #11
      //   1266: iload_2
      //   1267: iconst_1
      //   1268: iadd
      //   1269: istore #16
      //   1271: aload_0
      //   1272: fload #11
      //   1274: aload #4
      //   1276: iload #16
      //   1278: faload
      //   1279: invokevirtual lineTo : (FF)V
      //   1282: aload #4
      //   1284: iload #17
      //   1286: faload
      //   1287: fstore #11
      //   1289: aload #4
      //   1291: iload #16
      //   1293: faload
      //   1294: fstore #12
      //   1296: goto -> 509
      //   1299: iload_2
      //   1300: iconst_0
      //   1301: iadd
      //   1302: istore #17
      //   1304: aload_0
      //   1305: fconst_0
      //   1306: aload #4
      //   1308: iload #17
      //   1310: faload
      //   1311: invokevirtual rLineTo : (FF)V
      //   1314: aload #4
      //   1316: iload #17
      //   1318: faload
      //   1319: fstore #10
      //   1321: goto -> 918
      //   1324: iload_2
      //   1325: iconst_0
      //   1326: iadd
      //   1327: istore #16
      //   1329: aload #4
      //   1331: iload #16
      //   1333: faload
      //   1334: fstore #10
      //   1336: iload_2
      //   1337: iconst_1
      //   1338: iadd
      //   1339: istore #19
      //   1341: aload #4
      //   1343: iload #19
      //   1345: faload
      //   1346: fstore #14
      //   1348: iload_2
      //   1349: iconst_2
      //   1350: iadd
      //   1351: istore #18
      //   1353: aload #4
      //   1355: iload #18
      //   1357: faload
      //   1358: fstore #13
      //   1360: iload_2
      //   1361: iconst_3
      //   1362: iadd
      //   1363: istore #17
      //   1365: aload_0
      //   1366: fload #10
      //   1368: fload #14
      //   1370: fload #13
      //   1372: aload #4
      //   1374: iload #17
      //   1376: faload
      //   1377: invokevirtual rQuadTo : (FFFF)V
      //   1380: aload #4
      //   1382: iload #16
      //   1384: faload
      //   1385: fload #11
      //   1387: fadd
      //   1388: fstore #9
      //   1390: aload #4
      //   1392: iload #19
      //   1394: faload
      //   1395: fload #12
      //   1397: fadd
      //   1398: fstore #13
      //   1400: fload #11
      //   1402: aload #4
      //   1404: iload #18
      //   1406: faload
      //   1407: fadd
      //   1408: fstore #14
      //   1410: aload #4
      //   1412: iload #17
      //   1414: faload
      //   1415: fstore #10
      //   1417: fload #9
      //   1419: fstore #11
      //   1421: goto -> 1569
      //   1424: iload_2
      //   1425: iconst_0
      //   1426: iadd
      //   1427: istore #17
      //   1429: aload_0
      //   1430: aload #4
      //   1432: iload #17
      //   1434: faload
      //   1435: fconst_0
      //   1436: invokevirtual rLineTo : (FF)V
      //   1439: fload #11
      //   1441: aload #4
      //   1443: iload #17
      //   1445: faload
      //   1446: fadd
      //   1447: fstore #11
      //   1449: goto -> 509
      //   1452: aload #4
      //   1454: iload_2
      //   1455: iconst_0
      //   1456: iadd
      //   1457: faload
      //   1458: fstore #9
      //   1460: aload #4
      //   1462: iload_2
      //   1463: iconst_1
      //   1464: iadd
      //   1465: faload
      //   1466: fstore #10
      //   1468: iload_2
      //   1469: iconst_2
      //   1470: iadd
      //   1471: istore #19
      //   1473: aload #4
      //   1475: iload #19
      //   1477: faload
      //   1478: fstore #13
      //   1480: iload_2
      //   1481: iconst_3
      //   1482: iadd
      //   1483: istore #18
      //   1485: aload #4
      //   1487: iload #18
      //   1489: faload
      //   1490: fstore #7
      //   1492: iload_2
      //   1493: iconst_4
      //   1494: iadd
      //   1495: istore #17
      //   1497: aload #4
      //   1499: iload #17
      //   1501: faload
      //   1502: fstore #14
      //   1504: iload_2
      //   1505: iconst_5
      //   1506: iadd
      //   1507: istore #16
      //   1509: aload_0
      //   1510: fload #9
      //   1512: fload #10
      //   1514: fload #13
      //   1516: fload #7
      //   1518: fload #14
      //   1520: aload #4
      //   1522: iload #16
      //   1524: faload
      //   1525: invokevirtual rCubicTo : (FFFFFF)V
      //   1528: aload #4
      //   1530: iload #19
      //   1532: faload
      //   1533: fload #11
      //   1535: fadd
      //   1536: fstore #9
      //   1538: aload #4
      //   1540: iload #18
      //   1542: faload
      //   1543: fload #12
      //   1545: fadd
      //   1546: fstore #13
      //   1548: fload #11
      //   1550: aload #4
      //   1552: iload #17
      //   1554: faload
      //   1555: fadd
      //   1556: fstore #14
      //   1558: aload #4
      //   1560: iload #16
      //   1562: faload
      //   1563: fstore #10
      //   1565: fload #9
      //   1567: fstore #11
      //   1569: fload #12
      //   1571: fload #10
      //   1573: fadd
      //   1574: fstore #12
      //   1576: fload #14
      //   1578: fstore #10
      //   1580: fload #13
      //   1582: fstore #14
      //   1584: fload #11
      //   1586: fstore #13
      //   1588: fload #10
      //   1590: fstore #11
      //   1592: goto -> 509
      //   1595: iload_2
      //   1596: iconst_5
      //   1597: iadd
      //   1598: istore #16
      //   1600: aload #4
      //   1602: iload #16
      //   1604: faload
      //   1605: fstore #13
      //   1607: iload_2
      //   1608: bipush #6
      //   1610: iadd
      //   1611: istore #17
      //   1613: aload #4
      //   1615: iload #17
      //   1617: faload
      //   1618: fstore #7
      //   1620: aload #4
      //   1622: iload_2
      //   1623: iconst_0
      //   1624: iadd
      //   1625: faload
      //   1626: fstore #10
      //   1628: aload #4
      //   1630: iload_2
      //   1631: iconst_1
      //   1632: iadd
      //   1633: faload
      //   1634: fstore #9
      //   1636: aload #4
      //   1638: iload_2
      //   1639: iconst_2
      //   1640: iadd
      //   1641: faload
      //   1642: fstore #14
      //   1644: aload #4
      //   1646: iload_2
      //   1647: iconst_3
      //   1648: iadd
      //   1649: faload
      //   1650: fconst_0
      //   1651: fcmpl
      //   1652: ifeq -> 1661
      //   1655: iconst_1
      //   1656: istore #20
      //   1658: goto -> 1664
      //   1661: iconst_0
      //   1662: istore #20
      //   1664: aload #4
      //   1666: iload_2
      //   1667: iconst_4
      //   1668: iadd
      //   1669: faload
      //   1670: fconst_0
      //   1671: fcmpl
      //   1672: ifeq -> 1681
      //   1675: iconst_1
      //   1676: istore #21
      //   1678: goto -> 1684
      //   1681: iconst_0
      //   1682: istore #21
      //   1684: aload_0
      //   1685: fload #11
      //   1687: fload #12
      //   1689: fload #13
      //   1691: fload #11
      //   1693: fadd
      //   1694: fload #7
      //   1696: fload #12
      //   1698: fadd
      //   1699: fload #10
      //   1701: fload #9
      //   1703: fload #14
      //   1705: iload #20
      //   1707: iload #21
      //   1709: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   1712: fload #11
      //   1714: aload #4
      //   1716: iload #16
      //   1718: faload
      //   1719: fadd
      //   1720: fstore #11
      //   1722: fload #12
      //   1724: aload #4
      //   1726: iload #17
      //   1728: faload
      //   1729: fadd
      //   1730: fstore #12
      //   1732: goto -> 2126
      //   1735: iload_2
      //   1736: iconst_0
      //   1737: iadd
      //   1738: istore #17
      //   1740: aload_0
      //   1741: fload #11
      //   1743: aload #4
      //   1745: iload #17
      //   1747: faload
      //   1748: invokevirtual lineTo : (FF)V
      //   1751: aload #4
      //   1753: iload #17
      //   1755: faload
      //   1756: fstore #12
      //   1758: goto -> 2134
      //   1761: iload_2
      //   1762: istore #17
      //   1764: iload #17
      //   1766: iconst_0
      //   1767: iadd
      //   1768: istore #16
      //   1770: aload #4
      //   1772: iload #16
      //   1774: faload
      //   1775: fstore #11
      //   1777: iload #17
      //   1779: iconst_1
      //   1780: iadd
      //   1781: istore #18
      //   1783: aload #4
      //   1785: iload #18
      //   1787: faload
      //   1788: fstore #12
      //   1790: iload #17
      //   1792: iconst_2
      //   1793: iadd
      //   1794: istore #19
      //   1796: aload #4
      //   1798: iload #19
      //   1800: faload
      //   1801: fstore #13
      //   1803: iinc #17, 3
      //   1806: aload_0
      //   1807: fload #11
      //   1809: fload #12
      //   1811: fload #13
      //   1813: aload #4
      //   1815: iload #17
      //   1817: faload
      //   1818: invokevirtual quadTo : (FFFF)V
      //   1821: aload #4
      //   1823: iload #16
      //   1825: faload
      //   1826: fstore #13
      //   1828: aload #4
      //   1830: iload #18
      //   1832: faload
      //   1833: fstore #14
      //   1835: aload #4
      //   1837: iload #19
      //   1839: faload
      //   1840: fstore #11
      //   1842: aload #4
      //   1844: iload #17
      //   1846: faload
      //   1847: fstore #12
      //   1849: goto -> 2134
      //   1852: iload_2
      //   1853: iconst_0
      //   1854: iadd
      //   1855: istore #17
      //   1857: aload_0
      //   1858: aload #4
      //   1860: iload #17
      //   1862: faload
      //   1863: fload #12
      //   1865: invokevirtual lineTo : (FF)V
      //   1868: aload #4
      //   1870: iload #17
      //   1872: faload
      //   1873: fstore #11
      //   1875: goto -> 2134
      //   1878: iload_2
      //   1879: istore #17
      //   1881: aload #4
      //   1883: iload #17
      //   1885: iconst_0
      //   1886: iadd
      //   1887: faload
      //   1888: fstore #13
      //   1890: aload #4
      //   1892: iload #17
      //   1894: iconst_1
      //   1895: iadd
      //   1896: faload
      //   1897: fstore #11
      //   1899: iload #17
      //   1901: iconst_2
      //   1902: iadd
      //   1903: istore #19
      //   1905: aload #4
      //   1907: iload #19
      //   1909: faload
      //   1910: fstore #14
      //   1912: iload #17
      //   1914: iconst_3
      //   1915: iadd
      //   1916: istore #18
      //   1918: aload #4
      //   1920: iload #18
      //   1922: faload
      //   1923: fstore #10
      //   1925: iload #17
      //   1927: iconst_4
      //   1928: iadd
      //   1929: istore #16
      //   1931: aload #4
      //   1933: iload #16
      //   1935: faload
      //   1936: fstore #12
      //   1938: iinc #17, 5
      //   1941: aload_0
      //   1942: fload #13
      //   1944: fload #11
      //   1946: fload #14
      //   1948: fload #10
      //   1950: fload #12
      //   1952: aload #4
      //   1954: iload #17
      //   1956: faload
      //   1957: invokevirtual cubicTo : (FFFFFF)V
      //   1960: aload #4
      //   1962: iload #16
      //   1964: faload
      //   1965: fstore #11
      //   1967: aload #4
      //   1969: iload #17
      //   1971: faload
      //   1972: fstore #12
      //   1974: aload #4
      //   1976: iload #19
      //   1978: faload
      //   1979: fstore #13
      //   1981: aload #4
      //   1983: iload #18
      //   1985: faload
      //   1986: fstore #14
      //   1988: goto -> 2134
      //   1991: iload_2
      //   1992: istore #17
      //   1994: iload #17
      //   1996: iconst_5
      //   1997: iadd
      //   1998: istore #16
      //   2000: aload #4
      //   2002: iload #16
      //   2004: faload
      //   2005: fstore #13
      //   2007: iload #17
      //   2009: bipush #6
      //   2011: iadd
      //   2012: istore #18
      //   2014: aload #4
      //   2016: iload #18
      //   2018: faload
      //   2019: fstore #9
      //   2021: aload #4
      //   2023: iload #17
      //   2025: iconst_0
      //   2026: iadd
      //   2027: faload
      //   2028: fstore #10
      //   2030: aload #4
      //   2032: iload #17
      //   2034: iconst_1
      //   2035: iadd
      //   2036: faload
      //   2037: fstore #14
      //   2039: aload #4
      //   2041: iload #17
      //   2043: iconst_2
      //   2044: iadd
      //   2045: faload
      //   2046: fstore #7
      //   2048: aload #4
      //   2050: iload #17
      //   2052: iconst_3
      //   2053: iadd
      //   2054: faload
      //   2055: fconst_0
      //   2056: fcmpl
      //   2057: ifeq -> 2066
      //   2060: iconst_1
      //   2061: istore #20
      //   2063: goto -> 2069
      //   2066: iconst_0
      //   2067: istore #20
      //   2069: aload #4
      //   2071: iload #17
      //   2073: iconst_4
      //   2074: iadd
      //   2075: faload
      //   2076: fconst_0
      //   2077: fcmpl
      //   2078: ifeq -> 2087
      //   2081: iconst_1
      //   2082: istore #21
      //   2084: goto -> 2090
      //   2087: iconst_0
      //   2088: istore #21
      //   2090: aload_0
      //   2091: fload #11
      //   2093: fload #12
      //   2095: fload #13
      //   2097: fload #9
      //   2099: fload #10
      //   2101: fload #14
      //   2103: fload #7
      //   2105: iload #20
      //   2107: iload #21
      //   2109: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   2112: aload #4
      //   2114: iload #16
      //   2116: faload
      //   2117: fstore #11
      //   2119: aload #4
      //   2121: iload #18
      //   2123: faload
      //   2124: fstore #12
      //   2126: fload #12
      //   2128: fstore #14
      //   2130: fload #11
      //   2132: fstore #13
      //   2134: iload_2
      //   2135: iload #15
      //   2137: iadd
      //   2138: istore_2
      //   2139: iload_3
      //   2140: istore #17
      //   2142: goto -> 373
      //   2145: aload_1
      //   2146: iconst_0
      //   2147: fload #11
      //   2149: fastore
      //   2150: aload_1
      //   2151: iconst_1
      //   2152: fload #12
      //   2154: fastore
      //   2155: aload_1
      //   2156: iconst_2
      //   2157: fload #13
      //   2159: fastore
      //   2160: aload_1
      //   2161: iconst_3
      //   2162: fload #14
      //   2164: fastore
      //   2165: aload_1
      //   2166: iconst_4
      //   2167: fload #5
      //   2169: fastore
      //   2170: aload_1
      //   2171: iconst_5
      //   2172: fload #6
      //   2174: fastore
      //   2175: return
    }
    
    private static void arcToBezier(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d1 = Math.cos(param1Double7);
      double d2 = Math.sin(param1Double7);
      double d3 = Math.cos(param1Double8);
      double d4 = Math.sin(param1Double8);
      param1Double7 = -param1Double3;
      double d5 = param1Double7 * d1;
      double d6 = param1Double4 * d2;
      param1Double7 *= d2;
      double d7 = param1Double4 * d1;
      param1Double4 = i;
      Double.isNaN(param1Double4);
      param1Double9 /= param1Double4;
      param1Double4 = d4 * param1Double7 + d3 * d7;
      d4 = d5 * d4 - d6 * d3;
      byte b = 0;
      d3 = param1Double5;
      param1Double5 = param1Double6;
      param1Double6 = param1Double4;
      double d8 = param1Double8;
      param1Double4 = param1Double7;
      param1Double7 = param1Double9;
      param1Double9 = d2;
      param1Double8 = d1;
      while (true) {
        d1 = param1Double3;
        if (b < i) {
          double d9 = d8 + param1Double7;
          double d10 = Math.sin(d9);
          double d11 = Math.cos(d9);
          double d12 = param1Double1 + d1 * param1Double8 * d11 - d6 * d10;
          d1 = param1Double2 + d1 * param1Double9 * d11 + d7 * d10;
          d2 = d5 * d10 - d6 * d11;
          d10 = d10 * param1Double4 + d11 * d7;
          d11 = d9 - d8;
          d8 = Math.tan(d11 / 2.0D);
          d8 = Math.sin(d11) * (Math.sqrt(d8 * 3.0D * d8 + 4.0D) - 1.0D) / 3.0D;
          param1Path.rLineTo(0.0F, 0.0F);
          param1Path.cubicTo((float)(d3 + d4 * d8), (float)(param1Double5 + param1Double6 * d8), (float)(d12 - d8 * d2), (float)(d1 - d8 * d10), (float)d12, (float)d1);
          b++;
          d3 = d12;
          d8 = d9;
          param1Double6 = d10;
          d4 = d2;
          param1Double5 = d1;
          continue;
        } 
        break;
      } 
    }
    
    private static void drawArc(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d1 = Math.toRadians(param1Float7);
      double d2 = Math.cos(d1);
      double d3 = Math.sin(d1);
      double d4 = param1Float1;
      Double.isNaN(d4);
      double d5 = param1Float2;
      Double.isNaN(d5);
      double d6 = param1Float5;
      Double.isNaN(d6);
      double d7 = (d4 * d2 + d5 * d3) / d6;
      double d8 = -param1Float1;
      Double.isNaN(d8);
      Double.isNaN(d5);
      double d9 = param1Float6;
      Double.isNaN(d9);
      double d10 = (d8 * d3 + d5 * d2) / d9;
      double d11 = param1Float3;
      Double.isNaN(d11);
      d8 = param1Float4;
      Double.isNaN(d8);
      Double.isNaN(d6);
      double d12 = (d11 * d2 + d8 * d3) / d6;
      d11 = -param1Float3;
      Double.isNaN(d11);
      Double.isNaN(d8);
      Double.isNaN(d9);
      double d13 = (d11 * d3 + d8 * d2) / d9;
      double d14 = d7 - d12;
      double d15 = d10 - d13;
      d11 = (d7 + d12) / 2.0D;
      d8 = (d10 + d13) / 2.0D;
      double d16 = d14 * d14 + d15 * d15;
      if (d16 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d17 = 1.0D / d16 - 0.25D;
      if (d17 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Points are too far apart ");
        stringBuilder.append(d16);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d16) / 1.99999D);
        drawArc(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      d16 = Math.sqrt(d17);
      d14 *= d16;
      d15 = d16 * d15;
      if (param1Boolean1 == param1Boolean2) {
        d11 -= d15;
        d8 += d14;
      } else {
        d11 += d15;
        d8 -= d14;
      } 
      d14 = Math.atan2(d10 - d8, d7 - d11);
      d10 = Math.atan2(d13 - d8, d12 - d11) - d14;
      if (d10 >= 0.0D) {
        param1Boolean1 = true;
      } else {
        param1Boolean1 = false;
      } 
      d7 = d10;
      if (param1Boolean2 != param1Boolean1)
        if (d10 > 0.0D) {
          d7 = d10 - 6.283185307179586D;
        } else {
          d7 = d10 + 6.283185307179586D;
        }  
      Double.isNaN(d6);
      d11 *= d6;
      Double.isNaN(d9);
      d8 *= d9;
      arcToBezier(param1Path, d11 * d2 - d8 * d3, d11 * d3 + d8 * d2, d6, d9, d4, d5, d1, d14, d7);
    }
    
    public static void nodesToPath(PathDataNode[] param1ArrayOfPathDataNode, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c1 = 'm';
      byte b = 0;
      char c2;
      for (c2 = c1; b < param1ArrayOfPathDataNode.length; c2 = c1) {
        addCommand(param1Path, arrayOfFloat, c2, (param1ArrayOfPathDataNode[b]).mType, (param1ArrayOfPathDataNode[b]).mParams);
        c1 = (param1ArrayOfPathDataNode[b]).mType;
        b++;
      } 
    }
    
    public void interpolatePathDataNode(PathDataNode param1PathDataNode1, PathDataNode param1PathDataNode2, float param1Float) {
      this.mType = (char)param1PathDataNode1.mType;
      byte b = 0;
      while (true) {
        float[] arrayOfFloat = param1PathDataNode1.mParams;
        if (b < arrayOfFloat.length) {
          this.mParams[b] = arrayOfFloat[b] * (1.0F - param1Float) + param1PathDataNode2.mParams[b] * param1Float;
          b++;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\core\graphics\PathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */