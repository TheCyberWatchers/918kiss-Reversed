package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat {
  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              C:\Users\admin\Desktop\918kiss\918kiss(Reverse)\classes.jar!\androidx\core\content\pm\ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */